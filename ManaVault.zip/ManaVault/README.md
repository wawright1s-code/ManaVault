# ManaVault

An Android app for Magic: The Gathering players: scan cards with your camera, keep your collection with live prices, build decks, and get judge-level explanations of how any set of cards interact.

Card data, images and prices come from [Scryfall](https://scryfall.com)'s free API, so every card ever printed is searchable.

## Features

**Scanner**
- Point the camera at a card. ManaVault reads the name on-device (Google ML Kit, no upload) and, on cards printed since 2014, the set code and collector number in the bottom-left corner, so it can find the exact printing and its price.
- *Single* mode shows the card with its price; pick finish (non-foil / foil / etched), quantity, then add it to your collection or a deck. "Wrong printing?" lets you choose the exact one.
- *Bulk add* mode adds every recognized card to your collection automatically while you flip through a stack. Each card has an undo button. To scan two copies of the same card in a row, pull the first one out of view for a second.
- Flashlight toggle and a "type a name" fallback.

**Collection**
- Total value (USD, EUR or MTGO Tix), card counts, and a value-over-time sparkline.
- Prices refresh automatically once a day (Scryfall updates daily) or on demand.
- Filter by name/type/set and color; sort by value, name, date added, set or mana value.
- Tap an entry to change quantity, finish, condition or printing.
- Long-press to multi-select: send to the Interaction Lab, add to a deck, or delete.
- Import CSV from ManaBox, Moxfield, Deckbox, Archidekt and others, or paste a plain list. Export to CSV for backup.

**Decks**
- Formats: Commander, Standard, Pioneer, Modern, Legacy, Vintage, Pauper, Historic, Timeless, Premodern, or Casual.
- Legality check: deck size, sideboard size, copy limits (with exceptions such as Relentless Rats and basic lands), banned/restricted cards, and Commander color identity.
- Grouped by card type with owned/missing indicators against your collection, plus a one-tap "buy list" of what you're missing.
- Stats: mana curve, colored pips, type breakdown, most valuable cards.
- Playtest: draw sample opening hands, take London mulligans (tap cards to put them on the bottom) and draw turn by turn. Shows the odds of each land count in your opening hand and of hitting your land drops.
- **Analyze with Claude** (⋮ menu): a review of the whole list — game plan, synergies and combos, mana and curve, weak spots, and suggested swaps that are legal in your format. Ask follow-up questions; optionally tell it what to focus on ("budget upgrades", "more removal").
- Import from MTG Arena, MTGO, Moxfield or Archidekt text; export in Arena format (copy or share).

**Search**
- Type a name or full Scryfall syntax, or tap **Filters** to search by color (including / exactly / at most / fits a commander), card type, legendary, commander-eligible, format, rarity, mana value, maximum price and rules text. The Scryfall query it builds is shown so you can learn the syntax.
- Sort by name, price, release date, mana value or EDHREC popularity; show every printing; or roll a random card.

**Interaction Lab**
- Pick any number of cards (from search, your collection, a deck, or the scanner) and tap **Explain**.
- With an Anthropic API key, Claude explains how the cards interact: timing, triggers, replacement effects, combos and loops, the rules that matter, and common mistakes. It's grounded in each card's current Oracle text and official rulings. Add a situation ("opponent has Rest in Peace") and ask follow-up questions.
- Without a key, it still works in a free mode: official rulings for each card, keyword reminders, and built-in notes on classic interactions (deathtouch + trample, persist/undying loops, indestructible vs. exile, hexproof vs. "each", replacement-effect ordering, and more).

## Install it on your phone

You need to build the app once. Pick whichever is easier.

### Option A: let GitHub build it (nothing to install)

1. Create a free account at [github.com](https://github.com) and make a new **private** repository.
2. On the repository page choose **Add file → Upload files**, and drag in everything inside this `ManaVault` folder. Commit.
   - The `.github` folder is hidden on some computers. If it didn't upload, go to the **Actions** tab, choose **set up a workflow yourself**, paste the contents of `.github/workflows/build-apk.yml`, and commit.
3. Open the **Actions** tab. The "Build APK" run starts automatically and takes about 5–8 minutes.
4. When it shows a green check, open the run and download **ManaVault-apk** under *Artifacts*. Unzip it to get `app-debug.apk`.
5. Copy the APK to your phone (or download it there) and open it. Android will ask you to allow installing apps from that source. Allow it, then install.

### Option B: Android Studio

1. Install [Android Studio](https://developer.android.com/studio).
2. **File → Open** and choose this `ManaVault` folder. Let Gradle sync finish. If it offers to upgrade the Android Gradle Plugin, you can accept or skip.
3. On your phone, enable **Developer options → USB debugging**, connect it, and press **Run ▶**.

Requires Android 8.0 or newer.

## Set up AI explanations (optional)

1. Create an API key at [console.anthropic.com](https://console.anthropic.com/settings/keys) and add a few dollars of credit.
2. In ManaVault open **Settings** (⋮ menu on the Collection screen, or the gear in the Interaction Lab), paste the key, tap **Save key**, then **Test**.
3. Pick a model. Claude Sonnet 5.5 is the default and costs about 1–3¢ per explanation; Opus 5.5 is more thorough on tricky rules; Haiku 4.5 is the cheapest.

The key is stored only on your phone and is sent only to `api.anthropic.com`.

## Back up your data

Everything is stored on your phone. In **Settings → Your data**, tap **Back up everything** to save one file with your collection, decks and preferences (your API key is never included). **Restore** can either merge a backup into what you have or replace it, so it also works for moving to a new phone.

## Scanning tips

- Fill the outline with the card, in even light, without glare across the name.
- The faint bands in the outline show where the name and the set/number line should sit.
- Foils and textured frames read less reliably; use "type a name" or change the printing if needed.
- Very old cards (before 2014) have no collector line, so the scanner matches by name. Check the printing before adding.

## Project layout

```
app/src/main/java/com/manavault/app/
  core/        Pure Kotlin logic with unit tests: Scryfall parsing, scanner text heuristics,
               deck list import/export, deck stats & legality, CSV, rules notes, Claude prompt
  data/        Room database, Scryfall + Claude HTTP clients, repositories, settings
  ui/          Jetpack Compose screens: scan, collection, decks, interaction lab, search,
               card detail, settings
```

Run the unit tests with `./gradlew test`.

Built with Kotlin, Jetpack Compose (Material 3), Room, CameraX, ML Kit text recognition, OkHttp and Coil.

## Notes

- Your collection and decks are stored on the phone. Use **Back up everything** in Settings (or **Export CSV** for just the collection).
- Prices come from Scryfall (TCGplayer for USD, Cardmarket for EUR, Cardhoarder for Tix) and update once a day.
- ManaVault is unofficial Fan Content permitted under the Fan Content Policy. Not approved/endorsed by Wizards. Portions of the materials used are property of Wizards of the Coast. ©Wizards of the Coast LLC. Card data and images courtesy of Scryfall.
