package com.manavault.app.core

import com.manavault.app.core.model.Card
import com.manavault.app.core.model.Prices

object Fixtures {

    fun card(
        name: String,
        manaCost: String = "",
        cmc: Double = 0.0,
        typeLine: String = "Instant",
        oracle: String = "",
        keywords: List<String> = emptyList(),
        identity: List<String> = emptyList(),
        legal: Map<String, String> = emptyMap(),
        prices: Prices = Prices(usd = 1.0),
        finishes: List<String> = listOf("nonfoil", "foil"),
        id: String = "id-" + name.lowercase().replace(' ', '-'),
    ) = Card(
        id = id,
        oracleId = "oracle-" + name.lowercase().replace(' ', '-'),
        name = name,
        manaCost = manaCost,
        cmc = cmc,
        typeLine = typeLine,
        oracleText = oracle,
        keywords = keywords,
        colorIdentity = identity,
        legalities = legal,
        prices = prices,
        finishes = finishes,
        setCode = "tst",
        collectorNumber = "1",
    )

    val LIGHTNING_BOLT_JSON = """
    {
      "object": "card",
      "id": "e3285e6b-3e79-4d7c-bf96-d920f973b80d",
      "oracle_id": "4457ed35-7c10-48c8-9776-456485fdf070",
      "multiverse_ids": [191089],
      "name": "Lightning Bolt",
      "lang": "en",
      "released_at": "2009-07-17",
      "uri": "https://api.scryfall.com/cards/e3285e6b-3e79-4d7c-bf96-d920f973b80d",
      "scryfall_uri": "https://scryfall.com/card/m10/146/lightning-bolt",
      "layout": "normal",
      "highres_image": true,
      "image_status": "highres_scan",
      "image_uris": {
        "small": "https://cards.scryfall.io/small/front/e/3/e3285e6b.jpg",
        "normal": "https://cards.scryfall.io/normal/front/e/3/e3285e6b.jpg",
        "large": "https://cards.scryfall.io/large/front/e/3/e3285e6b.jpg",
        "png": "https://cards.scryfall.io/png/front/e/3/e3285e6b.png",
        "art_crop": "https://cards.scryfall.io/art_crop/front/e/3/e3285e6b.jpg",
        "border_crop": "https://cards.scryfall.io/border_crop/front/e/3/e3285e6b.jpg"
      },
      "mana_cost": "{R}",
      "cmc": 1.0,
      "type_line": "Instant",
      "oracle_text": "Lightning Bolt deals 3 damage to any target.",
      "colors": ["R"],
      "color_identity": ["R"],
      "keywords": [],
      "legalities": {"standard": "not_legal", "modern": "legal", "legacy": "legal", "vintage": "legal", "commander": "legal", "pauper": "legal"},
      "games": ["paper", "mtgo"],
      "reserved": false,
      "foil": true,
      "nonfoil": true,
      "finishes": ["nonfoil", "foil"],
      "set": "m10",
      "set_name": "Magic 2010",
      "collector_number": "146",
      "rarity": "common",
      "artist": "Christopher Moeller",
      "edhrec_rank": 4,
      "prices": {"usd": "2.15", "usd_foil": "9.99", "usd_etched": null, "eur": "1.80", "eur_foil": "7.50", "tix": "0.03"},
      "purchase_uris": {
        "tcgplayer": "https://www.tcgplayer.com/product/1",
        "cardmarket": "https://www.cardmarket.com/en/Magic/Products/Search?searchString=Lightning+Bolt",
        "cardhoarder": "https://www.cardhoarder.com/cards/1"
      }
    }
    """.trimIndent()

    val DELVER_JSON = """
    {
      "object": "card",
      "id": "11bf83bb-c95b-4b4f-9a56-ce7a1816307a",
      "oracle_id": "a6a0f33b-6d01-42ec-a3cb-7a0a9e1f6ea3",
      "name": "Delver of Secrets // Insectile Aberration",
      "lang": "en",
      "released_at": "2011-09-30",
      "scryfall_uri": "https://scryfall.com/card/isd/51/delver-of-secrets-insectile-aberration",
      "layout": "transform",
      "cmc": 1.0,
      "type_line": "Creature — Human Wizard // Creature — Human Insect",
      "color_identity": ["U"],
      "keywords": ["Flying", "Transform"],
      "card_faces": [
        {
          "object": "card_face",
          "name": "Delver of Secrets",
          "mana_cost": "{U}",
          "type_line": "Creature — Human Wizard",
          "oracle_text": "At the beginning of your upkeep, look at the top card of your library. You may reveal that card. If an instant or sorcery card is revealed this way, transform Delver of Secrets.",
          "colors": ["U"],
          "power": "1",
          "toughness": "1",
          "image_uris": {
            "small": "https://cards.scryfall.io/small/front/1/1/delver.jpg",
            "normal": "https://cards.scryfall.io/normal/front/1/1/delver.jpg",
            "large": "https://cards.scryfall.io/large/front/1/1/delver.jpg",
            "art_crop": "https://cards.scryfall.io/art_crop/front/1/1/delver.jpg"
          }
        },
        {
          "object": "card_face",
          "name": "Insectile Aberration",
          "mana_cost": "",
          "type_line": "Creature — Human Insect",
          "oracle_text": "Flying",
          "colors": ["U"],
          "color_indicator": ["U"],
          "power": "3",
          "toughness": "2",
          "image_uris": {
            "small": "https://cards.scryfall.io/small/back/1/1/delver.jpg",
            "normal": "https://cards.scryfall.io/normal/back/1/1/delver.jpg",
            "large": "https://cards.scryfall.io/large/back/1/1/delver.jpg",
            "art_crop": "https://cards.scryfall.io/art_crop/back/1/1/delver.jpg"
          }
        }
      ],
      "legalities": {"modern": "legal", "legacy": "legal", "pauper": "legal"},
      "finishes": ["nonfoil", "foil"],
      "set": "isd",
      "set_name": "Innistrad",
      "collector_number": "51",
      "rarity": "common",
      "prices": {"usd": "0.40", "usd_foil": "4.10", "usd_etched": null, "eur": "0.25", "eur_foil": "2.00", "tix": "0.02"}
    }
    """.trimIndent()
}
