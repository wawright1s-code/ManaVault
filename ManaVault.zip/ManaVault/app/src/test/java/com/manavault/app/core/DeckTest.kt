package com.manavault.app.core

import com.manavault.app.core.Fixtures.card
import com.manavault.app.core.deck.Board
import com.manavault.app.core.deck.DeckAnalysis
import com.manavault.app.core.deck.DeckCardEntry
import com.manavault.app.core.deck.DeckLine
import com.manavault.app.core.deck.DeckListFormat
import com.manavault.app.core.deck.ExportEntry
import com.manavault.app.core.deck.Formats
import com.manavault.app.core.deck.Severity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DeckTest {

    @Test
    fun parsesArenaExport() {
        val text = """
            Commander
            1 Atraxa, Praetors' Voice (2X2) 190

            Deck
            1 Sol Ring (CMM) 400
            4 Lightning Bolt (M10) 146
            1 Fire // Ice (MH2) 290

            Sideboard
            2 Duress (M21) 96
        """.trimIndent()
        val lines = DeckListFormat.parse(text)
        assertEquals(5, lines.size)
        assertEquals(DeckLine(1, "Atraxa, Praetors' Voice", "2x2", "190", Board.COMMANDER), lines[0])
        assertEquals(DeckLine(4, "Lightning Bolt", "m10", "146", Board.MAIN), lines[2])
        assertEquals("Fire // Ice", lines[3].name)
        assertEquals(Board.SIDE, lines[4].board)
    }

    @Test
    fun parsesPlainListsAndMtgo() {
        val lines = DeckListFormat.parse(
            """
            4x Counterspell
            Brainstorm
            3 Ponder [M12]
            // a comment
            SB: 2 Pyroblast
            1 Sol Ring (CMM) 400 *F* #ramp
            """.trimIndent()
        )
        assertEquals(DeckLine(4, "Counterspell"), lines[0])
        assertEquals(DeckLine(1, "Brainstorm"), lines[1])
        assertEquals(DeckLine(3, "Ponder", "m12", null), lines[2])
        assertEquals(Board.SIDE, lines[3].board)
        assertEquals("Pyroblast", lines[3].name)
        assertEquals(DeckLine(1, "Sol Ring", "cmm", "400", Board.MAIN, foil = true), lines[4])
    }

    @Test
    fun infersSideboardFromBlankLine() {
        val main = (1..15).joinToString("\n") { "4 Card $it" }
        val lines = DeckListFormat.parse("$main\n\n3 Side A\n2 Side B")
        assertEquals(60, lines.filter { it.board == Board.MAIN }.sumOf { it.quantity })
        assertEquals(5, lines.filter { it.board == Board.SIDE }.sumOf { it.quantity })
    }

    @Test
    fun splitCardSlashesNormalised() {
        assertEquals("Fire // Ice", DeckListFormat.parseCardLine("1 Fire/Ice")!!.name)
        assertEquals("Wear // Tear", DeckListFormat.parseCardLine("Wear // Tear")!!.name)
    }

    @Test
    fun exportsArenaFormat() {
        val out = DeckListFormat.export(
            listOf(
                ExportEntry(1, "Atraxa, Praetors' Voice", "2x2", "190", Board.COMMANDER),
                ExportEntry(4, "Lightning Bolt", "m10", "146", Board.MAIN),
                ExportEntry(2, "Duress", null, null, Board.SIDE),
            )
        )
        assertEquals("Commander\n1 Atraxa, Praetors' Voice (2X2) 190\n\nDeck\n4 Lightning Bolt (M10) 146\n\nSideboard\n2 Duress\n", out)
        // and it parses back to the same thing
        val back = DeckListFormat.parse(out)
        assertEquals(3, back.size)
        assertEquals(Board.SIDE, back[2].board)
    }

    @Test
    fun statsCurveAndTypes() {
        val entries = listOf(
            DeckCardEntry(card("Bolt", "{R}", 1.0, oracle = "Lightning Bolt deals 3 damage to any target."), 4, Board.MAIN),
            DeckCardEntry(card("Bears", "{1}{G}", 2.0, typeLine = "Creature — Bear"), 4, Board.MAIN),
            DeckCardEntry(card("Mountain", typeLine = "Basic Land — Mountain"), 10, Board.MAIN),
            DeckCardEntry(card("Big", "{7}{G}{G}", 9.0, typeLine = "Creature — Giant"), 1, Board.MAIN),
            DeckCardEntry(card("Duress", "{B}", 1.0, typeLine = "Sorcery"), 2, Board.SIDE),
        )
        val s = DeckAnalysis.stats(entries)
        assertEquals(19, s.mainCount)
        assertEquals(2, s.sideCount)
        assertEquals(10, s.landCount)
        assertEquals(listOf(0, 4, 4, 0, 0, 0, 0, 1), s.curve)
        assertEquals(mapOf("G" to 6, "R" to 4), s.colorPips)
        assertEquals("Creature", s.typeCounts.first().first)
        assertEquals((4 * 1.0 + 4 * 2.0 + 9.0) / 9, s.averageManaValue, 0.0001)
    }

    @Test
    fun constructedLegality() {
        val legalModern = mapOf("modern" to "legal")
        val entries = listOf(
            DeckCardEntry(card("Bolt", legal = legalModern), 5, Board.MAIN),
            DeckCardEntry(card("Mountain", typeLine = "Basic Land — Mountain", legal = legalModern), 50, Board.MAIN),
            DeckCardEntry(card("Banned Thing", legal = mapOf("modern" to "banned")), 1, Board.MAIN),
            DeckCardEntry(card("Relentless Rats", typeLine = "Creature — Rat", oracle = "A deck can have any number of cards named Relentless Rats.", legal = legalModern), 12, Board.MAIN),
        )
        val issues = DeckAnalysis.checkLegality(Formats.byId("modern"), entries)
        val messages = issues.map { it.message }
        assertTrue(messages.any { it.contains("Bolt: 5 copies") })
        assertTrue(messages.any { it.contains("Banned Thing is banned") })
        assertTrue(messages.none { it.contains("Relentless Rats") })
        assertTrue(messages.none { it.contains("Mountain") })
        assertTrue(messages.none { it.contains("at least 60") }) // 68 cards
    }

    @Test
    fun commanderLegality() {
        val legal = mapOf("commander" to "legal")
        val commander = card("Krenko, Mob Boss", "{2}{R}{R}", 4.0, "Legendary Creature — Goblin Warrior", identity = listOf("R"), legal = legal)
        val entries = listOf(
            DeckCardEntry(commander, 1, Board.COMMANDER),
            DeckCardEntry(card("Mountain", typeLine = "Basic Land — Mountain", identity = listOf("R"), legal = legal), 97, Board.MAIN),
            DeckCardEntry(card("Counterspell", identity = listOf("U"), legal = legal), 1, Board.MAIN),
            DeckCardEntry(card("Shock", identity = listOf("R"), legal = legal), 2, Board.MAIN),
        )
        val issues = DeckAnalysis.checkLegality(Formats.COMMANDER, entries)
        assertTrue(issues.any { it.message.contains("Counterspell is outside your commander's color identity") })
        assertTrue(issues.any { it.message.contains("Shock: 2 copies") })
        assertTrue(issues.any { it.message.contains("exactly 100") }) // 101 cards
        assertTrue(issues.all { it.severity == Severity.ERROR })
    }
}
