package com.manavault.app.core

import com.manavault.app.core.model.Currency
import com.manavault.app.core.scryfall.ColorMode
import com.manavault.app.core.scryfall.SearchFilters
import com.manavault.app.core.scryfall.SearchQueryBuilder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchFiltersTest {

    @Test
    fun buildsScryfallSyntax() {
        val f = SearchFilters(
            colors = setOf("R", "U"),
            types = setOf("Sorcery", "Instant"),
            format = "modern",
            rarities = setOf("rare", "common"),
            minMv = 1,
            maxMv = 3,
            maxPrice = 5.0,
            rulesText = "draw \"a\" card",
        )
        assertEquals(
            "bolt c>=ur (t:instant or t:sorcery) f:modern (r:common or r:rare) mv>=1 mv<=3 usd<=5 o:\"draw a card\"",
            SearchQueryBuilder.build(" bolt ", f),
        )
        assertEquals(7, f.activeCount)
    }

    @Test
    fun colorModesAndColorless() {
        fun q(f: SearchFilters, cur: Currency = Currency.USD) = SearchQueryBuilder.build("", f, cur)
        assertEquals("c=wb", q(SearchFilters(colors = setOf("B", "W"), colorMode = ColorMode.EXACTLY)))
        assertEquals("c<=g", q(SearchFilters(colors = setOf("G"), colorMode = ColorMode.AT_MOST)))
        assertEquals("id<=wubrg is:commander", q(SearchFilters(colors = setOf("G", "R", "B", "U", "W"), colorMode = ColorMode.IDENTITY, commanders = true)))
        assertEquals("c=c", q(SearchFilters(colors = setOf("C"))))
        assertEquals("t:creature t:legendary eur<=2.5", q(SearchFilters(types = setOf("Creature"), legendary = true, maxPrice = 2.5), Currency.EUR))
        assertEquals("", q(SearchFilters()))
        assertTrue(SearchFilters().isEmpty)
    }
}
