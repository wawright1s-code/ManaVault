package com.manavault.app.core

import com.manavault.app.core.backup.BackupCodec
import com.manavault.app.core.backup.BackupData
import com.manavault.app.core.backup.BackupDeck
import com.manavault.app.core.backup.BackupDeckCard
import com.manavault.app.core.backup.BackupEntry
import com.manavault.app.core.backup.BackupFormatException
import com.manavault.app.core.backup.BackupSettings
import com.manavault.app.core.scryfall.ScryfallJson
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class BackupTest {

    private val bolt = ScryfallJson.parseCard(Fixtures.LIGHTNING_BOLT_JSON)
    private val delver = ScryfallJson.parseCard(Fixtures.DELVER_JSON)

    private val data = BackupData(
        exportedAt = 1_700_000_000_000,
        cards = listOf(bolt, delver),
        collection = listOf(
            BackupEntry(bolt.id, 4, "nonfoil", "NM", "en", 1_600_000_000_000),
            BackupEntry(delver.id, 1, "foil", "LP", "en", 1_600_000_000_001),
        ),
        decks = listOf(
            BackupDeck(
                "Izzet Tempo", "modern", "notes \"quoted\"", 1, 2,
                listOf(BackupDeckCard(bolt.id, "main", 4), BackupDeckCard(delver.id, "side", 2)),
            )
        ),
        settings = BackupSettings("eur", "LP", "claude-opus-5-5"),
    )

    @Test
    fun roundTrips() {
        val text = BackupCodec.encode(data)
        assertFalse("API key must never be written", text.contains("apiKey", ignoreCase = true))
        val back = BackupCodec.decode(text)
        assertEquals(data, back)
        assertEquals(5, back.collectionCount)
    }

    @Test
    fun dropsReferencesToMissingCards() {
        val broken = data.copy(
            cards = listOf(bolt),
            collection = data.collection,
        )
        val back = BackupCodec.decode(BackupCodec.encode(broken))
        assertEquals(listOf(bolt.id), back.collection.map { it.cardId })
        assertEquals(listOf(bolt.id), back.decks.single().cards.map { it.cardId })
    }

    @Test
    fun rejectsOtherFiles() {
        for (text in listOf("not json", "{\"format\":\"something-else\"}", "[1,2,3]")) {
            try {
                BackupCodec.decode(text)
                fail("expected an error for $text")
            } catch (e: BackupFormatException) {
                assertTrue(e.message!!.contains("isn't a ManaVault backup"))
            }
        }
        try {
            BackupCodec.decode("{\"format\":\"manavault-backup\",\"version\":99}")
            fail("expected a version error")
        } catch (e: BackupFormatException) {
            assertTrue(e.message!!.contains("newer version"))
        }
    }
}
