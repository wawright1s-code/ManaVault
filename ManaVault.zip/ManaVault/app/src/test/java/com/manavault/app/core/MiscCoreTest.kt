package com.manavault.app.core

import com.manavault.app.core.Fixtures.card
import com.manavault.app.core.collection.Csv
import com.manavault.app.core.collection.CollectionCsv
import com.manavault.app.core.collection.CsvCollectionRow
import com.manavault.app.core.interaction.ChatTurn
import com.manavault.app.core.interaction.ClaudeProtocol
import com.manavault.app.core.interaction.InteractionPrompt
import com.manavault.app.core.interaction.QuickNotes
import com.manavault.app.core.model.Condition
import com.manavault.app.core.model.Currency
import com.manavault.app.core.model.Finish
import com.manavault.app.core.model.Ruling
import com.manavault.app.core.text.Format
import com.manavault.app.core.text.MdBlock
import com.manavault.app.core.text.MdSpan
import com.manavault.app.core.text.MiniMarkdown
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MiscCoreTest {

    @Test
    fun csvRoundTrip() {
        val rows = listOf(
            CsvCollectionRow(3, "Lightning Bolt", "m10", "Magic 2010", "146", Finish.FOIL, Condition.LP, "en", "e3285e6b-3e79-4d7c-bf96-d920f973b80d", 9.99),
            CsvCollectionRow(1, "Fire // Ice, the \"Best\"", "mh2", "Modern Horizons 2", "290"),
        )
        val text = CollectionCsv.write(rows)
        val back = CollectionCsv.read(text)!!
        assertEquals(rows, back)
    }

    @Test
    fun csvReadsOtherAppsColumns() {
        val moxfield = "\"Count\",\"Tradelist Count\",\"Name\",\"Edition\",\"Condition\",\"Language\",\"Foil\",\"Tags\",\"Last Modified\",\"Collector Number\"\n" +
            "\"2\",\"0\",\"Sol Ring\",\"cmm\",\"Near Mint\",\"English\",\"foil\",\"\",\"2024-01-01\",\"400\"\n"
        val rows = CollectionCsv.read(moxfield)!!
        assertEquals(1, rows.size)
        assertEquals(CsvCollectionRow(2, "Sol Ring", "cmm", null, "400", Finish.FOIL, Condition.NM, "en"), rows[0])

        val manabox = "Name;Set code;Collector number;Foil;Quantity;Scryfall ID\nShock;m21;159;normal;4;11111111-2222-3333-4444-555555555555\n"
        val r2 = CollectionCsv.read(manabox)!!
        assertEquals(4, r2[0].quantity)
        assertEquals(Finish.NONFOIL, r2[0].finish)
        assertEquals("11111111-2222-3333-4444-555555555555", r2[0].scryfallId)

        assertNull(CollectionCsv.read("4 Lightning Bolt\n2 Shock"))
        assertEquals(listOf(listOf("a", "b,c", "d\"e")), Csv.parse("a,\"b,c\",\"d\"\"e\""))
    }

    @Test
    fun quickNotesFindClassicInteractions() {
        val dt = card("Deathtouch Guy", typeLine = "Creature — Snake", oracle = "Deathtouch", keywords = listOf("Deathtouch"))
        val tr = card("Trample Boots", typeLine = "Artifact — Equipment", oracle = "Equipped creature has trample.\nEquip {1}", keywords = listOf("Equip"))
        val notes = QuickNotes.analyze(listOf(dt, tr))
        assertTrue(notes.any { it.title == "Deathtouch + trample" })

        val persist = card("Kitchen Finks", typeLine = "Creature — Ouphe", oracle = "When this creature enters, you gain 2 life.\nPersist", keywords = listOf("Persist"))
        val plus = card("Solemnity Lite", typeLine = "Enchantment", oracle = "Put a +1/+1 counter on target creature.")
        assertTrue(QuickNotes.analyze(listOf(persist, plus)).any { it.title == "Persist loop" })

        val vanilla = card("Grizzly Bears", typeLine = "Creature — Bear")
        val vanilla2 = card("Hill Giant", typeLine = "Creature — Giant")
        assertTrue(QuickNotes.analyze(listOf(vanilla, vanilla2)).isEmpty())

        val reminders = QuickNotes.keywordReminders(listOf(dt, tr))
        assertEquals(listOf("Deathtouch", "Equip"), reminders.map { it.keyword })
    }

    @Test
    fun promptIncludesOracleAndRulings() {
        val bolt = card("Lightning Bolt", "{R}", 1.0, oracle = "Lightning Bolt deals 3 damage to any target.")
        val msg = InteractionPrompt.userMessage(
            listOf(bolt, card("Shock", "{R}", 1.0, oracle = "Shock deals 2 damage to any target.")),
            mapOf(bolt.oracleId to listOf(Ruling("wotc", "2020-01-01", "It can target a battle."))),
            "Opponent is at 5 life",
        )
        assertTrue(msg.startsWith("Explain how these 2 cards interact"))
        assertTrue(msg.contains("Oracle text:\nLightning Bolt deals 3 damage to any target."))
        assertTrue(msg.contains("- (2020-01-01) It can target a battle."))
        assertTrue(msg.contains("Additional context from the player:\nOpponent is at 5 life"))
    }

    @Test
    fun claudeRequestAndReply() {
        val body = ClaudeProtocol.requestBody("claude-sonnet-5-5", "sys", listOf(ChatTurn.user("hi"), ChatTurn.assistant("yo"), ChatTurn.user("more")), 1000)
        val o = Json.parseToJsonElement(body).jsonObject
        assertEquals("claude-sonnet-5-5", o["model"]!!.jsonPrimitive.content)
        assertEquals(1000, o["max_tokens"]!!.jsonPrimitive.content.toInt())
        assertEquals(3, o["messages"]!!.jsonArray.size)
        assertEquals("assistant", o["messages"]!!.jsonArray[1].jsonObject["role"]!!.jsonPrimitive.content)

        val reply = ClaudeProtocol.parseReply(
            """{"id":"msg_1","type":"message","role":"assistant","content":[
                {"type":"thinking","thinking":"hmm","signature":"x"},
                {"type":"text","text":"## Summary\nThey combo."}],
               "stop_reason":"end_turn","usage":{"input_tokens":1200,"output_tokens":300}}"""
        )
        assertEquals("## Summary\nThey combo.", reply.text)
        assertEquals(1200, reply.inputTokens)
        assertEquals(0.0024 + 0.003, ClaudeProtocol.estimateCostUsd("claude-sonnet-5-5", 1200, 300)!!, 1e-9)

        assertEquals(
            "Your Anthropic API key was rejected. Check it in Settings.",
            ClaudeProtocol.friendlyError(401, """{"type":"error","error":{"type":"authentication_error","message":"invalid x-api-key"}}"""),
        )
        assertEquals(
            "Your credit balance is too low.",
            ClaudeProtocol.friendlyError(400, """{"type":"error","error":{"type":"invalid_request_error","message":"Your credit balance is too low."}}"""),
        )
    }

    @Test
    fun markdown() {
        val blocks = MiniMarkdown.parse(
            """
            ## Summary
            They **combo** for *infinite* mana.

            - First
              continued
            - Second
            1. Step one
            ---
            > Note
            """.trimIndent()
        )
        assertEquals(MdBlock.Heading(2, "Summary"), blocks[0])
        assertEquals(MdBlock.Paragraph("They **combo** for *infinite* mana."), blocks[1])
        assertEquals(MdBlock.Bullet("First continued", 0), blocks[2])
        assertEquals(MdBlock.Numbered(1, "Step one", 0), blocks[4])
        assertEquals(MdBlock.Rule, blocks[5])
        assertEquals(MdBlock.Quote("Note"), blocks[6])

        assertEquals(
            listOf(MdSpan("They "), MdSpan("combo", bold = true), MdSpan(" for "), MdSpan("infinite", italic = true), MdSpan(" mana.")),
            MiniMarkdown.inline("They **combo** for *infinite* mana."),
        )
        assertEquals(listOf(MdSpan("2 * 3 and snake_case_name")), MiniMarkdown.inline("2 * 3 and snake_case_name"))
        assertEquals(listOf(MdSpan("Pay "), MdSpan("{T}", code = true)), MiniMarkdown.inline("Pay `{T}`"))
    }

    @Test
    fun formatting() {
        assertEquals("$1,234.50", Format.price(1234.5, Currency.USD))
        assertEquals("€0.05", Format.price(0.05, Currency.EUR))
        assertEquals("3.00 tix", Format.price(3.0, Currency.TIX))
        assertEquals("$12,346", Format.total(12345.67, Currency.USD))
        assertEquals("—", Format.price(null, Currency.USD))
    }
}
