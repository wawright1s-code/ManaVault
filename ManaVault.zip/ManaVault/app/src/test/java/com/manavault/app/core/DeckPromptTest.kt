package com.manavault.app.core

import com.manavault.app.core.Fixtures.card
import com.manavault.app.core.deck.Board
import com.manavault.app.core.deck.DeckAnalysis
import com.manavault.app.core.deck.DeckCardEntry
import com.manavault.app.core.deck.DeckPrompt
import com.manavault.app.core.deck.Formats
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DeckPromptTest {

    @Test
    fun includesListOracleAndFocus() {
        val legal = mapOf("commander" to "legal")
        val entries = listOf(
            DeckCardEntry(card("Krenko, Mob Boss", "{2}{R}{R}", 4.0, "Legendary Creature — Goblin Warrior", "{T}: Create X 1/1 red Goblin creature tokens, where X is the number of Goblins you control.", identity = listOf("R"), legal = legal), 1, Board.COMMANDER),
            DeckCardEntry(card("Skirk Prospector", "{R}", 1.0, "Creature — Goblin", "Sacrifice a Goblin: Add {R}.", identity = listOf("R"), legal = legal), 1, Board.MAIN),
            DeckCardEntry(card("Mountain", typeLine = "Basic Land — Mountain", oracle = "({T}: Add {R}.)", identity = listOf("R"), legal = legal), 30, Board.MAIN),
            DeckCardEntry(card("Long Card", "{3}", 3.0, "Artifact", "x".repeat(400), legal = legal), 1, Board.MAIN),
            DeckCardEntry(card("Maybe Card", legal = legal), 1, Board.MAYBE),
        )
        val issues = DeckAnalysis.checkLegality(Formats.COMMANDER, entries)
        val msg = DeckPrompt.userMessage("Goblins!", Formats.COMMANDER, entries, issues, "more card draw")
        assertTrue(msg.startsWith("Analyze my deck \"Goblins!\" for Commander."))
        assertTrue(msg.contains("## Commander\n1x Krenko, Mob Boss {2}{R}{R} — Legendary Creature — Goblin Warrior"))
        assertTrue(msg.contains("1x Skirk Prospector {R} — Creature — Goblin — Sacrifice a Goblin: Add {R}."))
        // basic lands are listed by name only
        assertTrue(msg.contains("\n30x Mountain\n"))
        assertFalse(msg.contains("30x Mountain —"))
        // long rules text is truncated
        assertTrue(msg.contains("x".repeat(240) + "…"))
        assertFalse(msg.contains("x".repeat(241)))
        assertTrue(msg.contains("## Cards I'm considering\nMaybe Card"))
        assertTrue(msg.contains("exactly 100")) // legality problem is passed along
        assertTrue(msg.trimEnd().endsWith("What I'd especially like help with: more card draw"))
    }
}
