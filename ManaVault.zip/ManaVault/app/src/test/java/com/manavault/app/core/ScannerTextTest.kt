package com.manavault.app.core

import com.manavault.app.core.mana.ManaSymbols
import com.manavault.app.core.mana.TextSegment
import com.manavault.app.core.scan.CardTextExtractor
import com.manavault.app.core.scan.OcrLine
import com.manavault.app.core.scan.ScanStabilizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ScannerTextTest {

    private fun line(text: String, top: Int, height: Int = 20, left: Int = 40) = OcrLine(text, left, top, left + 400, top + height)

    @Test
    fun readsNameSetAndNumberFromModernCard() {
        val lines = listOf(
            line("Lightning Bolt", 10, height = 34),
            line("Instant", 380, height = 26),
            line("Lightning Bolt deals 3 damage to any target.", 430),
            line("The sparkmage shrieked, calling on the rage of the storms of his youth.", 470),
            line("0146/0280 C", 640, height = 12),
            line("M10 • EN Christopher Moeller", 655, height = 12),
            line("TM & © 2009 Wizards of the Coast", 655, height = 12, left = 300),
        )
        val r = CardTextExtractor.extract(lines)
        assertEquals("Lightning Bolt", r.bestName)
        assertEquals("m10", r.setCode)
        assertEquals("146", r.collectorNumber)
        assertTrue(r.hasPrintingInfo)
    }

    @Test
    fun readsNewStyleCollectorLine() {
        val lines = listOf(
            line("Sheoldred, the Apocalypse", 10, height = 30),
            line("Legendary Creature — Phyrexian Praetor", 380, height = 24),
            line("Deathtouch", 420),
            line("R 0107", 640, height = 12),
            line("DMU • EN", 655, height = 12),
        )
        val r = CardTextExtractor.extract(lines)
        assertEquals("Sheoldred, the Apocalypse", r.bestName)
        assertEquals("dmu", r.setCode)
        assertEquals("107", r.collectorNumber)
    }

    @Test
    fun stripsMisreadManaCostFromName() {
        assertEquals("Serra Angel", CardTextExtractor.cleanName("Serra Angel 3WW"))
        assertEquals("Llanowar Elves", CardTextExtractor.cleanName("Llanowar Elves @"))
        assertEquals("Jace, the Mind Sculptor", CardTextExtractor.cleanName("Jace, the Mind Sculptor 2UU"))
        assertNull(CardTextExtractor.cleanName("Creature — Elf Druid"))
        assertNull(CardTextExtractor.cleanName("Legendary Artifact"))
        assertNull(CardTextExtractor.cleanName("© 2024 Wizards of the Coast"))
        assertNull(CardTextExtractor.cleanName("{T}: Add {G}. This ability can only be activated"))
        assertNull(CardTextExtractor.cleanName("12"))
    }

    @Test
    fun ignoresTypeLineAndSmallTextForName() {
        val lines = listOf(
            line("Grizzly Bears 1G", 12, height = 32),
            line("Creature — Bear", 360, height = 24),
            line("2/2", 600, height = 22, left = 380),
        )
        assertEquals(listOf("Grizzly Bears"), CardTextExtractor.extract(lines).nameCandidates)
    }

    @Test
    fun noPrintingInfoOnOldCards() {
        val lines = listOf(line("Counterspell", 10, 32), line("Instant", 380), line("Counter target spell.", 420), line("Illus. Mark Poole", 650, 12))
        val r = CardTextExtractor.extract(lines)
        assertEquals("Counterspell", r.bestName)
        assertFalse(r.hasPrintingInfo)
    }

    @Test
    fun matchesNamesTolerantly() {
        assertTrue(CardTextExtractor.nameMatches("Lightnmg Bolt", "Lightning Bolt"))
        assertTrue(CardTextExtractor.nameMatches("Delver of Secrets", "Delver of Secrets // Insectile Aberration"))
        assertFalse(CardTextExtractor.nameMatches("Counterspell", "Lightning Bolt"))
        assertEquals("7a", CardTextExtractor.normalizeNumber("0007a"))
        assertEquals("0", CardTextExtractor.normalizeNumber("000"))
    }

    @Test
    fun stabilizerNeedsRepeatedReads() {
        val s = ScanStabilizer(window = 4, required = 2)
        assertNull(s.offer("Lightning Bolt"))
        assertNull(s.offer("Lightnlng Bolt"))
        assertEquals("Lightning Bolt", s.offer("Lightning Bolt"))
        s.reset()
        assertNull(s.offer(null))
        assertNull(s.offer("Shock"))
    }

    @Test
    fun guideFiltersTextOutsideTheCard() {
        // Portrait phone view 1080x2000 showing an upright 1440x1920 camera image (fill-center).
        val inside = OcrLine("Lightning Bolt", 600, 880, 840, 920)
        val outside = OcrLine("Table text", 10, 40, 90, 60)
        val kept = com.manavault.app.core.scan.ScanGeometry.linesInGuide(listOf(inside, outside), 1440, 1920, 1080, 2000)
        assertEquals(listOf(inside), kept)
        val g = com.manavault.app.core.scan.ScanGeometry.guide(1080f, 2000f)
        assertEquals(com.manavault.app.core.scan.ScanGeometry.CARD_ASPECT, g.width / g.height, 0.001f)
    }

    @Test
    fun manaSymbols() {
        assertEquals(listOf("2", "W/U", "G"), ManaSymbols.parse("{2}{W/U}{G}"))
        assertEquals("https://svgs.scryfall.io/card-symbols/WU.svg", ManaSymbols.svgUrl("W/U"))
        assertEquals("https://svgs.scryfall.io/card-symbols/T.svg", ManaSymbols.svgUrl("T"))
        assertEquals(mapOf("W" to 2, "U" to 1), ManaSymbols.colorPips("{1}{W}{W/U}"))
        val segs = ManaSymbols.segments("{T}: Add {G}.")
        assertEquals(listOf(TextSegment.Symbol("T"), TextSegment.Plain(": Add "), TextSegment.Symbol("G"), TextSegment.Plain(".")), segs)
        assertEquals("Esper", ManaSymbols.identityName(listOf("B", "W", "U")))
        assertEquals("{W}{U}{B}", ManaSymbols.identityCost(listOf("B", "U", "W")))
    }
}
