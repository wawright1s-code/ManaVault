package com.manavault.app.core

import com.manavault.app.core.model.Currency
import com.manavault.app.core.model.Finish
import com.manavault.app.core.scryfall.ScryfallJson
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ScryfallJsonTest {

    @Test
    fun parsesNormalCard() {
        val c = ScryfallJson.parseCard(Fixtures.LIGHTNING_BOLT_JSON)
        assertEquals("Lightning Bolt", c.name)
        assertEquals("{R}", c.manaCost)
        assertEquals(1.0, c.cmc, 0.0)
        assertEquals("Instant", c.typeLine)
        assertEquals("m10", c.setCode)
        assertEquals("146", c.collectorNumber)
        assertEquals(listOf("R"), c.colorIdentity)
        assertEquals("legal", c.legalityIn("modern"))
        assertEquals("not_legal", c.legalityIn("standard"))
        assertEquals(2.15, c.prices.usd!!, 0.001)
        assertEquals(9.99, c.price(Finish.FOIL, Currency.USD)!!, 0.001)
        assertNull(c.prices.usdEtched)
        assertEquals(0.03, c.price(Finish.NONFOIL, Currency.TIX)!!, 0.001)
        assertEquals("https://cards.scryfall.io/normal/front/e/3/e3285e6b.jpg", c.frontImage)
        assertEquals(listOf(Finish.NONFOIL, Finish.FOIL), c.availableFinishes)
        assertFalse(c.hasBackImage)
        assertTrue(c.tcgplayerUri!!.startsWith("https://"))
    }

    @Test
    fun parsesTransformCard() {
        val c = ScryfallJson.parseCard(Fixtures.DELVER_JSON)
        assertEquals("Delver of Secrets // Insectile Aberration", c.name)
        assertEquals(2, c.faces.size)
        assertTrue(c.hasBackImage)
        assertEquals("Delver of Secrets", c.frontName)
        assertEquals("{U}", c.displayManaCost)
        assertEquals("https://cards.scryfall.io/normal/front/1/1/delver.jpg", c.frontImage)
        assertTrue(c.allOracleText.contains("Flying"))
        assertTrue(c.allOracleText.contains("look at the top card"))
        assertEquals(listOf("U"), c.colors)
        assertTrue(c.isCreature)
    }

    @Test
    fun encodeThenParseRoundTrips() {
        for (src in listOf(Fixtures.LIGHTNING_BOLT_JSON, Fixtures.DELVER_JSON)) {
            val original = ScryfallJson.parseCard(src)
            val again = ScryfallJson.parseCard(ScryfallJson.encodeCard(original))
            assertEquals(original, again)
        }
    }

    @Test
    fun parsesListAndCollection() {
        val page = ScryfallJson.parseList(
            """{"object":"list","total_cards":2,"has_more":true,"next_page":"https://api.scryfall.com/cards/search?page=2",
               "data":[${Fixtures.LIGHTNING_BOLT_JSON},${Fixtures.DELVER_JSON}]}"""
        )
        assertEquals(2, page.cards.size)
        assertTrue(page.hasMore)
        assertEquals("https://api.scryfall.com/cards/search?page=2", page.nextPage)

        val col = ScryfallJson.parseCollection(
            ScryfallJson.parseObject("""{"object":"list","not_found":[{"name":"Nope"}],"data":[${Fixtures.LIGHTNING_BOLT_JSON}]}""")
        )
        assertEquals(1, col.found.size)
        assertEquals(1, col.notFound.size)
    }

    @Test
    fun parsesErrorsAndRulings() {
        val err = ScryfallJson.parseError("""{"object":"error","code":"not_found","status":404,"details":"No cards found"}""", 404)
        assertEquals("not_found", err.code)
        assertEquals("No cards found", err.details)
        val garbage = ScryfallJson.parseError("<html>", 503)
        assertEquals(503, garbage.status)

        val rulings = ScryfallJson.parseRulings(
            ScryfallJson.parseObject("""{"object":"list","has_more":false,"data":[
              {"object":"ruling","oracle_id":"x","source":"wotc","published_at":"2019-05-03","comment":"It works."}]}""")
        )
        assertEquals(1, rulings.size)
        assertEquals("2019-05-03", rulings[0].publishedAt)
    }

    @Test
    fun etchedFallsBackToFoilPrice() {
        val c = Fixtures.card("Sol Ring", prices = com.manavault.app.core.model.Prices(usd = 1.0, usdFoil = 5.0), finishes = listOf("nonfoil", "foil", "etched"))
        assertEquals(5.0, c.price(Finish.ETCHED, Currency.USD)!!, 0.0)
        // A foil entry of a nonfoil-only card is valued at the nonfoil price rather than nothing.
        val nonfoilOnly = Fixtures.card("Bolt", prices = com.manavault.app.core.model.Prices(usd = 1.5), finishes = listOf("nonfoil"))
        assertEquals(1.5, nonfoilOnly.priceOrFallback(Finish.FOIL, Currency.USD)!!, 0.0)
    }
}
