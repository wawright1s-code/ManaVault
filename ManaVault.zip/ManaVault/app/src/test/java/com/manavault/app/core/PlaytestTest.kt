package com.manavault.app.core

import com.manavault.app.core.Fixtures.card
import com.manavault.app.core.deck.Board
import com.manavault.app.core.deck.DeckCardEntry
import com.manavault.app.core.deck.DeckOdds
import com.manavault.app.core.deck.Playtest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class PlaytestTest {

    private val deck = listOf(
        DeckCardEntry(card("Mountain", typeLine = "Basic Land — Mountain"), 24, Board.MAIN),
        DeckCardEntry(card("Bolt"), 36, Board.MAIN),
        DeckCardEntry(card("Sideboard Card"), 15, Board.SIDE),
        DeckCardEntry(card("Commander Guy"), 1, Board.COMMANDER),
    )

    @Test
    fun dealsMulligansAndDraws() {
        val p = Playtest(deck, Random(42))
        assertEquals(60, p.deckSize)
        assertEquals(7, p.hand.size)
        assertEquals(53, p.library.size)
        assertEquals(60, (p.hand + p.library).map { it.id }.toSet().size)

        p.mulligan()
        assertEquals(1, p.mulligans)
        assertEquals(1, p.toBottom)
        assertEquals(7, p.hand.size)
        p.putOnBottom(p.hand.first())
        assertEquals(0, p.toBottom)
        assertEquals(6, p.hand.size)
        assertEquals(54, p.library.size)
        // can't bottom more than the mulligan count
        p.putOnBottom(p.hand.first())
        assertEquals(6, p.hand.size)

        val drawn = p.draw()!!
        assertEquals(1, p.turn)
        assertTrue(drawn in p.hand)
        assertEquals(53, p.library.size)

        p.newGame()
        assertEquals(0, p.mulligans)
        assertEquals(0, p.turn)
        repeat(53) { p.draw() }
        assertNull(p.draw())
    }

    @Test
    fun hypergeometricOdds() {
        val dist = DeckOdds.openingHandLands(60, 24)
        assertEquals(8, dist.size)
        assertEquals(1.0, dist.sum(), 1e-9)
        // C(36,7) / C(60,7)
        assertEquals(8_347_680.0 / 386_206_920.0, dist[0], 1e-9)
        assertEquals(1.0, DeckOdds.hitLandDrops(60, 60, 5), 1e-9)
        val t2 = DeckOdds.hitLandDrops(60, 24, 2)
        val t4 = DeckOdds.hitLandDrops(60, 24, 4)
        assertTrue(t2 > t4)
        assertTrue(t4 in 0.4..0.9)
        // on the draw you've seen one more card, so it's at least as likely
        assertTrue(DeckOdds.hitLandDrops(60, 24, 4, onThePlay = false) > t4)
    }
}
