package com.manavault.app.ui.interactions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.manavault.app.AppGraph
import com.manavault.app.core.interaction.ChatTurn
import com.manavault.app.core.interaction.ClaudeProtocol
import com.manavault.app.core.interaction.InteractionNote
import com.manavault.app.core.interaction.InteractionPrompt
import com.manavault.app.core.interaction.KeywordReminder
import com.manavault.app.core.interaction.QuickNotes
import com.manavault.app.core.model.Card
import com.manavault.app.core.model.Ruling
import com.manavault.app.data.repo.Settings
import com.manavault.app.ui.components.userMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class Usage(val model: String, val inputTokens: Int, val outputTokens: Int) {
    val costUsd: Double? get() = ClaudeProtocol.estimateCostUsd(model, inputTokens, outputTokens)
}

private data class LabState(
    val context: String = "",
    val loading: Boolean = false,
    val loadingLabel: String = "",
    val error: String? = null,
    /** The full conversation sent to Claude: first the generated card prompt, then follow-ups. */
    val thread: List<ChatTurn> = emptyList(),
    val explainedIds: Set<String> = emptySet(),
    val usage: Usage? = null,
    val rulings: Map<String, List<Ruling>> = emptyMap(),
    val freeModeShown: Boolean = false,
    val truncated: Boolean = false,
)

data class InteractionUi(
    val cards: List<Card> = emptyList(),
    val settings: Settings = Settings(),
    val context: String = "",
    val loading: Boolean = false,
    val loadingLabel: String = "",
    val error: String? = null,
    /** Visible conversation: the AI explanation and any follow-up questions/answers. */
    val answer: String? = null,
    val followUps: List<ChatTurn> = emptyList(),
    val stale: Boolean = false,
    val usage: Usage? = null,
    val notes: List<InteractionNote> = emptyList(),
    val reminders: List<KeywordReminder> = emptyList(),
    val rulings: Map<String, List<Ruling>> = emptyMap(),
    val showResults: Boolean = false,
    val truncated: Boolean = false,
)

class InteractionViewModel(private val graph: AppGraph) : ViewModel() {

    private val lab = MutableStateFlow(LabState())

    val ui: StateFlow<InteractionUi> = combine(graph.tray.cards, graph.settings.settings, lab) { cards, settings, s ->
        val ids = cards.map { it.id }.toSet()
        val answer = s.thread.getOrNull(1)?.text
        InteractionUi(
            cards = cards,
            settings = settings,
            context = s.context,
            loading = s.loading,
            loadingLabel = s.loadingLabel,
            error = s.error,
            answer = answer,
            followUps = if (s.thread.size > 2) s.thread.drop(2) else emptyList(),
            stale = (answer != null || s.freeModeShown) && ids != s.explainedIds,
            usage = s.usage,
            notes = QuickNotes.analyze(cards),
            reminders = QuickNotes.keywordReminders(cards),
            rulings = s.rulings,
            showResults = answer != null || s.freeModeShown,
            truncated = s.truncated,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), InteractionUi())

    fun setContext(text: String) = lab.update { it.copy(context = text) }

    fun remove(card: Card) = graph.tray.remove(card.id)

    fun add(card: Card) = graph.tray.add(card)

    fun clearAll() {
        graph.tray.clear()
        lab.value = LabState()
    }

    private suspend fun loadRulings(cards: List<Card>): Map<String, List<Ruling>> {
        val out = lab.value.rulings.toMutableMap()
        cards.filter { it.oracleId !in out }.forEachIndexed { i, card ->
            lab.update { it.copy(loadingLabel = "Fetching rulings (${i + 1}/${cards.size})…") }
            out[card.oracleId] = runCatching { graph.cards.rulings(card) }.getOrDefault(emptyList())
        }
        lab.update { it.copy(rulings = out) }
        return out
    }

    /** Explains the selected cards: with Claude if an API key is set, otherwise the offline rules notes. */
    fun explain() {
        val cards = graph.tray.cards.value
        if (cards.isEmpty() || lab.value.loading) return
        val settings = graph.settings.settings.value
        lab.update { it.copy(loading = true, error = null, loadingLabel = "Fetching rulings…") }
        viewModelScope.launch {
            try {
                val rulings = loadRulings(cards)
                if (!settings.hasApiKey) {
                    lab.update { it.copy(freeModeShown = true, thread = emptyList(), usage = null, explainedIds = cards.map { c -> c.id }.toSet()) }
                    return@launch
                }
                // Big selections: keep the prompt focused by sending Oracle text only.
                val truncated = cards.size > MAX_CARDS_WITH_RULINGS
                val prompt = InteractionPrompt.userMessage(cards, if (truncated) emptyMap() else rulings, lab.value.context)
                lab.update { it.copy(loadingLabel = "Asking Claude…") }
                val reply = graph.claude.send(settings.apiKey, settings.model, InteractionPrompt.SYSTEM, listOf(ChatTurn.user(prompt)))
                lab.update {
                    it.copy(
                        thread = listOf(ChatTurn.user(prompt), ChatTurn.assistant(reply.text + truncationNote(reply.stopReason))),
                        explainedIds = cards.map { c -> c.id }.toSet(),
                        usage = Usage(settings.model, reply.inputTokens, reply.outputTokens),
                        freeModeShown = true,
                        truncated = truncated,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lab.update { it.copy(error = e.userMessage(), freeModeShown = true, explainedIds = cards.map { c -> c.id }.toSet()) }
            } finally {
                lab.update { it.copy(loading = false, loadingLabel = "") }
            }
        }
    }

    fun askFollowUp(question: String) {
        val q = question.trim()
        val s = lab.value
        if (q.isEmpty() || s.loading || s.thread.size < 2) return
        val settings = graph.settings.settings.value
        val turns = s.thread + ChatTurn.user(q)
        lab.update { it.copy(thread = turns, loading = true, loadingLabel = "Thinking…", error = null) }
        viewModelScope.launch {
            try {
                val reply = graph.claude.send(settings.apiKey, settings.model, InteractionPrompt.SYSTEM, turns)
                lab.update {
                    val prev = it.usage
                    it.copy(
                        thread = turns + ChatTurn.assistant(reply.text + truncationNote(reply.stopReason)),
                        usage = Usage(settings.model, (prev?.inputTokens ?: 0) + reply.inputTokens, (prev?.outputTokens ?: 0) + reply.outputTokens),
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Drop the unanswered question so the conversation stays valid (user/assistant alternating).
                lab.update { it.copy(thread = s.thread, error = e.userMessage()) }
            } finally {
                lab.update { it.copy(loading = false, loadingLabel = "") }
            }
        }
    }

    private fun truncationNote(stopReason: String?) =
        if (stopReason == "max_tokens") "\n\n*(Answer cut off — ask a follow-up to continue.)*" else ""

    fun dismissError() = lab.update { it.copy(error = null) }

    private companion object {
        const val MAX_CARDS_WITH_RULINGS = 12
    }
}
