package com.manavault.app.core.scryfall

import com.manavault.app.core.model.Card
import com.manavault.app.core.model.CardFace
import com.manavault.app.core.model.Prices
import com.manavault.app.core.model.Ruling
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put

data class CardPage(
    val cards: List<Card>,
    val totalCards: Int,
    val hasMore: Boolean,
    val nextPage: String?,
)

data class CollectionResult(val found: List<Card>, val notFound: List<JsonObject>)

data class ScryfallError(val status: Int, val code: String, val details: String)

/**
 * Converts between Scryfall's JSON and the app's [Card] model.
 *
 * [encodeCard] writes a trimmed, Scryfall-shaped JSON document that [parseCard] reads back, so cached
 * cards in the local database use exactly the same parsing path as fresh API responses.
 */
object ScryfallJson {

    val json = Json { ignoreUnknownKeys = true; isLenient = true }

    fun parseObject(text: String): JsonObject = json.parseToJsonElement(text).jsonObject

    fun parseCard(text: String): Card = parseCard(parseObject(text))

    fun parseCard(o: JsonObject): Card {
        val faces = o.arr("card_faces")?.mapNotNull { (it as? JsonObject)?.let(::parseFace) }.orEmpty()
        val images = o.obj("image_uris")
        val prices = o.obj("prices")
        val purchase = o.obj("purchase_uris")
        val oracleId = o.str("oracle_id")
            ?: o.arr("card_faces")?.firstNotNullOfOrNull { (it as? JsonObject)?.str("oracle_id") }
            ?: o.str("id").orEmpty()
        return Card(
            id = o.str("id").orEmpty(),
            oracleId = oracleId,
            name = o.str("name").orEmpty(),
            lang = o.str("lang") ?: "en",
            layout = o.str("layout") ?: "normal",
            manaCost = o.str("mana_cost").orEmpty(),
            cmc = o.dbl("cmc") ?: 0.0,
            typeLine = o.str("type_line").orEmpty(),
            oracleText = o.str("oracle_text").orEmpty(),
            power = o.str("power"),
            toughness = o.str("toughness"),
            loyalty = o.str("loyalty"),
            defense = o.str("defense"),
            colors = o.strList("colors") ?: faces.flatMap { parseColorsFromCost(it.manaCost) }.distinct(),
            colorIdentity = o.strList("color_identity").orEmpty(),
            keywords = o.strList("keywords").orEmpty(),
            producedMana = o.strList("produced_mana").orEmpty(),
            legalities = o.obj("legalities")?.mapNotNull { (k, v) -> (v as? JsonPrimitive)?.contentOrNull?.let { k to it } }?.toMap().orEmpty(),
            setCode = o.str("set").orEmpty(),
            setName = o.str("set_name").orEmpty(),
            collectorNumber = o.str("collector_number").orEmpty(),
            rarity = o.str("rarity").orEmpty(),
            releasedAt = o.str("released_at").orEmpty(),
            artist = o.str("artist"),
            imageSmall = images?.str("small"),
            imageNormal = images?.str("normal"),
            imageLarge = images?.str("large"),
            imageArtCrop = images?.str("art_crop"),
            faces = faces,
            prices = Prices(
                usd = prices?.priceOf("usd"),
                usdFoil = prices?.priceOf("usd_foil"),
                usdEtched = prices?.priceOf("usd_etched"),
                eur = prices?.priceOf("eur"),
                eurFoil = prices?.priceOf("eur_foil"),
                eurEtched = prices?.priceOf("eur_etched"),
                tix = prices?.priceOf("tix"),
            ),
            finishes = o.strList("finishes") ?: legacyFinishes(o),
            scryfallUri = o.str("scryfall_uri"),
            tcgplayerUri = purchase?.str("tcgplayer"),
            cardmarketUri = purchase?.str("cardmarket"),
            edhrecRank = o.int("edhrec_rank"),
            gameChanger = o.bool("game_changer") ?: false,
        )
    }

    private fun parseFace(f: JsonObject): CardFace {
        val images = f.obj("image_uris")
        return CardFace(
            name = f.str("name").orEmpty(),
            manaCost = f.str("mana_cost").orEmpty(),
            typeLine = f.str("type_line").orEmpty(),
            oracleText = f.str("oracle_text").orEmpty(),
            power = f.str("power"),
            toughness = f.str("toughness"),
            loyalty = f.str("loyalty"),
            defense = f.str("defense"),
            imageSmall = images?.str("small"),
            imageNormal = images?.str("normal"),
            imageLarge = images?.str("large"),
            imageArtCrop = images?.str("art_crop"),
        )
    }

    private fun legacyFinishes(o: JsonObject): List<String> = buildList {
        if (o.bool("nonfoil") != false) add("nonfoil")
        if (o.bool("foil") == true) add("foil")
    }

    private fun parseColorsFromCost(cost: String): List<String> =
        listOf("W", "U", "B", "R", "G").filter { c -> Regex("\\{[^}]*$c[^}]*\\}").containsMatchIn(cost) }

    fun parseList(text: String): CardPage = parseList(parseObject(text))

    fun parseList(o: JsonObject): CardPage {
        val cards = o.arr("data")?.mapNotNull { (it as? JsonObject)?.let(::parseCard) }.orEmpty()
        return CardPage(
            cards = cards,
            totalCards = o.int("total_cards") ?: cards.size,
            hasMore = o.bool("has_more") ?: false,
            nextPage = o.str("next_page"),
        )
    }

    fun parseCollection(o: JsonObject): CollectionResult = CollectionResult(
        found = o.arr("data")?.mapNotNull { (it as? JsonObject)?.let(::parseCard) }.orEmpty(),
        notFound = o.arr("not_found")?.mapNotNull { it as? JsonObject }.orEmpty(),
    )

    fun parseCatalog(o: JsonObject): List<String> =
        o.arr("data")?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull }.orEmpty()

    fun parseRulings(o: JsonObject): List<Ruling> =
        o.arr("data")?.mapNotNull { el ->
            val r = el as? JsonObject ?: return@mapNotNull null
            Ruling(
                source = r.str("source").orEmpty(),
                publishedAt = r.str("published_at").orEmpty(),
                comment = r.str("comment").orEmpty(),
            )
        }.orEmpty()

    fun parseError(text: String, httpStatus: Int): ScryfallError = try {
        val o = parseObject(text)
        ScryfallError(o.int("status") ?: httpStatus, o.str("code") ?: "error", o.str("details") ?: "Scryfall returned HTTP $httpStatus")
    } catch (e: Exception) {
        ScryfallError(httpStatus, "error", "Scryfall returned HTTP $httpStatus")
    }

    /** Writes the subset of fields [parseCard] understands, in Scryfall's own shape. */
    fun encodeCard(c: Card): String = buildJsonObject {
        put("object", "card")
        put("id", c.id)
        put("oracle_id", c.oracleId)
        put("name", c.name)
        put("lang", c.lang)
        put("layout", c.layout)
        put("mana_cost", c.manaCost)
        put("cmc", c.cmc)
        put("type_line", c.typeLine)
        put("oracle_text", c.oracleText)
        c.power?.let { put("power", it) }
        c.toughness?.let { put("toughness", it) }
        c.loyalty?.let { put("loyalty", it) }
        c.defense?.let { put("defense", it) }
        put("colors", strArray(c.colors))
        put("color_identity", strArray(c.colorIdentity))
        put("keywords", strArray(c.keywords))
        put("produced_mana", strArray(c.producedMana))
        put("legalities", buildJsonObject { c.legalities.forEach { (k, v) -> put(k, v) } })
        put("set", c.setCode)
        put("set_name", c.setName)
        put("collector_number", c.collectorNumber)
        put("rarity", c.rarity)
        put("released_at", c.releasedAt)
        c.artist?.let { put("artist", it) }
        if (c.imageNormal != null || c.imageSmall != null) {
            put("image_uris", images(c.imageSmall, c.imageNormal, c.imageLarge, c.imageArtCrop))
        }
        if (c.faces.isNotEmpty()) {
            put("card_faces", buildJsonArray {
                c.faces.forEach { f ->
                    add(buildJsonObject {
                        put("name", f.name)
                        put("mana_cost", f.manaCost)
                        put("type_line", f.typeLine)
                        put("oracle_text", f.oracleText)
                        f.power?.let { put("power", it) }
                        f.toughness?.let { put("toughness", it) }
                        f.loyalty?.let { put("loyalty", it) }
                        f.defense?.let { put("defense", it) }
                        if (f.imageNormal != null || f.imageSmall != null) {
                            put("image_uris", images(f.imageSmall, f.imageNormal, f.imageLarge, f.imageArtCrop))
                        }
                    })
                }
            })
        }
        put("prices", buildJsonObject {
            putPrice("usd", c.prices.usd)
            putPrice("usd_foil", c.prices.usdFoil)
            putPrice("usd_etched", c.prices.usdEtched)
            putPrice("eur", c.prices.eur)
            putPrice("eur_foil", c.prices.eurFoil)
            putPrice("eur_etched", c.prices.eurEtched)
            putPrice("tix", c.prices.tix)
        })
        put("finishes", strArray(c.finishes))
        c.scryfallUri?.let { put("scryfall_uri", it) }
        if (c.tcgplayerUri != null || c.cardmarketUri != null) {
            put("purchase_uris", buildJsonObject {
                c.tcgplayerUri?.let { put("tcgplayer", it) }
                c.cardmarketUri?.let { put("cardmarket", it) }
            })
        }
        c.edhrecRank?.let { put("edhrec_rank", it) }
        if (c.gameChanger) put("game_changer", true)
    }.toString()

    private fun images(small: String?, normal: String?, large: String?, art: String?) = buildJsonObject {
        small?.let { put("small", it) }
        normal?.let { put("normal", it) }
        large?.let { put("large", it) }
        art?.let { put("art_crop", it) }
    }

    private fun strArray(values: List<String>): JsonArray = buildJsonArray { values.forEach { add(JsonPrimitive(it)) } }

    private fun kotlinx.serialization.json.JsonObjectBuilder.putPrice(key: String, value: Double?) {
        // Scryfall sends prices as decimal strings; keep that shape.
        put(key, value?.let { JsonPrimitive(formatPrice(it)) } ?: kotlinx.serialization.json.JsonNull)
    }

    private fun formatPrice(v: Double): String = String.format(java.util.Locale.US, "%.2f", v)
}

// ---- small JsonObject helpers -------------------------------------------------------------

internal fun JsonObject.prim(key: String): JsonPrimitive? = this[key] as? JsonPrimitive
internal fun JsonObject.str(key: String): String? = prim(key)?.contentOrNull
internal fun JsonObject.dbl(key: String): Double? = prim(key)?.let { it.doubleOrNull ?: it.contentOrNull?.toDoubleOrNull() }
internal fun JsonObject.int(key: String): Int? = prim(key)?.let { it.intOrNull ?: it.contentOrNull?.toDoubleOrNull()?.toInt() }
internal fun JsonObject.bool(key: String): Boolean? = prim(key)?.booleanOrNull
internal fun JsonObject.obj(key: String): JsonObject? = this[key] as? JsonObject
internal fun JsonObject.arr(key: String): JsonArray? = this[key] as? JsonArray
internal fun JsonObject.strList(key: String): List<String>? =
    arr(key)?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull }

private fun JsonObject.priceOf(key: String): Double? = str(key)?.toDoubleOrNull()
