package com.manavault.app.core.deck

import com.manavault.app.core.model.Card

enum class Board(val key: String, val label: String) {
    COMMANDER("commander", "Commander"),
    MAIN("main", "Main deck"),
    SIDE("side", "Sideboard"),
    MAYBE("maybe", "Maybeboard");

    companion object {
        fun fromKey(key: String?): Board = entries.firstOrNull { it.key == key } ?: MAIN
    }
}

/** One parsed line of a pasted deck list. */
data class DeckLine(
    val quantity: Int,
    val name: String,
    val setCode: String? = null,
    val collectorNumber: String? = null,
    val board: Board = Board.MAIN,
    val foil: Boolean = false,
)

data class ExportEntry(
    val quantity: Int,
    val name: String,
    val setCode: String?,
    val collectorNumber: String?,
    val board: Board,
)

/**
 * Reads and writes the common text deck formats: MTG Arena ("Deck"/"Sideboard" headers,
 * "4 Name (SET) 123"), MTGO ("SB: 2 Name"), Moxfield/Archidekt exports and plain "4x Name" lists.
 */
object DeckListFormat {

    private val QTY_LINE = Regex("^(\\d{1,3})\\s*[xX]?\\s+(.+)$")
    private val SET_PAREN = Regex("\\s+\\(([A-Za-z0-9]{2,6})\\)(?:\\s+([A-Za-z0-9★\\-]+))?\\s*$")
    private val SET_BRACKET = Regex("\\s+\\[([A-Za-z0-9]{2,6})(?::([A-Za-z0-9★\\-]+))?\\]\\s*$")
    private val FOIL_MARK = Regex("\\s+\\*(F|E|FOIL|ETCHED)\\*", RegexOption.IGNORE_CASE)
    private val TRAILING_TAGS = Regex("(\\s+(#\\S+|\\^[^^]+\\^))+\\s*$")
    private val SLASHES = Regex("\\s*/{1,2}\\s*")
    private val HEADER = Regex(
        "^(?://\\s*)?(commander|commanders|deck|main|maindeck|mainboard|main deck|sideboard|side|maybeboard|maybe|considering|companion|about)\\b[^\\p{L}]*$",
        RegexOption.IGNORE_CASE,
    )

    fun parse(text: String): List<DeckLine> {
        data class Raw(val line: DeckLine, val group: Int, val explicitBoard: Boolean)

        val raws = mutableListOf<Raw>()
        var board = Board.MAIN
        var sawHeader = false
        var inAbout = false
        var group = 0
        var lastWasBlank = false

        for (rawLine in text.lines()) {
            val line = rawLine.trim()
            if (line.isEmpty()) {
                if (!lastWasBlank && raws.isNotEmpty()) group++
                lastWasBlank = true
                continue
            }
            lastWasBlank = false

            val header = HEADER.find(line)
            if (header != null) {
                sawHeader = true
                inAbout = false
                board = when (header.groupValues[1].lowercase()) {
                    "commander", "commanders" -> Board.COMMANDER
                    "sideboard", "side", "companion" -> Board.SIDE
                    "maybeboard", "maybe", "considering" -> Board.MAYBE
                    "about" -> { inAbout = true; board }
                    else -> Board.MAIN
                }
                continue
            }
            if (inAbout) continue
            if (line.startsWith("//") || line.startsWith("#")) continue

            var body = line
            var lineBoard = board
            var explicit = sawHeader
            if (body.startsWith("SB:", ignoreCase = true)) {
                body = body.substring(3).trim()
                lineBoard = Board.SIDE
                explicit = true
            }
            val parsed = parseCardLine(body) ?: continue
            raws += Raw(parsed.copy(board = lineBoard), group, explicit)
        }

        if (sawHeader || raws.any { it.explicitBoard }) return raws.map { it.line }

        // No headers: infer from blank-line groups (MTG Arena / MTGO put the sideboard after a blank line).
        val groups = raws.groupBy { it.group }.values.toList()
        if (groups.size == 2) {
            val first = groups[0].sumOf { it.line.quantity }
            val second = groups[1].sumOf { it.line.quantity }
            if (first >= 40 && second <= 15) {
                return groups[0].map { it.line } + groups[1].map { it.line.copy(board = Board.SIDE) }
            }
            if (first <= 2 && second >= 58) {
                return groups[0].map { it.line.copy(board = Board.COMMANDER) } + groups[1].map { it.line }
            }
        }
        return raws.map { it.line }
    }

    /** Parses "4x Lightning Bolt (M10) 146 *F*" style lines. Returns null for blank input. */
    fun parseCardLine(input: String): DeckLine? {
        var s = input.trim()
        if (s.isEmpty()) return null
        var qty = 1
        QTY_LINE.find(s)?.let { m ->
            qty = m.groupValues[1].toInt()
            s = m.groupValues[2].trim()
        }
        var foil = false
        FOIL_MARK.find(s)?.let { foil = true; s = s.replace(FOIL_MARK, "") }
        s = s.replace(TRAILING_TAGS, "")
        var set: String? = null
        var number: String? = null
        (SET_PAREN.find(s) ?: SET_BRACKET.find(s))?.let { m ->
            set = m.groupValues[1].lowercase()
            number = m.groupValues.getOrNull(2)?.takeIf { it.isNotBlank() }
            s = s.substring(0, m.range.first)
        }
        val trimmed = s.trim()
        // Normalise "Fire/Ice" and "Fire // Ice" to Scryfall's " // " separator.
        val name = if (trimmed.contains('/')) {
            trimmed.split(SLASHES).filter { it.isNotBlank() }.joinToString(" // ")
        } else trimmed
        if (name.isEmpty() || qty <= 0) return null
        return DeckLine(qty, name, set, number, Board.MAIN, foil)
    }

    /** The name MTG Arena and most sites expect: full name for split cards, front face otherwise. */
    fun exportName(card: Card): String =
        if (card.layout == "split" || !card.name.contains(" // ")) card.name else card.frontName

    fun export(entries: List<ExportEntry>, includePrinting: Boolean = true): String {
        val sb = StringBuilder()
        val order = listOf(Board.COMMANDER, Board.MAIN, Board.SIDE, Board.MAYBE)
        for (board in order) {
            val cards = entries.filter { it.board == board && it.quantity > 0 }
            if (cards.isEmpty()) continue
            if (sb.isNotEmpty()) sb.append('\n')
            sb.append(
                when (board) {
                    Board.COMMANDER -> "Commander"
                    Board.MAIN -> "Deck"
                    Board.SIDE -> "Sideboard"
                    Board.MAYBE -> "Maybeboard"
                }
            ).append('\n')
            for (e in cards) {
                sb.append(e.quantity).append(' ').append(e.name)
                if (includePrinting && !e.setCode.isNullOrBlank()) {
                    sb.append(" (").append(e.setCode.uppercase()).append(')')
                    if (!e.collectorNumber.isNullOrBlank()) sb.append(' ').append(e.collectorNumber)
                }
                sb.append('\n')
            }
        }
        return sb.toString().trimEnd() + "\n"
    }
}
