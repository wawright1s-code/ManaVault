package com.manavault.app.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.manavault.app.BuildConfig
import com.manavault.app.core.interaction.ClaudeProtocol
import com.manavault.app.core.model.Condition
import com.manavault.app.core.model.Currency
import com.manavault.app.graph
import com.manavault.app.ui.Navigator
import com.manavault.app.ui.components.ScreenScaffold
import com.manavault.app.ui.components.SectionHeader
import com.manavault.app.ui.components.userMessage
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(nav: Navigator) {
    val graph = LocalContext.current.graph
    val settings by graph.settings.settings.collectAsStateWithLifecycle()
    val uri = LocalUriHandler.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var keyDraft by remember { mutableStateOf(settings.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    val presetIds = ClaudeProtocol.MODELS.map { it.id }
    var customModel by remember { mutableStateOf(if (settings.model in presetIds) "" else settings.model) }

    ScreenScaffold(title = "Settings", onBack = nav::back, snackbarHost = snackbar) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 40.dp),
        ) {
            SectionHeader("AI interaction explainer")
            Text(
                "The Interaction Lab uses Claude, Anthropic's AI model, through your own API key. You pay Anthropic directly — " +
                    "typically a cent or two per explanation. The key is stored only on this phone and sent only to api.anthropic.com.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = keyDraft,
                onValueChange = { keyDraft = it },
                label = { Text("Anthropic API key") },
                placeholder = { Text("sk-ant-…") },
                singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = { showKey = !showKey }) {
                        Icon(if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, if (showKey) "Hide key" else "Show key")
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = {
                    graph.settings.setApiKey(keyDraft)
                    scope.launch { snackbar.showSnackbar(if (keyDraft.isBlank()) "API key removed" else "API key saved") }
                }, enabled = keyDraft.trim() != settings.apiKey) { Text("Save key") }
                OutlinedButton(
                    enabled = !testing && keyDraft.isNotBlank(),
                    onClick = {
                        testing = true
                        scope.launch {
                            val result = runCatching { graph.claude.verifyKey(keyDraft, settings.model) }
                            testing = false
                            snackbar.showSnackbar(result.fold({ "The key works ✓" }, { it.userMessage() }))
                        }
                    },
                ) {
                    if (testing) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Text("Test")
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { uri.openUri("https://console.anthropic.com/settings/keys") }) { Text("Get a key") }
            }

            Spacer(Modifier.height(12.dp))
            Text("Model", style = MaterialTheme.typography.titleSmall)
            ClaudeProtocol.MODELS.forEach { m ->
                Row(
                    Modifier.fillMaxWidth().clickable { graph.settings.setModel(m.id); customModel = "" }.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = settings.model == m.id, onClick = { graph.settings.setModel(m.id); customModel = "" })
                    Column {
                        Text(m.label)
                        Text(m.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            OutlinedTextField(
                value = customModel,
                onValueChange = { customModel = it },
                label = { Text("Or a custom model ID") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                trailingIcon = {
                    TextButton(enabled = customModel.isNotBlank(), onClick = { graph.settings.setModel(customModel) }) { Text("Use") }
                },
            )

            SectionHeader("Prices")
            Text("Currency", style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Currency.entries.forEach { c ->
                    FilterChip(selected = settings.currency == c, onClick = { graph.settings.setCurrency(c) }, label = { Text(c.label) })
                }
            }
            Text(
                "USD prices come from TCGplayer, EUR from Cardmarket and Tix from Cardhoarder, all via Scryfall (updated once a day).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(10.dp))
            Text("Default condition for new cards", style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Condition.entries.forEach { c ->
                    FilterChip(selected = settings.defaultCondition == c, onClick = { graph.settings.setDefaultCondition(c) }, label = { Text(c.label) })
                }
            }

            DataSection(snackbar)

            SectionHeader("About")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                Column(Modifier.padding(14.dp)) {
                    Text("ManaVault ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Card data, images and prices are provided by Scryfall. ManaVault is unofficial Fan Content permitted under the " +
                            "Wizards of the Coast Fan Content Policy. Not approved or endorsed by Wizards. Portions of the materials used are " +
                            "property of Wizards of the Coast. ©Wizards of the Coast LLC.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row {
                        TextButton(onClick = { uri.openUri("https://scryfall.com") }) { Text("Scryfall") }
                        TextButton(onClick = { uri.openUri("https://company.wizards.com/en/legal/fancontentpolicy") }) { Text("Fan Content Policy") }
                    }
                }
            }
        }
    }
}
