package com.manavault.app.ui.collection

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.manavault.app.AppGraph
import com.manavault.app.core.model.Card
import com.manavault.app.core.model.Condition
import com.manavault.app.core.model.Currency
import com.manavault.app.core.model.Finish
import com.manavault.app.data.repo.ImportReport
import com.manavault.app.data.repo.OwnedCard
import com.manavault.app.ui.components.userMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class SortMode(val label: String) {
    VALUE("Value"),
    NAME("Name"),
    RECENT("Recently added"),
    SET("Set"),
    MANA("Mana value"),
}

/** Color filter chips: the five colors, colorless and multicolor. */
val COLOR_FILTERS = listOf("W", "U", "B", "R", "G", "C", "M")

private data class Controls(
    val query: String = "",
    val sort: SortMode = SortMode.VALUE,
    val colors: Set<String> = emptySet(),
    val selection: Set<Long> = emptySet(),
)

data class CollectionUi(
    val loaded: Boolean = false,
    val items: List<OwnedCard> = emptyList(),
    val totalValue: Double = 0.0,
    val totalCards: Int = 0,
    val uniqueCards: Int = 0,
    val currency: Currency = Currency.USD,
    val query: String = "",
    val sort: SortMode = SortMode.VALUE,
    val colors: Set<String> = emptySet(),
    val selection: Set<Long> = emptySet(),
    val history: List<Double> = emptyList(),
    val isEmpty: Boolean = true,
)

sealed interface CollectionTask {
    data class Running(val message: String) : CollectionTask
    data class ImportDone(val report: ImportReport) : CollectionTask
}

class CollectionViewModel(private val graph: AppGraph) : ViewModel() {

    private val controls = MutableStateFlow(Controls())
    val job = MutableStateFlow<CollectionTask?>(null)
    val messages = MutableStateFlow<String?>(null)
    val lastRefresh = MutableStateFlow(graph.settings.lastPriceRefresh)

    val ui: StateFlow<CollectionUi> = combine(
        graph.collection.owned,
        graph.settings.settings,
        controls,
        graph.collection.snapshots,
    ) { owned, settings, c, snapshots ->
        val currency = settings.currency
        val filtered = owned.filter { matches(it, c) }
        val sorted = when (c.sort) {
            SortMode.VALUE -> filtered.sortedByDescending { it.totalPrice(currency) }
            SortMode.NAME -> filtered.sortedBy { it.card.name }
            SortMode.RECENT -> filtered.sortedByDescending { it.addedAt }
            SortMode.SET -> filtered.sortedWith(compareBy<OwnedCard> { it.card.setName }.thenBy { it.card.collectorNumber.filter(Char::isDigit).toIntOrNull() ?: 0 })
            SortMode.MANA -> filtered.sortedWith(compareBy<OwnedCard> { it.card.cmc }.thenBy { it.card.name })
        }
        val history = snapshots.sortedBy { it.day }.map {
            when (currency) {
                Currency.USD -> it.usd
                Currency.EUR -> it.eur
                Currency.TIX -> it.tix
            }
        }
        CollectionUi(
            loaded = true,
            items = sorted,
            totalValue = owned.sumOf { it.totalPrice(currency) },
            totalCards = owned.sumOf { it.quantity },
            uniqueCards = owned.map { it.card.oracleId }.distinct().size,
            currency = currency,
            query = c.query,
            sort = c.sort,
            colors = c.colors,
            selection = c.selection.filter { id -> owned.any { it.entryId == id } }.toSet(),
            history = history,
            isEmpty = owned.isEmpty(),
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CollectionUi())

    init {
        // Scryfall updates prices once a day; refresh quietly if ours are older than that.
        viewModelScope.launch {
            delay(1_500)
            val owned = graph.collection.owned.first()
            if (owned.isNotEmpty() && System.currentTimeMillis() - graph.settings.lastPriceRefresh > 24 * 3600 * 1000L) {
                refreshPrices(quiet = true)
            }
        }
    }

    private fun matches(o: OwnedCard, c: Controls): Boolean {
        val q = c.query.trim()
        if (q.isNotEmpty()) {
            val hit = o.card.name.contains(q, true) || o.card.typeLine.contains(q, true) ||
                o.card.setCode.equals(q, true) || o.card.setName.contains(q, true)
            if (!hit) return false
        }
        if (c.colors.isNotEmpty()) {
            val identity = o.card.colorIdentity
            val ok = c.colors.any { f ->
                when (f) {
                    "C" -> identity.isEmpty()
                    "M" -> identity.size >= 2
                    else -> f in identity
                }
            }
            if (!ok) return false
        }
        return true
    }

    fun setQuery(q: String) = controls.update { it.copy(query = q) }
    fun setSort(s: SortMode) = controls.update { it.copy(sort = s) }
    fun toggleColor(c: String) = controls.update { it.copy(colors = if (c in it.colors) it.colors - c else it.colors + c) }
    fun toggleSelect(id: Long) = controls.update { it.copy(selection = if (id in it.selection) it.selection - id else it.selection + id) }
    fun selectAllVisible() = controls.update { it.copy(selection = ui.value.items.map { o -> o.entryId }.toSet()) }
    fun clearSelection() = controls.update { it.copy(selection = emptySet()) }

    fun selectedCards(): List<Card> {
        val sel = ui.value.selection
        return ui.value.items.filter { it.entryId in sel }.map { it.card }
    }

    fun deleteSelected() {
        val ids = ui.value.selection
        viewModelScope.launch {
            graph.collection.removeMany(ids)
            clearSelection()
            messages.value = "Removed ${ids.size} entr${if (ids.size == 1) "y" else "ies"}"
        }
    }

    fun setQuantity(entryId: Long, quantity: Int) = viewModelScope.launch { graph.collection.setQuantity(entryId, quantity) }

    fun edit(entryId: Long, card: Card, finish: Finish, condition: Condition, quantity: Int) =
        viewModelScope.launch { graph.collection.edit(entryId, card, finish, condition, quantity) }

    fun addCard(card: Card) = viewModelScope.launch {
        graph.collection.add(card)
        messages.value = "Added ${card.name}"
    }

    fun refreshPrices(quiet: Boolean = false) {
        if (job.value is CollectionTask.Running) return
        viewModelScope.launch {
            if (!quiet) job.value = CollectionTask.Running("Updating prices…")
            try {
                val n = graph.collection.refreshPrices { done, total ->
                    if (!quiet) job.value = CollectionTask.Running("Updating prices… $done / $total")
                }
                lastRefresh.value = graph.settings.lastPriceRefresh
                if (!quiet) messages.value = "Updated prices for $n cards"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (!quiet) messages.value = e.userMessage()
            } finally {
                if (!quiet && job.value is CollectionTask.Running) job.value = null
            }
        }
    }

    suspend fun exportCsv(): String = graph.collection.exportCsv()

    fun import(text: String) {
        viewModelScope.launch {
            job.value = CollectionTask.Running("Reading list…")
            try {
                val report = graph.collection.importText(text) { job.value = CollectionTask.Running(it) }
                job.value = CollectionTask.ImportDone(report)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                job.value = null
                messages.value = e.userMessage()
            }
        }
    }

    fun dismissJob() { job.value = null }
    fun messageShown() { messages.value = null }
}
