package com.manavault.app.ui.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material3.AssistChip
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.manavault.app.AppGraph
import com.manavault.app.core.model.Card
import com.manavault.app.core.scryfall.SearchFilters
import com.manavault.app.core.scryfall.SearchQueryBuilder
import com.manavault.app.core.text.Format
import com.manavault.app.graph
import com.manavault.app.ui.Navigator
import com.manavault.app.ui.components.CardImage
import com.manavault.app.ui.components.ScreenScaffold
import com.manavault.app.ui.components.userMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class SearchOrder(val key: String, val label: String) {
    NAME("name", "Name"),
    PRICE("usd", "Price (USD)"),
    RELEASED("released", "Release date"),
    MANA("cmc", "Mana value"),
    EDHREC("edhrec", "EDHREC popularity"),
}

data class SearchUi(
    val query: String = "",
    val submitted: String = "",
    val suggestions: List<String> = emptyList(),
    val results: List<Card> = emptyList(),
    val total: Int = 0,
    val nextPage: String? = null,
    val loading: Boolean = false,
    val error: String? = null,
    val allPrintings: Boolean = false,
    val order: SearchOrder = SearchOrder.NAME,
    val filters: SearchFilters = SearchFilters(),
    /** The full Scryfall query that was last run (typed text + filters). */
    val fullQuery: String = "",
)

class SearchViewModel(private val graph: AppGraph) : ViewModel() {
    private val _ui = MutableStateFlow(SearchUi())
    val ui: StateFlow<SearchUi> = _ui.asStateFlow()
    private var suggestJob: Job? = null
    private var searchJob: Job? = null

    fun onQueryChange(q: String) {
        _ui.update { it.copy(query = q) }
        suggestJob?.cancel()
        // Only suggest names for plain text; Scryfall syntax (t:, o:, ...) goes straight to search.
        if (q.length < 2 || q.contains(':') || q.contains('"')) {
            _ui.update { it.copy(suggestions = emptyList()) }
            return
        }
        suggestJob = viewModelScope.launch {
            delay(250)
            val s = runCatching { graph.cards.autocomplete(q) }.getOrDefault(emptyList())
            _ui.update { it.copy(suggestions = s.take(8)) }
        }
    }

    fun search(q: String = _ui.value.query) {
        val query = q.trim()
        val full = SearchQueryBuilder.build(query, _ui.value.filters, graph.settings.settings.value.currency)
        if (full.isEmpty()) return
        suggestJob?.cancel()
        searchJob?.cancel()
        _ui.update {
            it.copy(
                query = query, submitted = query.ifEmpty { " " }, fullQuery = full, suggestions = emptyList(),
                loading = true, error = null, results = emptyList(), total = 0,
            )
        }
        searchJob = viewModelScope.launch {
            try {
                val s = _ui.value
                val page = graph.cards.search(full, unique = if (s.allPrintings) "prints" else "cards", order = s.order.key)
                _ui.update {
                    it.copy(
                        results = page.cards, total = page.totalCards, nextPage = page.nextPage.takeIf { page.hasMore },
                        error = if (page.cards.isEmpty()) "No cards match these filters." else null,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(error = e.userMessage()) }
            } finally {
                _ui.update { it.copy(loading = false) }
            }
        }
    }

    fun loadMore() {
        val next = _ui.value.nextPage ?: return
        if (_ui.value.loading) return
        _ui.update { it.copy(loading = true) }
        viewModelScope.launch {
            try {
                val page = graph.cards.nextPage(next)
                _ui.update { it.copy(results = it.results + page.cards, nextPage = page.nextPage.takeIf { page.hasMore }) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(error = e.userMessage(), nextPage = null) }
            } finally {
                _ui.update { it.copy(loading = false) }
            }
        }
    }

    private fun rerun() {
        if (_ui.value.submitted.isNotEmpty()) search(_ui.value.submitted)
    }

    fun setAllPrintings(on: Boolean) {
        _ui.update { it.copy(allPrintings = on) }
        rerun()
    }

    fun setOrder(order: SearchOrder) {
        _ui.update { it.copy(order = order) }
        rerun()
    }

    /** Applies filters and runs the search, even when no text has been typed. */
    fun applyFilters(filters: SearchFilters) {
        _ui.update { it.copy(filters = filters) }
        if (filters.isEmpty && _ui.value.query.isBlank()) {
            _ui.update { SearchUi(allPrintings = it.allPrintings, order = it.order) }
        } else {
            search(_ui.value.query)
        }
    }

    fun clear() = _ui.update { SearchUi(allPrintings = it.allPrintings, order = it.order, filters = it.filters) }

    suspend fun random(): Card? = runCatching { graph.cards.random() }.getOrNull()
}

private val EXAMPLES = listOf(
    "t:dragon c:r" to "Red dragons",
    "o:\"draw a card\" mv<=2" to "Cheap card draw",
    "is:commander id:esper" to "Esper commanders",
    "f:modern usd>=20" to "Modern staples over \$20",
    "t:land o:\"any color\"" to "Lands that make any color",
    "kw:deathtouch t:creature mv<=3" to "Cheap deathtouchers",
)

@Composable
fun SearchScreen(nav: Navigator) {
    val graph = LocalContext.current.graph
    val vm: SearchViewModel = viewModel { SearchViewModel(graph) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val currency = graph.settings.settings.collectAsStateWithLifecycle().value.currency
    val focus = LocalFocusManager.current
    val gridState = rememberLazyGridState()
    var orderOpen by remember { mutableStateOf(false) }
    var filtersOpen by remember { mutableStateOf(false) }
    var rolling by remember { mutableStateOf(false) }

    val nearEnd by remember {
        derivedStateOf {
            val last = gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            last >= gridState.layoutInfo.totalItemsCount - 8
        }
    }
    LaunchedEffect(nearEnd, ui.results.size) { if (nearEnd && ui.nextPage != null) vm.loadMore() }
    LaunchedEffect(rolling) {
        if (rolling) {
            vm.random()?.let { nav.card(it.id) }
            rolling = false
        }
    }

    ScreenScaffold(
        title = "Search",
        actions = {
            IconButton(onClick = { rolling = true }) { Icon(Icons.Filled.Casino, "Random card") }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value = ui.query,
                onValueChange = vm::onQueryChange,
                placeholder = { Text("Name or Scryfall syntax") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (ui.query.isNotEmpty()) IconButton(onClick = vm::clear) { Icon(Icons.Filled.Close, "Clear") }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focus.clearFocus(); vm.search() }),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            )
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(
                    selected = !ui.filters.isEmpty,
                    onClick = { filtersOpen = true },
                    label = { Text(if (ui.filters.isEmpty) "Filters" else "Filters (${ui.filters.activeCount})") },
                    leadingIcon = { Icon(Icons.Filled.Tune, null, Modifier.size(18.dp)) },
                )
                FilterChip(selected = ui.allPrintings, onClick = { vm.setAllPrintings(!ui.allPrintings) }, label = { Text("All printings") })
                Box {
                    AssistChip(
                        onClick = { orderOpen = true },
                        label = { Text("Sort: ${ui.order.label}") },
                        leadingIcon = { Icon(Icons.AutoMirrored.Filled.Sort, null) },
                    )
                    DropdownMenu(expanded = orderOpen, onDismissRequest = { orderOpen = false }) {
                        SearchOrder.entries.forEach { o ->
                            DropdownMenuItem(text = { Text(o.label) }, onClick = { orderOpen = false; vm.setOrder(o) })
                        }
                    }
                }
            }
            if (ui.total > 0 || (ui.fullQuery.isNotEmpty() && !ui.filters.isEmpty)) {
                Text(
                    listOfNotNull(
                        ui.total.takeIf { it > 0 }?.let { "${Format.count(it)} cards" },
                        ui.fullQuery.takeIf { !ui.filters.isEmpty },
                    ).joinToString("  ·  "),
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp),
                )
            }
            if (ui.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 4.dp))

            when {
                ui.suggestions.isNotEmpty() && ui.query != ui.submitted -> LazyColumn {
                    items(ui.suggestions) { s ->
                        ListItem(
                            headlineContent = { Text(s) },
                            leadingContent = { Icon(Icons.Filled.Search, null) },
                            modifier = Modifier.clickable { focus.clearFocus(); vm.search("!\"$s\"") },
                        )
                        HorizontalDivider()
                    }
                }
                ui.submitted.isEmpty() -> SearchTips(onExample = { focus.clearFocus(); vm.search(it) })
                ui.error != null && ui.results.isEmpty() -> Text(ui.error!!, modifier = Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                else -> LazyVerticalGrid(
                    state = gridState,
                    columns = GridCells.Adaptive(150.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(ui.results, key = { it.id }) { card ->
                        Column(Modifier.clickable { nav.card(card.id) }) {
                            CardImage(card.frontImage, card.name, Modifier.fillMaxWidth())
                            Spacer(Modifier.height(4.dp))
                            Text(card.name, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Row {
                                Text(
                                    if (ui.allPrintings) "${card.setCode.uppercase()} #${card.collectorNumber}" else card.setCode.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.weight(1f),
                                )
                                Text(Format.price(card.price(card.defaultFinish, currency), currency), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    if (ui.nextPage != null) {
                        item(span = { GridItemSpan(maxLineSpan) }) { Spacer(Modifier.height(48.dp)) }
                    }
                }
            }
        }
    }

    if (filtersOpen) {
        FilterSheet(
            initial = ui.filters,
            currency = currency,
            onDismiss = { filtersOpen = false },
            onApply = { focus.clearFocus(); vm.applyFilters(it); filtersOpen = false },
        )
    }
}

@Composable
private fun SearchTips(onExample: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item {
            Text("Search every Magic card", style = MaterialTheme.typography.titleMedium)
            Text(
                "Type a name, or use Scryfall's search syntax for anything else. Try one:",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }
        items(EXAMPLES) { (q, label) ->
            ListItem(
                headlineContent = { Text(label) },
                supportingContent = { Text(q, fontFamily = FontFamily.Monospace) },
                modifier = Modifier.clickable { onExample(q) },
            )
        }
    }
}
