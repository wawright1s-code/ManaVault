package com.manavault.app.core.scan

data class Box(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    fun contains(x: Float, y: Float) = x in left..right && y in top..bottom
}

/**
 * Geometry shared by the scanner overlay and the OCR filter, so that only text inside the on-screen
 * card outline is used — text on the table or on neighbouring cards is ignored.
 */
object ScanGeometry {
    const val CARD_ASPECT = 488f / 680f

    /** The card-shaped guide, in view pixels. */
    fun guide(viewWidth: Float, viewHeight: Float): Box {
        var w = viewWidth * 0.78f
        var h = w / CARD_ASPECT
        val maxH = viewHeight * 0.66f
        if (h > maxH) {
            h = maxH
            w = h * CARD_ASPECT
        }
        val cx = viewWidth / 2f
        val cy = viewHeight * 0.44f
        return Box(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
    }

    /**
     * Maps the guide from view coordinates into the upright camera image, assuming the preview is
     * scaled to fill the view and centered (PreviewView's FILL_CENTER).
     */
    fun guideInImage(viewWidth: Float, viewHeight: Float, imageWidth: Float, imageHeight: Float, margin: Float = 0.08f): Box {
        val g = guide(viewWidth, viewHeight)
        val scale = maxOf(viewWidth / imageWidth, viewHeight / imageHeight)
        fun x(vx: Float) = (vx - viewWidth / 2f) / scale + imageWidth / 2f
        fun y(vy: Float) = (vy - viewHeight / 2f) / scale + imageHeight / 2f
        val mx = g.width * margin
        val my = g.height * margin
        return Box(x(g.left - mx), y(g.top - my), x(g.right + mx), y(g.bottom + my))
    }

    /** Keeps only lines whose center falls inside the (slightly enlarged) guide. */
    fun linesInGuide(
        lines: List<OcrLine>,
        imageWidth: Int,
        imageHeight: Int,
        viewWidth: Int,
        viewHeight: Int,
    ): List<OcrLine> {
        if (viewWidth <= 0 || viewHeight <= 0 || imageWidth <= 0 || imageHeight <= 0) return lines
        val box = guideInImage(viewWidth.toFloat(), viewHeight.toFloat(), imageWidth.toFloat(), imageHeight.toFloat())
        return lines.filter { box.contains((it.left + it.right) / 2f, (it.top + it.bottom) / 2f) }
    }
}
