package com.manavault.app.core.text

sealed interface MdBlock {
    data class Heading(val level: Int, val text: String) : MdBlock
    data class Paragraph(val text: String) : MdBlock
    data class Bullet(val text: String, val depth: Int) : MdBlock
    data class Numbered(val number: Int, val text: String, val depth: Int) : MdBlock
    data class Quote(val text: String) : MdBlock
    data class Code(val text: String) : MdBlock
    data object Rule : MdBlock
}

data class MdSpan(val text: String, val bold: Boolean = false, val italic: Boolean = false, val code: Boolean = false)

/** Just enough Markdown to render Claude's answers nicely: headings, lists, quotes, code, bold/italic/code spans. */
object MiniMarkdown {
    private val HEADING = Regex("^(#{1,6})\\s+(.*)$")
    private val BULLET = Regex("^(\\s*)[-*+•]\\s+(.*)$")
    private val NUMBERED = Regex("^(\\s*)(\\d{1,3})[.)]\\s+(.*)$")
    private val RULE = Regex("^\\s*([-*_])(\\s*\\1){2,}\\s*$")

    fun parse(markdown: String): List<MdBlock> {
        val out = mutableListOf<MdBlock>()
        val para = StringBuilder()
        fun flush() {
            if (para.isNotBlank()) out += MdBlock.Paragraph(para.toString().trim())
            para.setLength(0)
        }
        val lines = markdown.replace("\r\n", "\n").lines()
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            val trimmed = line.trim()
            when {
                trimmed.startsWith("```") -> {
                    flush()
                    val code = StringBuilder()
                    i++
                    while (i < lines.size && !lines[i].trim().startsWith("```")) {
                        code.append(lines[i]).append('\n')
                        i++
                    }
                    out += MdBlock.Code(code.toString().trimEnd())
                }
                trimmed.isEmpty() -> flush()
                RULE.matches(trimmed) -> { flush(); out += MdBlock.Rule }
                HEADING.matches(trimmed) -> {
                    flush()
                    val m = HEADING.find(trimmed)!!
                    out += MdBlock.Heading(m.groupValues[1].length, m.groupValues[2].trim().trimEnd('#').trim())
                }
                trimmed.startsWith(">") -> {
                    flush()
                    out += MdBlock.Quote(trimmed.removePrefix(">").trim())
                }
                BULLET.matches(line) -> {
                    flush()
                    val m = BULLET.find(line)!!
                    out += MdBlock.Bullet(m.groupValues[2].trim(), depth(m.groupValues[1]))
                }
                NUMBERED.matches(line) -> {
                    flush()
                    val m = NUMBERED.find(line)!!
                    out += MdBlock.Numbered(m.groupValues[2].toInt(), m.groupValues[3].trim(), depth(m.groupValues[1]))
                }
                else -> {
                    // Continuation of a list item (indented, directly after it) joins that item.
                    val last = out.lastOrNull()
                    if (para.isEmpty() && line.startsWith("  ") && (last is MdBlock.Bullet || last is MdBlock.Numbered)) {
                        out[out.lastIndex] = when (last) {
                            is MdBlock.Bullet -> last.copy(text = last.text + " " + trimmed)
                            is MdBlock.Numbered -> last.copy(text = last.text + " " + trimmed)
                            else -> last
                        }
                    } else {
                        if (para.isNotEmpty()) para.append(' ')
                        para.append(trimmed)
                    }
                }
            }
            i++
        }
        flush()
        return out
    }

    private fun depth(indent: String): Int = (indent.replace("\t", "    ").length / 2).coerceAtMost(3)

    /** Splits inline text into styled spans: **bold**, __bold__, *italic*, _italic_, `code`. */
    fun inline(text: String): List<MdSpan> {
        val spans = mutableListOf<MdSpan>()
        val buf = StringBuilder()
        var bold = false
        var italic = false
        var i = 0
        fun emit() {
            if (buf.isNotEmpty()) spans += MdSpan(buf.toString(), bold, italic)
            buf.setLength(0)
        }
        while (i < text.length) {
            val c = text[i]
            val next = text.getOrNull(i + 1)
            when {
                c == '`' -> {
                    val end = text.indexOf('`', i + 1)
                    if (end > i) {
                        emit()
                        spans += MdSpan(text.substring(i + 1, end), bold, italic, code = true)
                        i = end
                    } else buf.append(c)
                }
                (c == '*' && next == '*') || (c == '_' && next == '_') -> {
                    emit(); bold = !bold; i++
                }
                c == '*' && isDelimiter(text, i) -> { emit(); italic = !italic }
                c == '_' && isDelimiter(text, i) && !isWordChar(text.getOrNull(i - 1)) || (c == '_' && italic && !isWordChar(next)) -> {
                    emit(); italic = !italic
                }
                c == '\\' && next != null && next in "*_`\\" -> { buf.append(next); i++ }
                else -> buf.append(c)
            }
            i++
        }
        emit()
        return mergeAdjacent(spans)
    }

    private fun isWordChar(c: Char?) = c != null && c.isLetterOrDigit()

    // A single * or _ only toggles italics when it's next to non-space text (so "2 * 3" stays literal).
    private fun isDelimiter(text: String, i: Int): Boolean {
        val before = text.getOrNull(i - 1)
        val after = text.getOrNull(i + 1)
        val opens = after != null && !after.isWhitespace()
        val closes = before != null && !before.isWhitespace()
        return opens || closes
    }

    private fun mergeAdjacent(spans: List<MdSpan>): List<MdSpan> {
        val out = mutableListOf<MdSpan>()
        for (s in spans) {
            val last = out.lastOrNull()
            if (last != null && last.bold == s.bold && last.italic == s.italic && last.code == s.code && !s.code) {
                out[out.lastIndex] = last.copy(text = last.text + s.text)
            } else out += s
        }
        return out
    }

    /** Plain text with Markdown markers removed (for copying to the clipboard). */
    fun toPlainText(markdown: String): String = parse(markdown).joinToString("\n\n") { b ->
        when (b) {
            is MdBlock.Heading -> plain(b.text).uppercase()
            is MdBlock.Paragraph -> plain(b.text)
            is MdBlock.Bullet -> "  ".repeat(b.depth) + "• " + plain(b.text)
            is MdBlock.Numbered -> "  ".repeat(b.depth) + "${b.number}. " + plain(b.text)
            is MdBlock.Quote -> "\"" + plain(b.text) + "\""
            is MdBlock.Code -> b.text
            MdBlock.Rule -> "———"
        }
    }.replace(Regex("\n\n(?=(\\s*• |\\s*\\d+\\. ))"), "\n")

    private fun plain(s: String) = inline(s).joinToString("") { it.text }
}
