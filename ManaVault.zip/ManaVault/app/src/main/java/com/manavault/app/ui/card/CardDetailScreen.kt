package com.manavault.app.ui.card

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.manavault.app.AppGraph
import com.manavault.app.core.model.Card
import com.manavault.app.core.model.CardFace
import com.manavault.app.core.model.Currency
import com.manavault.app.core.model.Finish
import com.manavault.app.core.model.Ruling
import com.manavault.app.core.text.Format
import com.manavault.app.data.repo.OwnedCard
import com.manavault.app.graph
import com.manavault.app.ui.Navigator
import com.manavault.app.ui.components.AddToCollectionDialog
import com.manavault.app.ui.components.AddToDeckDialog
import com.manavault.app.ui.components.CardImage
import com.manavault.app.ui.components.EmptyState
import com.manavault.app.ui.components.LoadingBox
import com.manavault.app.ui.components.ManaCost
import com.manavault.app.ui.components.ScreenScaffold
import com.manavault.app.ui.components.SectionHeader
import com.manavault.app.ui.components.SymbolText
import com.manavault.app.ui.components.userMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CardDetailUi(
    val card: Card? = null,
    val loading: Boolean = true,
    val error: String? = null,
    val rulings: List<Ruling>? = null,
    val printings: List<Card>? = null,
)

class CardDetailViewModel(private val graph: AppGraph, private val id: String) : ViewModel() {
    private val _ui = MutableStateFlow(CardDetailUi())
    val ui: StateFlow<CardDetailUi> = _ui.asStateFlow()

    /** Everything in the collection with the same Oracle card (any printing). */
    val owned: StateFlow<List<OwnedCard>> = combine(graph.collection.owned, _ui) { owned, ui ->
        val oracle = ui.card?.oracleId ?: return@combine emptyList()
        owned.filter { it.card.oracleId == oracle }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        viewModelScope.launch {
            val local = graph.cards.local(id)
            if (local != null) _ui.update { it.copy(card = local, loading = false) }
            try {
                // Fresh copy for current prices. Only stored if the card was already cached locally.
                val fresh = graph.cards.fetchFreshIfCached(id, cachedLocally = local != null)
                _ui.update { it.copy(card = fresh, loading = false, error = null) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(loading = false, error = if (local == null) e.userMessage() else null) }
            }
            val card = _ui.value.card ?: return@launch
            launch {
                val r = runCatching { graph.cards.rulings(card) }.getOrNull()
                _ui.update { it.copy(rulings = r ?: emptyList()) }
            }
            launch {
                val p = runCatching { graph.cards.printings(card) }.getOrNull()
                _ui.update { it.copy(printings = p ?: emptyList()) }
            }
        }
    }
}

private val SHOWN_FORMATS = listOf(
    "standard" to "Standard", "pioneer" to "Pioneer", "modern" to "Modern", "legacy" to "Legacy",
    "vintage" to "Vintage", "commander" to "Commander", "pauper" to "Pauper", "historic" to "Historic",
    "timeless" to "Timeless", "brawl" to "Brawl", "oathbreaker" to "Oathbreaker", "premodern" to "Premodern",
)

@Composable
fun CardDetailScreen(id: String, nav: Navigator) {
    val graph = LocalContext.current.graph
    val vm: CardDetailViewModel = viewModel(key = "card-$id") { CardDetailViewModel(graph, id) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val owned by vm.owned.collectAsStateWithLifecycle()
    val tray by graph.tray.cards.collectAsStateWithLifecycle()
    val currency = graph.settings.settings.collectAsStateWithLifecycle().value.currency
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current
    var addOpen by remember { mutableStateOf(false) }
    var deckOpen by remember { mutableStateOf(false) }

    fun toast(m: String) { scope.launch { snackbar.showSnackbar(m) } }

    val card = ui.card
    ScreenScaffold(
        title = card?.name ?: "Card",
        onBack = nav::back,
        snackbarHost = snackbar,
        actions = {
            card?.scryfallUri?.let { link ->
                IconButton(onClick = { uri.openUri(link) }) { Icon(Icons.AutoMirrored.Filled.OpenInNew, "Open on Scryfall") }
            }
        },
    ) { padding ->
        when {
            card == null && ui.loading -> LoadingBox(Modifier.padding(padding), "Loading card…")
            card == null -> EmptyState(Icons.Filled.Inventory2, "Couldn't load this card", ui.error ?: "", Modifier.padding(padding))
            else -> LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 40.dp)) {
                item { CardHero(card) }
                item {
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { addOpen = true }, modifier = Modifier.weight(1f)) { Text("Collection") }
                        FilledTonalButton(onClick = { deckOpen = true }, modifier = Modifier.weight(1f)) { Text("Deck") }
                        val inTray = tray.any { it.oracleId == card.oracleId }
                        OutlinedButton(onClick = {
                            if (inTray) nav.interactionLab() else { graph.tray.add(card); toast("Added to the Interaction Lab") }
                        }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.AutoAwesome, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(if (inTray) "Open lab" else "Interact")
                        }
                    }
                    if (owned.isNotEmpty()) {
                        val total = owned.sumOf { it.quantity }
                        val thisPrinting = owned.filter { it.card.id == card.id }.sumOf { it.quantity }
                        Text(
                            "You own $total" + if (thisPrinting != total) " ($thisPrinting of this printing)" else "",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.padding(top = 8.dp),
                        )
                    }
                }
                item { RulesText(card) }
                item { PriceBlock(card, currency, onOpen = { uri.openUri(it) }) }
                item { Legalities(card) }
                ui.printings?.takeIf { it.size > 1 }?.let { printings ->
                    item {
                        SectionHeader("Printings (${printings.size})")
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(printings, key = { it.id }) { p ->
                                Column(Modifier.width(92.dp).clickable { if (p.id != card.id) nav.replaceCard(p.id) }) {
                                    CardImage(p.frontImageSmall ?: p.frontImage, p.name, Modifier.fillMaxWidth(), cornerRadius = 5.dp)
                                    Text(
                                        "${p.setCode.uppercase()} #${p.collectorNumber}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (p.id == card.id) FontWeight.Bold else null,
                                        color = if (p.id == card.id) MaterialTheme.colorScheme.primary else Color.Unspecified,
                                        maxLines = 1,
                                    )
                                    Text(Format.price(p.price(p.defaultFinish, currency), currency), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                }
                            }
                        }
                    }
                }
                item {
                    SectionHeader("Rulings")
                    val rulings = ui.rulings
                    when {
                        rulings == null -> Text("Loading…", style = MaterialTheme.typography.bodySmall)
                        rulings.isEmpty() -> Text("No official rulings for this card.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        else -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            rulings.forEach { r ->
                                Column {
                                    Text(r.publishedAt, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    SymbolText(r.comment, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (addOpen && card != null) AddToCollectionDialog(card, onDismiss = { addOpen = false }, onDone = ::toast)
    if (deckOpen && card != null) AddToDeckDialog(listOf(card), onDismiss = { deckOpen = false }, onDone = ::toast)
}

@Composable
private fun CardHero(card: Card) {
    var back by remember(card.id) { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
        val url = if (back && card.hasBackImage) card.faces[1].imageLarge ?: card.faces[1].imageNormal else card.imageLarge ?: card.faces.firstOrNull()?.imageLarge ?: card.frontImage
        CardImage(url, card.name, Modifier.fillMaxWidth(0.78f), cornerRadius = 14.dp)
        if (card.hasBackImage) {
            IconButton(
                onClick = { back = !back },
                modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHighest),
            ) { Icon(Icons.Filled.Flip, "Flip card") }
        }
    }
}

@Composable
private fun RulesText(card: Card) {
    SectionHeader("Card text")
    val faces: List<CardFace> = if (card.faces.isNotEmpty()) card.faces else listOf(
        CardFace(card.name, card.manaCost, card.typeLine, card.oracleText, card.power, card.toughness, card.loyalty, card.defense)
    )
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.padding(16.dp)) {
            faces.forEachIndexed { i, f ->
                if (i > 0) HorizontalDivider(Modifier.padding(vertical = 12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(f.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    ManaCost(f.manaCost)
                }
                Text(f.typeLine, style = MaterialTheme.typography.bodyMedium, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (f.oracleText.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    f.oracleText.split('\n').forEach { para ->
                        SymbolText(para, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(bottom = 6.dp))
                    }
                }
                val stats = when {
                    f.power != null && f.toughness != null -> "${f.power}/${f.toughness}"
                    f.loyalty != null -> "Loyalty ${f.loyalty}"
                    f.defense != null -> "Defense ${f.defense}"
                    else -> null
                }
                if (stats != null) {
                    Text(stats, style = MaterialTheme.typography.titleMedium, modifier = Modifier.align(Alignment.End))
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                listOfNotNull(
                    "${card.setName} (${card.setCode.uppercase()}) #${card.collectorNumber}",
                    Format.rarity(card.rarity).ifBlank { null },
                    card.artist?.let { "Illus. $it" },
                ).joinToString(" · "),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun PriceBlock(card: Card, currency: Currency, onOpen: (String) -> Unit) {
    SectionHeader("Prices")
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth()) {
                card.availableFinishes.forEach { f ->
                    Column(Modifier.weight(1f)) {
                        Text(f.label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(Format.price(card.price(f, currency), currency), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                listOf(Currency.USD, Currency.EUR, Currency.TIX).filter { it != currency }.joinToString("   ") { c ->
                    "${c.label}: " + Format.price(card.price(if (c == Currency.TIX) Finish.NONFOIL else card.defaultFinish, c), c)
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "Prices from Scryfall, updated daily.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row {
                card.tcgplayerUri?.let { TextButton(onClick = { onOpen(it) }) { Text("TCGplayer") } }
                card.cardmarketUri?.let { TextButton(onClick = { onOpen(it) }) { Text("Cardmarket") } }
            }
        }
    }
}

@Composable
private fun Legalities(card: Card) {
    SectionHeader("Legality")
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        SHOWN_FORMATS.forEach { (id, name) ->
            val status = card.legalityIn(id)
            val (bg, fg) = when (status) {
                "legal" -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
                "restricted" -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
                "banned" -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
                else -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
            }
            Row(
                Modifier.clip(RoundedCornerShape(8.dp)).background(bg).padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(name, style = MaterialTheme.typography.labelMedium, color = fg)
                Spacer(Modifier.width(6.dp))
                Text(Format.legality(status), style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.8f))
            }
        }
    }
}
