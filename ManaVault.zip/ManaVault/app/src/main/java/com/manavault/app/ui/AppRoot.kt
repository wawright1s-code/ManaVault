package com.manavault.app.ui

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.manavault.app.graph
import com.manavault.app.ui.card.CardDetailScreen
import com.manavault.app.ui.collection.CollectionScreen
import com.manavault.app.ui.decks.DeckDetailScreen
import com.manavault.app.ui.decks.DecksScreen
import com.manavault.app.ui.interactions.InteractionScreen
import com.manavault.app.ui.scan.ScanScreen
import com.manavault.app.ui.search.SearchScreen
import com.manavault.app.ui.settings.SettingsScreen

object Routes {
    const val COLLECTION = "collection"
    const val DECKS = "decks"
    const val SCAN = "scan"
    const val INTERACT = "interact"
    const val SEARCH = "search"
    const val SETTINGS = "settings"
    const val CARD = "card/{id}"
    const val DECK = "deck/{id}"
    fun card(id: String) = "card/$id"
    fun deck(id: Long) = "deck/$id"
}

private data class Tab(val route: String, val label: String, val icon: ImageVector, val selectedIcon: ImageVector)

private val TABS = listOf(
    Tab(Routes.COLLECTION, "Collection", Icons.Outlined.Inventory2, Icons.Filled.Inventory2),
    Tab(Routes.DECKS, "Decks", Icons.Outlined.Style, Icons.Filled.Style),
    Tab(Routes.SCAN, "Scan", Icons.Outlined.CameraAlt, Icons.Filled.CameraAlt),
    Tab(Routes.INTERACT, "Interact", Icons.Outlined.AutoAwesome, Icons.Filled.AutoAwesome),
    Tab(Routes.SEARCH, "Search", Icons.Outlined.Search, Icons.Filled.Search),
)

/** Navigation callbacks handed to every screen. */
class Navigator(private val nav: NavHostController) {
    fun back() { nav.popBackStack() }
    fun card(id: String) = nav.navigate(Routes.card(id))
    fun deck(id: Long) = nav.navigate(Routes.deck(id))
    fun settings() = nav.navigate(Routes.SETTINGS)
    fun tab(route: String) = nav.navigate(route) {
        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
    fun interactionLab() = tab(Routes.INTERACT)

    /** Replace the current card page with another printing instead of stacking pages. */
    fun replaceCard(id: String) = nav.navigate(Routes.card(id)) {
        popUpTo(Routes.CARD) { inclusive = true }
    }
}

@Composable
fun AppRoot() {
    val nav = rememberNavController()
    val navigator = androidx.compose.runtime.remember(nav) { Navigator(nav) }
    val backStack by nav.currentBackStackEntryAsState()
    val destination = backStack?.destination
    val showBar = TABS.any { tab -> destination?.route == tab.route }
    val tray by LocalContext.current.graph.tray.cards.collectAsStateWithLifecycle()

    Scaffold(
        contentWindowInsets = WindowInsets.navigationBars,
        bottomBar = {
            if (showBar) {
                NavigationBar {
                    TABS.forEach { tab ->
                        val selected = destination?.hierarchy?.any { it.route == tab.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = { navigator.tab(tab.route) },
                            icon = {
                                BadgedBox(badge = {
                                    if (tab.route == Routes.INTERACT && tray.isNotEmpty()) Badge { Text(tray.size.toString()) }
                                }) {
                                    Icon(if (selected) tab.selectedIcon else tab.icon, contentDescription = tab.label)
                                }
                            },
                            label = { Text(tab.label) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Routes.COLLECTION,
            modifier = Modifier.padding(padding).consumeWindowInsets(padding),
        ) {
            composable(Routes.COLLECTION) { CollectionScreen(navigator) }
            composable(Routes.DECKS) { DecksScreen(navigator) }
            composable(Routes.SCAN) { ScanScreen(navigator) }
            composable(Routes.INTERACT) { InteractionScreen(navigator) }
            composable(Routes.SEARCH) { SearchScreen(navigator) }
            composable(Routes.SETTINGS) { SettingsScreen(navigator) }
            composable(Routes.CARD, arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
                CardDetailScreen(entry.arguments?.getString("id").orEmpty(), navigator)
            }
            composable(Routes.DECK, arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                DeckDetailScreen(entry.arguments?.getLong("id") ?: 0L, navigator)
            }
        }
    }
}
