package com.manavault.app.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.manavault.app.core.backup.BackupFormatException
import com.manavault.app.graph
import com.manavault.app.ui.components.SectionHeader
import com.manavault.app.ui.components.userMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

/** Settings section: back up everything to one file, or restore from one. */
@Composable
fun DataSection(snackbar: SnackbarHostState) {
    val context = LocalContext.current
    val graph = context.graph
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf<String?>(null) }
    var pendingRestore by remember { mutableStateOf<String?>(null) }

    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = "Creating backup…"
            val result = runCatching {
                val json = graph.backup.export()
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
                        ?: error("Couldn't open the file for writing.")
                }
            }
            busy = null
            snackbar.showSnackbar(result.fold({ "Backup saved" }, { it.userMessage() }))
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val text = withContext(Dispatchers.IO) {
                runCatching { context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } }.getOrNull()
            }
            if (text.isNullOrBlank()) snackbar.showSnackbar("Couldn't read that file") else pendingRestore = text
        }
    }

    SectionHeader("Your data")
    Text(
        "Your collection and decks are stored only on this phone. A backup file holds everything — cards, decks and " +
            "preferences (not your API key) — so you can move to a new phone or recover after a reset.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        FilledTonalButton(
            enabled = busy == null,
            onClick = { backupLauncher.launch("manavault-backup-${LocalDate.now()}.json") },
        ) { Text("Back up everything") }
        OutlinedButton(
            enabled = busy == null,
            onClick = { restoreLauncher.launch(arrayOf("application/json", "text/*", "*/*")) },
        ) { Text("Restore") }
    }
    busy?.let {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(8.dp))
            Text(it, style = MaterialTheme.typography.bodySmall)
        }
    }

    pendingRestore?.let { text ->
        fun run(replace: Boolean) {
            pendingRestore = null
            scope.launch {
                busy = "Restoring…"
                val result = runCatching { graph.backup.restore(text, replace) }
                busy = null
                snackbar.showSnackbar(
                    result.fold(
                        { r -> "Restored ${r.collectionCards} cards and ${r.decks} deck${if (r.decks == 1) "" else "s"}" },
                        { e -> if (e is BackupFormatException) e.message ?: "Not a backup file" else e.userMessage() },
                    )
                )
            }
        }
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("Restore backup") },
            text = {
                Column {
                    Text("Merge adds the backup's cards and decks to what you have now.")
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Replace deletes your current collection and decks first. This can't be undone.",
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = { pendingRestore = null }) { Text("Cancel") }
                    TextButton(onClick = { run(replace = true) }) { Text("Replace", color = MaterialTheme.colorScheme.error) }
                    TextButton(onClick = { run(replace = false) }) { Text("Merge") }
                }
            },
        )
    }
}
