package com.manavault.app.core.backup

import com.manavault.app.core.model.Card
import com.manavault.app.core.scryfall.ScryfallJson
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put

data class BackupEntry(
    val cardId: String,
    val quantity: Int,
    val finish: String,
    val condition: String,
    val language: String,
    val addedAt: Long,
)

data class BackupDeckCard(val cardId: String, val board: String, val quantity: Int)

data class BackupDeck(
    val name: String,
    val format: String,
    val notes: String,
    val createdAt: Long,
    val updatedAt: Long,
    val cards: List<BackupDeckCard>,
)

data class BackupSettings(val currency: String?, val defaultCondition: String?, val model: String?)

/** Everything needed to rebuild the app's data on another phone, including the card data, so a restore works offline. */
data class BackupData(
    val exportedAt: Long,
    val cards: List<Card>,
    val collection: List<BackupEntry>,
    val decks: List<BackupDeck>,
    val settings: BackupSettings,
) {
    val collectionCount: Int get() = collection.sumOf { it.quantity }
}

class BackupFormatException(message: String) : Exception(message)

/**
 * Reads and writes ManaVault backup files (JSON). The Anthropic API key is deliberately never included.
 */
object BackupCodec {
    const val FORMAT = "manavault-backup"
    const val VERSION = 1

    fun encode(data: BackupData): String = buildJsonObject {
        put("format", FORMAT)
        put("version", VERSION)
        put("exportedAt", data.exportedAt)
        put("settings", buildJsonObject {
            data.settings.currency?.let { put("currency", it) }
            data.settings.defaultCondition?.let { put("defaultCondition", it) }
            data.settings.model?.let { put("model", it) }
        })
        put("cards", buildJsonArray {
            data.cards.distinctBy { it.id }.forEach { add(ScryfallJson.parseObject(ScryfallJson.encodeCard(it))) }
        })
        put("collection", buildJsonArray {
            data.collection.forEach { e ->
                add(buildJsonObject {
                    put("cardId", e.cardId)
                    put("quantity", e.quantity)
                    put("finish", e.finish)
                    put("condition", e.condition)
                    put("language", e.language)
                    put("addedAt", e.addedAt)
                })
            }
        })
        put("decks", buildJsonArray {
            data.decks.forEach { d ->
                add(buildJsonObject {
                    put("name", d.name)
                    put("format", d.format)
                    put("notes", d.notes)
                    put("createdAt", d.createdAt)
                    put("updatedAt", d.updatedAt)
                    put("cards", buildJsonArray {
                        d.cards.forEach { c ->
                            add(buildJsonObject {
                                put("cardId", c.cardId)
                                put("board", c.board)
                                put("quantity", c.quantity)
                            })
                        }
                    })
                })
            }
        })
    }.toString()

    fun decode(text: String): BackupData {
        val root = try {
            ScryfallJson.parseObject(text)
        } catch (e: Exception) {
            throw BackupFormatException("This file isn't a ManaVault backup.")
        }
        if (root.str("format") != FORMAT) throw BackupFormatException("This file isn't a ManaVault backup.")
        val version = root.int("version") ?: 0
        if (version > VERSION) throw BackupFormatException("This backup was made by a newer version of ManaVault. Update the app first.")

        val cards = root.arr("cards").objects().mapNotNull { runCatching { ScryfallJson.parseCard(it) }.getOrNull() }
        val known = cards.map { it.id }.toSet()
        val collection = root.arr("collection").objects().mapNotNull { o ->
            val id = o.str("cardId") ?: return@mapNotNull null
            if (id !in known) return@mapNotNull null
            BackupEntry(
                cardId = id,
                quantity = (o.int("quantity") ?: 1).coerceAtLeast(1),
                finish = o.str("finish") ?: "nonfoil",
                condition = o.str("condition") ?: "NM",
                language = o.str("language") ?: "en",
                addedAt = o.long("addedAt") ?: 0L,
            )
        }
        val decks = root.arr("decks").objects().map { d ->
            BackupDeck(
                name = d.str("name") ?: "Restored deck",
                format = d.str("format") ?: "casual",
                notes = d.str("notes").orEmpty(),
                createdAt = d.long("createdAt") ?: 0L,
                updatedAt = d.long("updatedAt") ?: 0L,
                cards = d.arr("cards").objects().mapNotNull { c ->
                    val id = c.str("cardId") ?: return@mapNotNull null
                    if (id !in known) return@mapNotNull null
                    BackupDeckCard(id, c.str("board") ?: "main", (c.int("quantity") ?: 1).coerceAtLeast(1))
                },
            )
        }
        val s = root["settings"] as? JsonObject
        return BackupData(
            exportedAt = root.long("exportedAt") ?: 0L,
            cards = cards,
            collection = collection,
            decks = decks,
            settings = BackupSettings(s?.str("currency"), s?.str("defaultCondition"), s?.str("model")),
        )
    }

    private fun JsonObject.str(k: String) = (this[k] as? JsonPrimitive)?.contentOrNull
    private fun JsonObject.int(k: String) = (this[k] as? JsonPrimitive)?.intOrNull
    private fun JsonObject.long(k: String) = (this[k] as? JsonPrimitive)?.longOrNull
    private fun JsonObject.arr(k: String) = this[k] as? JsonArray
    private fun JsonArray?.objects(): List<JsonObject> = this?.mapNotNull { it as? JsonObject }.orEmpty()
}
