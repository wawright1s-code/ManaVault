package com.manavault.app.ui.decks

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.manavault.app.core.deck.Board
import com.manavault.app.core.deck.DeckAnalysis
import com.manavault.app.core.deck.DeckCardEntry
import com.manavault.app.core.deck.DeckOdds
import com.manavault.app.core.deck.Playtest
import com.manavault.app.ui.components.BarChart
import com.manavault.app.ui.components.CardImage
import com.manavault.app.ui.components.EmptyState
import com.manavault.app.ui.components.SectionHeader
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Style

/** Goldfish the deck: opening hands, London mulligans and draws, plus land odds. */
@Composable
fun PlaytestTab(entries: List<DeckCardEntry>, onOpenCard: (String) -> Unit) {
    val main = entries.filter { it.board == Board.MAIN }
    val deckSize = main.sumOf { it.quantity }
    if (deckSize < Playtest.OPENING_HAND) {
        EmptyState(Icons.Filled.Style, "Not enough cards", "Add at least 7 cards to the main deck to draw sample hands.")
        return
    }
    // Rebuild the session whenever the deck list changes.
    val session = remember(main) { Playtest(main) }
    var version by remember(session) { mutableIntStateOf(0) }
    fun act(block: Playtest.() -> Unit) { session.block(); version++ }

    val lands = main.filter { DeckAnalysis.primaryType(it.card) == "Land" }.sumOf { it.quantity }
    val handLands = remember(version, session) { session.hand.count { DeckAnalysis.primaryType(it.card) == "Land" } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 32.dp)) {
        val status = buildString {
            append("Library ").append(session.library.size)
            append(" · ").append(session.hand.size).append(" in hand (").append(handLands).append(" land")
            if (handLands != 1) append("s")
            append(")")
            if (session.mulligans > 0) append(" · mulligan ").append(session.mulligans)
            if (session.turn > 0) append(" · drew ").append(session.turn)
        }
        Text(status, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 12.dp))

        if (session.toBottom > 0) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            ) {
                Text(
                    "London mulligan: tap ${session.toBottom} card${if (session.toBottom == 1) "" else "s"} to put on the bottom.",
                    modifier = Modifier.padding(12.dp),
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            session.hand.forEach { pc ->
                CardImage(
                    pc.card.frontImage,
                    pc.card.name,
                    Modifier.width(104.dp).clickable {
                        if (session.toBottom > 0) act { putOnBottom(pc) } else onOpenCard(pc.card.id)
                    },
                    cornerRadius = 6.dp,
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { act { newGame() } }) { Text("New hand") }
            OutlinedButton(onClick = { act { mulligan() } }, enabled = session.mulligans < 6) { Text("Mulligan") }
            FilledTonalButton(onClick = { act { draw() } }, enabled = session.library.isNotEmpty() && session.toBottom == 0) { Text("Draw") }
        }

        SectionHeader("Opening-hand lands")
        Text(
            "$lands lands in $deckSize cards. Chance of each land count in your first 7:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        val dist = remember(deckSize, lands) { DeckOdds.openingHandLands(deckSize, lands) }
        Spacer(Modifier.height(8.dp))
        BarChart(
            values = dist.map { (it * 100).toInt() },
            labels = (0..Playtest.OPENING_HAND).map { it.toString() },
        )
        Text("Bars show % of hands.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        val keepable = dist.subList(2, 6).sum()
        Text(
            "2–5 lands: ${pct(keepable)}   ·   0–1 lands: ${pct(dist[0] + dist[1])}",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(top = 6.dp),
        )

        SectionHeader("Hitting land drops (on the play)")
        (2..5).forEach { t ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                Text("A land every turn through turn $t", modifier = Modifier.weight(1f))
                Text(pct(DeckOdds.hitLandDrops(deckSize, lands, t)), fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

private fun pct(p: Double) = "%.0f%%".format(p * 100)
