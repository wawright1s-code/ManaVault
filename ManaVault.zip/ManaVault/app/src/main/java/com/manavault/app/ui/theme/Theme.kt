package com.manavault.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// "Vault" palette: ink-blue surfaces, antique gold accent, arcane violet and emerald as supporting hues.
private val Gold = Color(0xFFE2B34B)
private val GoldDeep = Color(0xFF7A5600)

private val DarkColors = darkColorScheme(
    primary = Gold,
    onPrimary = Color(0xFF2A1E00),
    primaryContainer = Color(0xFF4A3A10),
    onPrimaryContainer = Color(0xFFFBE3A6),
    secondary = Color(0xFFB9A7FF),
    onSecondary = Color(0xFF231A55),
    secondaryContainer = Color(0xFF3A3170),
    onSecondaryContainer = Color(0xFFE6DEFF),
    tertiary = Color(0xFF79D3A0),
    onTertiary = Color(0xFF00391F),
    tertiaryContainer = Color(0xFF15513A),
    onTertiaryContainer = Color(0xFFA4F2C2),
    background = Color(0xFF12141F),
    onBackground = Color(0xFFE6E2D9),
    surface = Color(0xFF12141F),
    onSurface = Color(0xFFE6E2D9),
    surfaceVariant = Color(0xFF2A2E40),
    onSurfaceVariant = Color(0xFFC3C2CC),
    surfaceContainerLowest = Color(0xFF0D0F17),
    surfaceContainerLow = Color(0xFF181B28),
    surfaceContainer = Color(0xFF1C2030),
    surfaceContainerHigh = Color(0xFF242839),
    surfaceContainerHighest = Color(0xFF2E3245),
    outline = Color(0xFF8D8C98),
    outlineVariant = Color(0xFF3F4255),
)

private val LightColors = lightColorScheme(
    primary = GoldDeep,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDF9C),
    onPrimaryContainer = Color(0xFF261A00),
    secondary = Color(0xFF5B4BB0),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE6DEFF),
    onSecondaryContainer = Color(0xFF170A5C),
    tertiary = Color(0xFF1E7A4C),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFA9F1C5),
    onTertiaryContainer = Color(0xFF002111),
    background = Color(0xFFF7F4EC),
    onBackground = Color(0xFF1D1B16),
    surface = Color(0xFFF7F4EC),
    onSurface = Color(0xFF1D1B16),
    surfaceVariant = Color(0xFFE9E2D0),
    onSurfaceVariant = Color(0xFF4C4639),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFFBF8F1),
    surfaceContainer = Color(0xFFF2EEE4),
    surfaceContainerHigh = Color(0xFFECE7DC),
    surfaceContainerHighest = Color(0xFFE6E1D5),
    outline = Color(0xFF7E7667),
    outlineVariant = Color(0xFFCFC6B4),
)

private val Base = Typography()

/** Serif display faces for names and titles evoke the card frame; body text stays in the system sans. */
private val AppTypography = Base.copy(
    displaySmall = Base.displaySmall.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
    headlineLarge = Base.headlineLarge.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
    headlineMedium = Base.headlineMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
    headlineSmall = Base.headlineSmall.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
    titleLarge = Base.titleLarge.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
)

/** Small all-caps label used above sections. */
val SectionLabelStyle = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp)

@Composable
fun ManaVaultTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
