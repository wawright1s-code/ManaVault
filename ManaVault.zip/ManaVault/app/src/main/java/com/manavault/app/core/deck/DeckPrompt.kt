package com.manavault.app.core.deck

import com.manavault.app.core.mana.ManaSymbols
import com.manavault.app.core.model.Card
import java.util.Locale

/** Builds the prompt for Claude's whole-deck analysis. */
object DeckPrompt {

    private const val MAX_ORACLE = 240

    val SYSTEM = """
You are an expert Magic: The Gathering deck builder and Level 3 judge reviewing a player's deck.

Ground rules:
- The card text in the message is the current Oracle text; rely on it rather than memory.
- Be specific to THIS list: name the actual cards involved in every point you make.
- Identify combos and loops precisely (which cards, what they need, whether infinite) and say plainly if there are none.
- Only suggest cards that are legal in the deck's format and fit its colors. Prefer well-known cards; never invent card names. If you're unsure a card is legal or exists, leave it out.
- Keep suggestions balanced: for each card you'd add, say what you'd cut.

Format your answer in Markdown with these sections:
## Game plan
## Key synergies and combos
## Mana and curve
## Weak spots
## Suggestions

Be concise and concrete; no preamble. For follow-up questions, answer directly without the section template.
""".trimIndent()

    fun userMessage(
        deckName: String,
        format: FormatRule,
        entries: List<DeckCardEntry>,
        issues: List<LegalityIssue>,
        focus: String?,
    ): String = buildString {
        val stats = DeckAnalysis.stats(entries)
        append("Analyze my deck \"").append(deckName).append("\"")
        if (format.id != Formats.CASUAL.id) append(" for ").append(format.name)
        append(".\n\n")

        append("Overview: ").append(stats.mainCount + stats.commanderCount).append(" cards")
        if (stats.sideCount > 0) append(", ").append(stats.sideCount).append(" in sideboard")
        append("; ").append(stats.landCount).append(" lands; average mana value of non-land cards ")
        append(String.format(Locale.US, "%.2f", stats.averageManaValue)).append(".\n")
        append("Curve (mana value: cards): ")
        append(stats.curve.mapIndexed { mv, n -> (if (mv == 7) "7+" else "$mv") + ": " + n }.joinToString(", ")).append('\n')
        append("Colors: ").append(ManaSymbols.identityName(stats.colorIdentity)).append('\n')
        val errors = issues.filter { it.severity == Severity.ERROR }
        if (errors.isNotEmpty()) {
            append("Legality problems the app found:\n")
            errors.take(15).forEach { append("- ").append(it.message).append('\n') }
        }
        append('\n')

        val commanders = entries.filter { it.board == Board.COMMANDER }
        if (commanders.isNotEmpty()) {
            append("## Commander\n")
            commanders.forEach { append(line(it, full = true)).append('\n') }
            append('\n')
        }

        val main = entries.filter { it.board == Board.MAIN }
            .sortedWith(compareBy<DeckCardEntry> { DeckAnalysis.typeOrder(DeckAnalysis.primaryType(it.card)) }.thenBy { it.card.cmc }.thenBy { it.card.name })
        val spells = main.filter { DeckAnalysis.primaryType(it.card) != "Land" }
        val lands = main.filter { DeckAnalysis.primaryType(it.card) == "Land" }
        append("## Main deck — spells\n")
        spells.forEach { append(line(it, full = true)).append('\n') }
        append("\n## Main deck — lands\n")
        lands.forEach { append(line(it, full = !it.card.isBasicLand)).append('\n') }

        val side = entries.filter { it.board == Board.SIDE }
        if (side.isNotEmpty()) {
            append("\n## Sideboard\n")
            side.sortedBy { it.card.name }.forEach { append(it.quantity).append("x ").append(it.card.name).append('\n') }
        }
        val maybe = entries.filter { it.board == Board.MAYBE }
        if (maybe.isNotEmpty()) {
            append("\n## Cards I'm considering\n")
            maybe.sortedBy { it.card.name }.forEach { append(it.card.name).append('\n') }
        }
        if (!focus.isNullOrBlank()) {
            append("\nWhat I'd especially like help with: ").append(focus.trim()).append('\n')
        }
    }

    private fun line(e: DeckCardEntry, full: Boolean): String {
        val c: Card = e.card
        val sb = StringBuilder().append(e.quantity).append("x ").append(c.name)
        if (!full) return sb.toString()
        if (c.displayManaCost.isNotBlank()) sb.append(' ').append(c.displayManaCost)
        sb.append(" — ").append(c.displayTypeLine)
        if (c.power != null && c.toughness != null) sb.append(" (").append(c.power).append('/').append(c.toughness).append(')')
        val text = c.allOracleText.replace('\n', ' ').trim()
        if (text.isNotEmpty()) {
            sb.append(" — ").append(if (text.length > MAX_ORACLE) text.take(MAX_ORACLE).trimEnd() + "…" else text)
        }
        return sb.toString()
    }
}
