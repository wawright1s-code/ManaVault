package com.manavault.app.data.repo

import androidx.room.withTransaction
import com.manavault.app.core.deck.Board
import com.manavault.app.core.deck.DeckCardEntry
import com.manavault.app.core.deck.DeckListFormat
import com.manavault.app.core.deck.ExportEntry
import com.manavault.app.core.deck.FormatRule
import com.manavault.app.core.deck.Formats
import com.manavault.app.core.mana.ManaSymbols
import com.manavault.app.core.model.Card
import com.manavault.app.core.model.Currency
import com.manavault.app.data.db.AppDatabase
import com.manavault.app.data.db.DeckCardEntity
import com.manavault.app.data.db.DeckCardRow
import com.manavault.app.data.db.DeckEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn

data class DeckWithCards(val deck: DeckEntity, val entries: List<DeckCardEntry>) {
    val format: FormatRule get() = Formats.byId(deck.format)

    fun count(board: Board): Int = entries.filter { it.board == board }.sumOf { it.quantity }

    /** Cards that are played: main deck + command zone. */
    val playingCount: Int get() = count(Board.MAIN) + count(Board.COMMANDER)

    fun value(currency: Currency): Double = entries
        .filter { it.board != Board.MAYBE }
        .sumOf { (it.card.priceOrFallback(it.card.defaultFinish, currency) ?: 0.0) * it.quantity }

    val colorIdentity: List<String>
        get() {
            val commanders = entries.filter { it.board == Board.COMMANDER }
            val source = commanders.ifEmpty { entries.filter { it.board == Board.MAIN } }
            return ManaSymbols.sortColors(source.flatMap { it.card.colorIdentity })
        }

    /** Commander art if there is one, otherwise the priciest non-land card's art. */
    val coverArt: String?
        get() = entries.firstOrNull { it.board == Board.COMMANDER }?.card?.artCrop
            ?: entries.filter { it.board == Board.MAIN && !it.card.isLand }
                .maxByOrNull { it.card.prices.usd ?: 0.0 }?.card?.artCrop
}

class DeckRepository(private val db: AppDatabase, private val cards: CardRepository) {

    private fun entry(r: DeckCardRow) = DeckCardEntry(
        card = cards.decode(r.deckCard.cardId, r.cardJson, r.cardUpdatedAt),
        quantity = r.deckCard.quantity,
        board = Board.fromKey(r.deckCard.board),
    )

    fun observeDecks(): Flow<List<DeckWithCards>> =
        combine(db.decks().observeDecks(), db.decks().observeAllDeckRows()) { decks, rows ->
            val byDeck = rows.groupBy { it.deckCard.deckId }
            decks.map { d -> DeckWithCards(d, byDeck[d.id].orEmpty().map(::entry)) }
        }.flowOn(Dispatchers.Default)

    fun observeDeck(id: Long): Flow<DeckWithCards?> =
        combine(db.decks().observeDeck(id), db.decks().observeDeckRows(id)) { deck, rows ->
            deck?.let { DeckWithCards(it, rows.map(::entry)) }
        }.flowOn(Dispatchers.Default)

    suspend fun create(name: String, format: String): Long {
        val now = System.currentTimeMillis()
        return db.decks().insertDeck(DeckEntity(name = name.trim().ifEmpty { "Untitled deck" }, format = format, createdAt = now, updatedAt = now))
    }

    suspend fun update(deck: DeckEntity) = db.decks().updateDeck(deck.copy(updatedAt = System.currentTimeMillis()))

    suspend fun delete(id: Long) = db.withTransaction {
        db.decks().clearDeck(id)
        db.decks().deleteDeck(id)
    }

    suspend fun duplicate(id: Long): Long {
        val deck = db.decks().getDeck(id) ?: return -1
        val rows = db.decks().deckRows(id)
        return db.withTransaction {
            val newId = create("${deck.name} (copy)", deck.format)
            val now = System.currentTimeMillis()
            rows.forEach { db.decks().upsertDeckCard(it.deckCard.copy(deckId = newId, addedAt = now)) }
            newId
        }
    }

    private suspend fun touch(deckId: Long) = db.decks().touch(deckId, System.currentTimeMillis())

    suspend fun addCard(deckId: Long, card: Card, board: Board = Board.MAIN, quantity: Int = 1) {
        cards.cache(card)
        addCached(deckId, card.id, board, quantity)
    }

    private suspend fun addCached(deckId: Long, cardId: String, board: Board, quantity: Int) {
        val dao = db.decks()
        db.withTransaction {
            val existing = dao.getDeckCard(deckId, cardId, board.key)
            val q = (existing?.quantity ?: 0) + quantity
            dao.upsertDeckCard(DeckCardEntity(deckId, cardId, board.key, q, existing?.addedAt ?: System.currentTimeMillis()))
            touch(deckId)
        }
    }

    suspend fun setQuantity(deckId: Long, cardId: String, board: Board, quantity: Int) {
        val dao = db.decks()
        db.withTransaction {
            if (quantity <= 0) {
                dao.deleteDeckCard(deckId, cardId, board.key)
            } else {
                val existing = dao.getDeckCard(deckId, cardId, board.key)
                dao.upsertDeckCard(DeckCardEntity(deckId, cardId, board.key, quantity, existing?.addedAt ?: System.currentTimeMillis()))
            }
            touch(deckId)
        }
    }

    /** Moves [quantity] copies (default: all) from one board to another. */
    suspend fun move(deckId: Long, cardId: String, from: Board, to: Board, quantity: Int? = null) {
        if (from == to) return
        val dao = db.decks()
        db.withTransaction {
            val src = dao.getDeckCard(deckId, cardId, from.key) ?: return@withTransaction
            val n = (quantity ?: src.quantity).coerceIn(1, src.quantity)
            if (n >= src.quantity) dao.deleteDeckCard(deckId, cardId, from.key)
            else dao.upsertDeckCard(src.copy(quantity = src.quantity - n))
            val dst = dao.getDeckCard(deckId, cardId, to.key)
            dao.upsertDeckCard(DeckCardEntity(deckId, cardId, to.key, (dst?.quantity ?: 0) + n, dst?.addedAt ?: System.currentTimeMillis()))
            touch(deckId)
        }
    }

    suspend fun setCommander(deckId: Long, cardId: String, from: Board) = move(deckId, cardId, from, Board.COMMANDER, 1)

    /** Swaps which printing of a card the deck uses (keeps quantity and board). */
    suspend fun replacePrinting(deckId: Long, oldCardId: String, board: Board, newCard: Card) {
        if (oldCardId == newCard.id) return
        cards.cache(newCard)
        val dao = db.decks()
        db.withTransaction {
            val old = dao.getDeckCard(deckId, oldCardId, board.key) ?: return@withTransaction
            dao.deleteDeckCard(deckId, oldCardId, board.key)
            val dst = dao.getDeckCard(deckId, newCard.id, board.key)
            dao.upsertDeckCard(DeckCardEntity(deckId, newCard.id, board.key, (dst?.quantity ?: 0) + old.quantity, old.addedAt))
            touch(deckId)
        }
    }

    /** Adds (or with [replace], replaces the deck with) a pasted deck list. */
    suspend fun importList(deckId: Long, text: String, replace: Boolean, onProgress: (String) -> Unit = {}): ImportReport {
        val lines = DeckListFormat.parse(text)
        if (lines.isEmpty()) return ImportReport(0, 0, emptyList())
        val requests = lines.map { CardRequest(it.name, it.setCode, it.collectorNumber) }
        val resolved = cards.resolve(requests, onProgress)
        val notFound = mutableListOf<String>()
        var added = 0
        db.withTransaction {
            if (replace) db.decks().clearDeck(deckId)
            lines.forEachIndexed { i, line ->
                val card = resolved[i]
                if (card == null) notFound += line.name
                else {
                    addCached(deckId, card.id, line.board, line.quantity)
                    added += line.quantity
                }
            }
        }
        return ImportReport(added, resolved.filterNotNull().distinctBy { it.id }.size, notFound)
    }

    suspend fun exportText(deckId: Long, includePrinting: Boolean): String {
        val rows = db.decks().deckRows(deckId).map(::entry)
        return DeckListFormat.export(
            rows.sortedBy { it.card.name }.map {
                ExportEntry(it.quantity, DeckListFormat.exportName(it.card), it.card.setCode, it.card.collectorNumber, it.board)
            },
            includePrinting,
        )
    }
}
