package com.manavault.app.ui.scan

import android.os.SystemClock
import android.util.Size
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.manavault.app.core.scan.OcrLine
import java.util.concurrent.Executors

/** One analysed camera frame: recognised lines plus the upright image size they're measured in. */
class OcrFrame(val lines: List<OcrLine>, val imageWidth: Int, val imageHeight: Int)

/**
 * Runs ML Kit's on-device Latin text recognizer on camera frames, at most every [minIntervalMs],
 * skipping frames while a previous one is still being processed.
 */
private class CardTextAnalyzer(
    private val recognizer: TextRecognizer,
    private val minIntervalMs: Long = 350,
    private val onFrame: (OcrFrame) -> Unit,
) : ImageAnalysis.Analyzer {
    @Volatile private var busy = false
    private var lastRun = 0L

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    override fun analyze(image: ImageProxy) {
        val now = SystemClock.elapsedRealtime()
        val media = image.image
        if (busy || media == null || now - lastRun < minIntervalMs) {
            image.close()
            return
        }
        busy = true
        lastRun = now
        val rotation = image.imageInfo.rotationDegrees
        val uprightW = if (rotation == 90 || rotation == 270) image.height else image.width
        val uprightH = if (rotation == 90 || rotation == 270) image.width else image.height
        recognizer.process(InputImage.fromMediaImage(media, rotation))
            .addOnSuccessListener { text ->
                val lines = text.textBlocks.flatMap { block ->
                    block.lines.mapNotNull { line ->
                        line.boundingBox?.let { r -> OcrLine(line.text, r.left, r.top, r.right, r.bottom) }
                    }
                }
                onFrame(OcrFrame(lines, uprightW, uprightH))
            }
            .addOnCompleteListener {
                busy = false
                image.close()
            }
    }
}

@Composable
fun CameraPreview(
    onFrame: (OcrFrame) -> Unit,
    torchOn: Boolean,
    modifier: Modifier = Modifier,
    onCameraError: (String) -> Unit = {},
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember {
        PreviewView(context).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
    }
    val latestOnFrame by rememberUpdatedState(onFrame)
    val latestOnError by rememberUpdatedState(onCameraError)
    var camera by remember { mutableStateOf<Camera?>(null) }

    DisposableEffect(lifecycleOwner) {
        val executor = Executors.newSingleThreadExecutor()
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val mainExecutor = ContextCompat.getMainExecutor(context)
        val analyzer = CardTextAnalyzer(recognizer) { frame -> mainExecutor.execute { latestOnFrame(frame) } }
        val providerFuture = ProcessCameraProvider.getInstance(context)
        var provider: ProcessCameraProvider? = null
        var disposed = false

        providerFuture.addListener({
            if (disposed) return@addListener
            try {
                val p = providerFuture.get()
                provider = p
                // Preview and analysis both use 4:3 so the on-screen guide maps onto the analysed frame.
                val preview = Preview.Builder()
                    .setResolutionSelector(
                        ResolutionSelector.Builder().setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY).build()
                    )
                    .build()
                preview.setSurfaceProvider(previewView.surfaceProvider)
                val selector = ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .setResolutionStrategy(
                        ResolutionStrategy(Size(1920, 1440), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
                    )
                    .build()
                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(selector)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor, analyzer)
                p.unbindAll()
                camera = p.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) {
                latestOnError(e.message ?: "Couldn't start the camera.")
            }
        }, mainExecutor)

        onDispose {
            disposed = true
            provider?.unbindAll()
            camera = null
            executor.shutdown()
            recognizer.close()
        }
    }

    LaunchedEffect(camera, torchOn) {
        camera?.let { c -> if (c.cameraInfo.hasFlashUnit()) c.cameraControl.enableTorch(torchOn) }
    }

    AndroidView(factory = { previewView }, modifier = modifier)
}
