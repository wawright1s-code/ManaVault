package com.manavault.app.core.collection

import com.manavault.app.core.model.Condition
import com.manavault.app.core.model.Finish
import java.util.Locale

data class CsvCollectionRow(
    val quantity: Int,
    val name: String,
    val setCode: String? = null,
    val setName: String? = null,
    val collectorNumber: String? = null,
    val finish: Finish = Finish.NONFOIL,
    val condition: Condition = Condition.NM,
    val language: String = "en",
    val scryfallId: String? = null,
    val price: Double? = null,
)

/** Minimal RFC 4180 CSV reader/writer with delimiter auto-detection (comma, semicolon or tab). */
object Csv {
    fun parse(text: String, delimiter: Char = detectDelimiter(text)): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        val row = mutableListOf<String>()
        val field = StringBuilder()
        var inQuotes = false
        var i = 0
        val s = text.removePrefix("﻿")
        fun endField() { row += field.toString(); field.setLength(0) }
        fun endRow() {
            endField()
            if (!(row.size == 1 && row[0].isEmpty())) rows += row.toList()
            row.clear()
        }
        while (i < s.length) {
            val c = s[i]
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < s.length && s[i + 1] == '"') { field.append('"'); i++ } else inQuotes = false
                } else field.append(c)
            } else when (c) {
                '"' -> inQuotes = true
                delimiter -> endField()
                '\r' -> { endRow(); if (i + 1 < s.length && s[i + 1] == '\n') i++ }
                '\n' -> endRow()
                else -> field.append(c)
            }
            i++
        }
        if (field.isNotEmpty() || row.isNotEmpty()) endRow()
        return rows
    }

    fun detectDelimiter(text: String): Char {
        val first = text.removePrefix("﻿").lineSequence().firstOrNull().orEmpty()
        return listOf(',', ';', '\t').maxByOrNull { d -> first.count { it == d } }?.takeIf { d -> first.count { it == d } > 0 } ?: ','
    }

    fun escape(value: String): String =
        if (value.any { it == ',' || it == '"' || it == '\n' || it == '\r' || it == ';' }) "\"" + value.replace("\"", "\"\"") + "\"" else value

    fun line(values: List<String>): String = values.joinToString(",") { escape(it) }
}

/**
 * Collection import/export. The export columns are readable by ManaBox/Moxfield-style importers,
 * and the importer understands the column names those apps (and Deckbox, Archidekt, TCGplayer) use.
 */
object CollectionCsv {
    val HEADER = listOf("Quantity", "Name", "Set", "Set Name", "Collector Number", "Finish", "Condition", "Language", "Price", "Scryfall ID")

    private val ALIASES: Map<String, List<String>> = mapOf(
        "quantity" to listOf("quantity", "count", "qty", "amount", "copies", "havelistcount", "totalquantity"),
        "name" to listOf("name", "cardname", "card", "cardtitle"),
        "set" to listOf("set", "setcode", "edition", "editioncode", "expansioncode", "code"),
        "setname" to listOf("setname", "editionname", "expansion", "expansionname"),
        "number" to listOf("collectornumber", "number", "cardnumber", "collectorsnumber", "cn"),
        "finish" to listOf("finish", "foil", "printing", "isfoil", "foiling"),
        "condition" to listOf("condition", "cond"),
        "language" to listOf("language", "lang"),
        "id" to listOf("scryfallid", "scryfalluuid", "scryfall"),
        "price" to listOf("price", "priceusd", "purchaseprice", "marketprice"),
    )

    fun write(rows: List<CsvCollectionRow>): String = buildString {
        append(Csv.line(HEADER)).append('\n')
        for (r in rows) {
            append(
                Csv.line(
                    listOf(
                        r.quantity.toString(),
                        r.name,
                        r.setCode.orEmpty().uppercase(),
                        r.setName.orEmpty(),
                        r.collectorNumber.orEmpty(),
                        r.finish.key,
                        r.condition.code,
                        r.language,
                        r.price?.let { String.format(Locale.US, "%.2f", it) }.orEmpty(),
                        r.scryfallId.orEmpty(),
                    )
                )
            ).append('\n')
        }
    }

    /** Returns null when the text has no recognizable header (caller can then try deck-list parsing). */
    fun read(text: String): List<CsvCollectionRow>? {
        val table = Csv.parse(text)
        if (table.isEmpty()) return emptyList()
        val header = table.first().map { norm(it) }
        fun col(key: String): Int = ALIASES[key].orEmpty().firstNotNullOfOrNull { alias -> header.indexOf(alias).takeIf { it >= 0 } } ?: -1
        val nameCol = col("name")
        val idCol = col("id")
        if (nameCol < 0 && idCol < 0) return null
        val qtyCol = col("quantity")
        val setCol = col("set")
        val setNameCol = col("setname")
        val numCol = col("number")
        val finishCol = col("finish")
        val condCol = col("condition")
        val langCol = col("language")
        val priceCol = col("price")

        return table.drop(1).mapNotNull { r ->
            fun at(i: Int): String? = if (i >= 0 && i < r.size) r[i].trim().ifEmpty { null } else null
            val name = at(nameCol).orEmpty()
            val id = at(idCol)
            if (name.isEmpty() && id == null) return@mapNotNull null
            CsvCollectionRow(
                quantity = at(qtyCol)?.toDoubleOrNull()?.toInt()?.coerceAtLeast(1) ?: 1,
                name = name,
                setCode = at(setCol)?.lowercase()?.takeIf { it.length in 2..6 },
                setName = at(setNameCol),
                collectorNumber = at(numCol),
                finish = Finish.fromKey(at(finishCol)),
                condition = Condition.fromCode(at(condCol)),
                language = languageCode(at(langCol)),
                scryfallId = id?.takeIf { UUID.matches(it) },
                price = at(priceCol)?.replace("$", "")?.replace("€", "")?.toDoubleOrNull(),
            )
        }
    }

    private val UUID = Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun languageCode(raw: String?): String {
        val v = raw?.trim()?.lowercase() ?: return "en"
        return when (v) {
            "english" -> "en"; "spanish" -> "es"; "french" -> "fr"; "german" -> "de"; "italian" -> "it"
            "portuguese" -> "pt"; "japanese" -> "ja"; "korean" -> "ko"; "russian" -> "ru"
            "chinese simplified", "simplified chinese" -> "zhs"; "chinese traditional", "traditional chinese" -> "zht"
            else -> if (v.length in 2..3) v else "en"
        }
    }
}
