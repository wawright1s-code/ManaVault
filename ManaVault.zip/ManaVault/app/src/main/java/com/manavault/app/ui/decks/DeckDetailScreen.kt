package com.manavault.app.ui.decks

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.manavault.app.core.deck.Board
import com.manavault.app.core.deck.DeckCardEntry
import com.manavault.app.core.deck.Formats
import com.manavault.app.core.deck.Severity
import com.manavault.app.core.mana.ManaSymbols
import com.manavault.app.core.text.Format
import com.manavault.app.graph
import com.manavault.app.ui.Navigator
import com.manavault.app.ui.components.BarChart
import com.manavault.app.ui.components.CardImage
import com.manavault.app.ui.components.CardRow
import com.manavault.app.ui.components.CardSearchDialog
import com.manavault.app.ui.components.ConfirmDialog
import com.manavault.app.ui.components.EmptyState
import com.manavault.app.ui.components.LoadingBox
import com.manavault.app.ui.components.PrintingPickerDialog
import com.manavault.app.ui.components.QuantityStepper
import com.manavault.app.ui.components.ScreenScaffold
import com.manavault.app.ui.components.SectionHeader
import com.manavault.app.ui.components.SymbolIcon
import com.manavault.app.ui.components.Tag
import kotlinx.coroutines.launch

@Composable
fun DeckDetailScreen(deckId: Long, nav: Navigator) {
    val context = LocalContext.current
    val graph = context.graph
    val vm: DeckDetailViewModel = viewModel(key = "deck-$deckId") { DeckDetailViewModel(graph, deckId) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val task by vm.task.collectAsStateWithLifecycle()
    val message by vm.messages.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var tab by remember { mutableIntStateOf(0) }
    var menuOpen by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    var sheetFor by remember { mutableStateOf<DeckCardEntry?>(null) }
    var renaming by remember { mutableStateOf(false) }
    var formatOpen by remember { mutableStateOf(false) }
    var importOpen by remember { mutableStateOf(false) }
    var exportOpen by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var analyzing by remember { mutableStateOf(false) }
    val analysis by vm.analysis.collectAsStateWithLifecycle()
    val settings by graph.settings.settings.collectAsStateWithLifecycle()

    fun toast(m: String) { scope.launch { snackbar.showSnackbar(m) } }

    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); vm.messageShown() } }

    val deck = ui.deck
    val selecting = ui.selection.isNotEmpty()

    ScreenScaffold(
        title = if (selecting) "${ui.selection.size} selected" else deck?.deck?.name ?: "Deck",
        onBack = if (selecting) vm::clearSelection else nav::back,
        snackbarHost = snackbar,
        titleContent = if (selecting || deck == null) null else {
            {
                Column(Modifier.clickable { renaming = true }) {
                    Text(deck.deck.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(deck.format.name, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        actions = {
            if (selecting) {
                IconButton(onClick = {
                    graph.tray.addAll(vm.selectedCards())
                    vm.clearSelection()
                    nav.interactionLab()
                }) { Icon(Icons.Filled.AutoAwesome, "Explain interactions") }
            } else if (deck != null) {
                IconButton(onClick = { exportOpen = true }) { Icon(Icons.Filled.Share, "Export") }
                Box {
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, "More") }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Analyze with Claude") },
                            leadingIcon = { Icon(Icons.Filled.AutoAwesome, null) },
                            enabled = deck.entries.isNotEmpty(),
                            onClick = { menuOpen = false; analyzing = true },
                        )
                        DropdownMenuItem(text = { Text("Rename") }, onClick = { menuOpen = false; renaming = true })
                        DropdownMenuItem(text = { Text("Change format") }, onClick = { menuOpen = false; formatOpen = true })
                        DropdownMenuItem(text = { Text("Import / paste list") }, onClick = { menuOpen = false; importOpen = true })
                        DropdownMenuItem(
                            text = { Text("Copy buy list (${ui.missingCards} missing)") },
                            enabled = ui.missingCards > 0,
                            onClick = {
                                menuOpen = false
                                clipboard.setText(AnnotatedString(vm.missingList()))
                                toast("Copied the cards you're missing")
                            },
                        )
                        DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menuOpen = false; vm.duplicate { nav.deck(it) } })
                        DropdownMenuItem(text = { Text("Delete deck", color = MaterialTheme.colorScheme.error) }, onClick = { menuOpen = false; confirmDelete = true })
                    }
                }
            }
        },
        floatingActionButton = {
            if (deck != null && !selecting && tab == 0) {
                ExtendedFloatingActionButton(text = { Text("Add cards") }, icon = { Icon(Icons.Filled.Add, null) }, onClick = { adding = true })
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            when {
                !ui.loaded -> LoadingBox()
                deck == null -> EmptyState(Icons.Filled.Style, "Deck not found", "It may have been deleted.")
                else -> {
                    TabRow(selectedTabIndex = tab) {
                        Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Cards (${deck.playingCount})") })
                        Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Stats") })
                        Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Playtest") })
                    }
                    if (tab == 0) CardsTab(ui, onOpen = { e -> if (selecting) vm.toggleSelect(e) else sheetFor = e }, onSelect = vm::toggleSelect, onCopyMissing = {
                        clipboard.setText(AnnotatedString(vm.missingList()))
                        toast("Copied the cards you're missing")
                    }, onAdd = { adding = true })
                    else if (tab == 1) StatsTab(ui)
                    else PlaytestTab(deck.entries, onOpenCard = { nav.card(it) })
                }
            }
        }
    }

    sheetFor?.let { e0 ->
        val e = deck?.entries?.firstOrNull { it.card.id == e0.card.id && it.board == e0.board }
        if (e != null) {
            EntrySheet(
                e = e,
                ui = ui,
                onDismiss = { sheetFor = null },
                onQuantity = { vm.setQuantity(e, it); if (it <= 0) sheetFor = null },
                onMove = { vm.move(e, it); sheetFor = null },
                onCommander = { vm.setCommander(e); sheetFor = null },
                onPrinting = { vm.replacePrinting(e, it); sheetFor = null },
                onDetails = { sheetFor = null; nav.card(e.card.id) },
                onInteract = { graph.tray.add(e.card); toast("Added to the Interaction Lab") },
            )
        }
    }
    if (adding) {
        CardSearchDialog(
            title = "Add to ${deck?.deck?.name ?: "deck"}",
            keepOpen = true,
            onDismiss = { adding = false },
            onPick = { vm.addCard(it, Board.MAIN) },
        )
    }
    if (renaming && deck != null) {
        var name by remember { mutableStateOf(deck.deck.name) }
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text("Rename deck") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.rename(name); renaming = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text("Cancel") } },
        )
    }
    if (formatOpen && deck != null) {
        AlertDialog(
            onDismissRequest = { formatOpen = false },
            title = { Text("Format") },
            text = { FormatPicker(deck.deck.format) { vm.setFormat(it); formatOpen = false } },
            confirmButton = { TextButton(onClick = { formatOpen = false }) { Text("Close") } },
        )
    }
    if (importOpen) {
        DeckImportDialog(onDismiss = { importOpen = false }, onImport = { text, replace -> vm.importList(text, replace) })
    }
    if (exportOpen) {
        ExportDialog(vm = vm, onDismiss = { exportOpen = false }, onCopied = { toast("Deck list copied") }, onShare = { text ->
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, deck?.deck?.name ?: "Deck")
                putExtra(Intent.EXTRA_TEXT, text)
            }
            context.startActivity(Intent.createChooser(send, "Share deck list"))
        })
    }
    if (analyzing && deck != null) {
        DeckAnalysisDialog(
            deckName = deck.deck.name,
            analysis = analysis,
            hasApiKey = settings.hasApiKey,
            onAnalyze = vm::analyze,
            onReset = vm::resetAnalysis,
            onOpenSettings = { analyzing = false; nav.settings() },
            onDismiss = { analyzing = false },
        )
    }
    if (confirmDelete) {
        ConfirmDialog(
            title = "Delete this deck?",
            message = "The deck list is deleted. Cards in your collection aren't affected.",
            confirmLabel = "Delete",
            onConfirm = { vm.delete { nav.back() } },
            onDismiss = { confirmDelete = false },
        )
    }
    when (val t = task) {
        is DeckTask.Running -> AlertDialog(onDismissRequest = {}, confirmButton = {}, title = { Text("Importing") }, text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(24.dp))
                Spacer(Modifier.width(16.dp))
                Text(t.message)
            }
        })
        is DeckTask.Done -> AlertDialog(
            onDismissRequest = vm::dismissTask,
            confirmButton = { TextButton(onClick = vm::dismissTask) { Text("OK") } },
            title = { Text("Import finished") },
            text = {
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    Text("Added ${t.report.added} cards.")
                    if (t.report.notFound.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Couldn't find ${t.report.notFound.size}:", fontWeight = FontWeight.SemiBold)
                        t.report.notFound.take(50).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            },
        )
        null -> Unit
    }
}

@Composable
private fun CardsTab(
    ui: DeckDetailUi,
    onOpen: (DeckCardEntry) -> Unit,
    onSelect: (DeckCardEntry) -> Unit,
    onCopyMissing: () -> Unit,
    onAdd: () -> Unit,
) {
    val deck = ui.deck ?: return
    if (deck.entries.isEmpty()) {
        EmptyState(
            icon = Icons.Filled.Style,
            title = "An empty deck",
            message = "Add cards with search, or paste a list from the ⋮ menu.",
            action = { OutlinedButton(onClick = onAdd) { Text("Add cards") } },
        )
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 96.dp)) {
        item(key = "summary") { DeckSummary(ui, onCopyMissing) }
        for (group in ui.groups) {
            item(key = "h-" + group.title + group.board.key) {
                SectionHeader("${group.title} (${group.count})", Modifier.padding(horizontal = 16.dp))
            }
            items(group.entries, key = { it.key() }) { e ->
                val owned = ui.owned[e.card.oracleId] ?: 0
                CardRow(
                    card = e.card,
                    subtitle = e.card.displayTypeLine,
                    selected = e.key() in ui.selection,
                    onClick = { onOpen(e) },
                    onLongClick = { onSelect(e) },
                    trailing = {
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${e.quantity}×", style = MaterialTheme.typography.titleMedium)
                            when {
                                e.board == Board.MAYBE -> Unit
                                owned >= e.quantity -> Tag("Owned", MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer)
                                owned > 0 -> Tag("Have $owned", MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant)
                                else -> Text(
                                    Format.price(e.card.priceOrFallback(e.card.defaultFinish, ui.currency), ui.currency),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    },
                )
            }
        }
    }
}

@Composable
private fun DeckSummary(ui: DeckDetailUi, onCopyMissing: () -> Unit) {
    val deck = ui.deck ?: return
    val format = deck.format
    var showIssues by remember { mutableStateOf(false) }
    val errors = ui.issues.count { it.severity == Severity.ERROR }
    Card(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    val target = format.exactDeckSize ?: format.minDeckSize
                    Text(
                        buildString {
                            append(deck.playingCount)
                            if (target > 0) append(" / ").append(target)
                            append(" cards")
                            deck.count(Board.SIDE).takeIf { it > 0 }?.let { append(" · ").append(it).append(" sideboard") }
                        },
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                        deck.colorIdentity.forEach { SymbolIcon(it, 16.dp) }
                        if (deck.colorIdentity.isNotEmpty()) Spacer(Modifier.width(4.dp))
                        Text(ManaSymbols.identityName(deck.colorIdentity), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(Format.price(ui.value, ui.currency), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                    Text("deck value", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(10.dp))
            if (ui.missingCards == 0) {
                Text("✓ You own every card in this deck", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.tertiary)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Missing ${ui.missingCards} card${if (ui.missingCards == 1) "" else "s"} from your collection", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    TextButton(onClick = onCopyMissing) { Text("Copy list") }
                }
            }
            if (format.id != Formats.CASUAL.id) {
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Row(Modifier.fillMaxWidth().clickable(enabled = ui.issues.isNotEmpty()) { showIssues = !showIssues }, verticalAlignment = Alignment.CenterVertically) {
                    val ok = errors == 0
                    Icon(
                        if (ok) Icons.Filled.CheckCircle else Icons.Filled.ErrorOutline,
                        null,
                        tint = if (ok) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (ok) "Legal in ${format.name}" + (if (ui.issues.isNotEmpty()) " (${ui.issues.size} note${if (ui.issues.size == 1) "" else "s"})" else "")
                        else "$errors problem${if (errors == 1) "" else "s"} for ${format.name}",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                    )
                    if (ui.issues.isNotEmpty()) Text(if (showIssues) "Hide" else "Show", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                }
                if (showIssues) {
                    ui.issues.forEach { issue ->
                        Row(Modifier.padding(top = 6.dp)) {
                            Icon(
                                if (issue.severity == Severity.ERROR) Icons.Filled.ErrorOutline else Icons.Filled.Warning,
                                null,
                                tint = if (issue.severity == Severity.ERROR) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp).padding(top = 2.dp),
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(issue.message, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatsTab(ui: DeckDetailUi) {
    val stats = ui.stats ?: return
    val deck = ui.deck ?: return
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 32.dp)) {
        SectionHeader("Mana curve")
        Text(
            "Average mana value %.2f (non-land cards) · %d lands".format(stats.averageManaValue, stats.landCount),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        BarChart(stats.curve, listOf("0", "1", "2", "3", "4", "5", "6", "7+"))

        if (stats.colorPips.isNotEmpty()) {
            SectionHeader("Colored mana symbols")
            val keys = stats.colorPips.keys.toList()
            BarChart(
                values = keys.map { stats.colorPips.getValue(it) },
                labels = keys.map { ManaSymbols.COLOR_NAMES[it] ?: it },
                barColors = keys.map { pipColor(it) },
            )
        }

        SectionHeader("Card types")
        stats.typeCounts.forEach { (type, n) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                Text(type, modifier = Modifier.weight(1f))
                Text(n.toString(), fontWeight = FontWeight.SemiBold)
            }
        }

        SectionHeader("Most valuable")
        deck.entries.filter { it.board != Board.MAYBE }
            .sortedByDescending { it.card.priceOrFallback(it.card.defaultFinish, ui.currency) ?: 0.0 }
            .take(10)
            .forEach { e ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${e.quantity}× ${e.card.name}", modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(Format.price(e.card.priceOrFallback(e.card.defaultFinish, ui.currency), ui.currency))
                }
            }
    }
}

private fun pipColor(c: String): Color = when (c) {
    "W" -> Color(0xFFF3E9C6)
    "U" -> Color(0xFF4A90D9)
    "B" -> Color(0xFF6F6577)
    "R" -> Color(0xFFE0533D)
    "G" -> Color(0xFF3E9B5B)
    else -> Color(0xFFB8B2A7)
}

@Composable
private fun EntrySheet(
    e: DeckCardEntry,
    ui: DeckDetailUi,
    onDismiss: () -> Unit,
    onQuantity: (Int) -> Unit,
    onMove: (Board) -> Unit,
    onCommander: () -> Unit,
    onPrinting: (com.manavault.app.core.model.Card) -> Unit,
    onDetails: () -> Unit,
    onInteract: () -> Unit,
) {
    var pickPrinting by remember { mutableStateOf(false) }
    val owned = ui.owned[e.card.oracleId] ?: 0
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
            Row {
                CardImage(e.card.frontImage, e.card.name, Modifier.width(110.dp), cornerRadius = 7.dp)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(e.card.name, style = MaterialTheme.typography.titleLarge)
                    Text("${e.card.setCode.uppercase()} #${e.card.collectorNumber} · ${e.board.label}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    Text(Format.price(e.card.priceOrFallback(e.card.defaultFinish, ui.currency), ui.currency) + " each", color = MaterialTheme.colorScheme.primary)
                    Text(if (owned > 0) "You own $owned" else "Not in your collection", style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { pickPrinting = true }, contentPadding = PaddingValues(0.dp)) { Text("Change printing") }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Copies", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                QuantityStepper(e.quantity, onQuantity, min = 0)
            }
            Spacer(Modifier.height(10.dp))
            Text("Move to", style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(Board.MAIN, Board.SIDE, Board.MAYBE).filter { it != e.board }.forEach { b ->
                    FilterChip(selected = false, onClick = { onMove(b) }, label = { Text(b.label) })
                }
                if (e.board != Board.COMMANDER && (ui.deck?.format?.hasCommander == true || e.card.isLegendary)) {
                    FilterChip(selected = false, onClick = onCommander, label = { Text("Set as commander") })
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = onDetails) { Text("Card details") }
                TextButton(onClick = onInteract) { Text("Interaction Lab") }
                TextButton(onClick = { onQuantity(0) }) { Text("Remove", color = MaterialTheme.colorScheme.error) }
            }
        }
    }
    if (pickPrinting) {
        PrintingPickerDialog(e.card, onDismiss = { pickPrinting = false }, onPick = onPrinting)
    }
}

@Composable
private fun DeckImportDialog(onDismiss: () -> Unit, onImport: (String, Boolean) -> Unit) {
    var text by remember { mutableStateOf("") }
    var replace by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Import deck list") },
        text = {
            Column {
                Text(
                    "Paste from Arena, MTGO, Moxfield, Archidekt or any “4 Card Name” list. Commander and Sideboard sections are recognized.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp, max = 300.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = replace, onCheckedChange = { replace = it })
                    Text("Replace the current cards")
                }
            }
        },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onImport(text, replace); onDismiss() }) { Text("Import") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ExportDialog(vm: DeckDetailViewModel, onDismiss: () -> Unit, onCopied: () -> Unit, onShare: (String) -> Unit) {
    val clipboard = LocalClipboardManager.current
    var includePrinting by remember { mutableStateOf(true) }
    var text by remember { mutableStateOf("") }
    LaunchedEffect(includePrinting) { text = vm.exportText(includePrinting) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Export deck") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = includePrinting, onCheckedChange = { includePrinting = it })
                    Text("Include set and collector number")
                }
                Text(
                    text,
                    fontFamily = FontFamily.Monospace,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState()),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { clipboard.setText(AnnotatedString(text)); onCopied(); onDismiss() }) { Text("Copy") }
        },
        dismissButton = {
            TextButton(onClick = { onShare(text) }) { Text("Share") }
        },
    )
}
