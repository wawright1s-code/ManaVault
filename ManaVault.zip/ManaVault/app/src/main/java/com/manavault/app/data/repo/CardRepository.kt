package com.manavault.app.data.repo

import com.manavault.app.core.model.Card
import com.manavault.app.core.model.Ruling
import com.manavault.app.core.scan.CardTextExtractor
import com.manavault.app.core.scryfall.CardPage
import com.manavault.app.core.scryfall.ScryfallJson
import com.manavault.app.core.text.LruMap
import com.manavault.app.data.db.AppDatabase
import com.manavault.app.data.db.CardEntity
import com.manavault.app.data.net.ScryfallApi
import kotlinx.serialization.json.JsonObject

/** A card to look up: by Scryfall id, by set + collector number, or by name (optionally within a set). */
data class CardRequest(
    val name: String? = null,
    val setCode: String? = null,
    val collectorNumber: String? = null,
    val scryfallId: String? = null,
) {
    val label: String
        get() = name ?: scryfallId ?: listOfNotNull(setCode?.uppercase(), collectorNumber?.let { "#$it" }).joinToString(" ")
}

/**
 * Scryfall lookups plus the local card cache. Every card that is in the collection or a deck is
 * stored locally, so those screens work offline and prices only refresh when asked.
 */
class CardRepository(private val api: ScryfallApi, private val db: AppDatabase) {

    private val parsed = LruMap<String, Card>(6000)
    private val rulingsCache = LruMap<String, List<Ruling>>(300)
    private val printingsCache = LruMap<String, List<Card>>(100)

    fun decode(id: String, json: String, updatedAt: Long): Card =
        parsed.getOrPut("$id@$updatedAt") { ScryfallJson.parseCard(json) }

    private fun entity(card: Card, now: Long) =
        CardEntity(card.id, card.oracleId, card.name, ScryfallJson.encodeCard(card), now)

    suspend fun cache(card: Card) = db.cards().upsert(entity(card, System.currentTimeMillis()))

    suspend fun cacheAll(cards: List<Card>) {
        if (cards.isEmpty()) return
        val now = System.currentTimeMillis()
        db.cards().upsertAll(cards.distinctBy { it.id }.map { entity(it, now) })
    }

    suspend fun local(id: String): Card? = db.cards().get(id)?.let { decode(it.id, it.json, it.updatedAt) }

    /** Local copy if we have one, otherwise fetched from Scryfall (and cached). */
    suspend fun get(id: String): Card = local(id) ?: api.cardById(id).also { cache(it) }

    /** Always fetches fresh data (prices) from Scryfall and updates the cache. */
    suspend fun fetchFresh(id: String): Card = api.cardById(id).also { cache(it) }

    /** Fetches fresh data; only writes it to the local cache if the card was already stored there. */
    suspend fun fetchFreshIfCached(id: String, cachedLocally: Boolean): Card =
        api.cardById(id).also { if (cachedLocally) cache(it) }

    suspend fun search(query: String, unique: String = "cards", order: String = "name"): CardPage =
        api.search(query, unique = unique, order = order)

    suspend fun nextPage(url: String): CardPage = api.page(url)

    suspend fun autocomplete(text: String): List<String> = api.autocomplete(text)

    suspend fun named(fuzzy: String, set: String? = null): Card? = api.named(fuzzy = fuzzy, set = set)

    suspend fun exact(name: String): Card? = api.named(exact = name)

    suspend fun byCollectorNumber(set: String, number: String): Card? = api.byCollectorNumber(set, number)

    suspend fun random(query: String? = null): Card = api.random(query)

    suspend fun rulings(card: Card): List<Ruling> =
        rulingsCache[card.oracleId] ?: api.rulings(card.id).also { rulingsCache[card.oracleId] = it }

    suspend fun printings(card: Card): List<Card> =
        printingsCache[card.oracleId] ?: api.printings(card.oracleId).also { printingsCache[card.oracleId] = it }

    /** Re-downloads the given cards (in batches of 75) to update prices. Returns how many were refreshed. */
    suspend fun refresh(ids: Collection<String>, onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }): Int {
        val all = ids.distinct()
        var done = 0
        var refreshed = 0
        for (chunk in all.chunked(75)) {
            val result = api.collection(chunk.map { ScryfallApi.idIdentifier(it) })
            cacheAll(result.found)
            refreshed += result.found.size
            done += chunk.size
            onProgress(done, all.size)
        }
        return refreshed
    }

    /**
     * Resolves many card requests with as few API calls as possible: one batched lookup using the most
     * specific identifier, a name-only retry for anything whose set/number didn't match, then a fuzzy
     * name search for whatever is still missing (catches typos and missing accents).
     */
    suspend fun resolve(requests: List<CardRequest>, onProgress: (String) -> Unit = {}): List<Card?> {
        val results = arrayOfNulls<Card>(requests.size)
        if (requests.isEmpty()) return emptyList()

        onProgress("Looking up ${requests.size} cards…")
        val identifiers: List<JsonObject?> = requests.map(::identifierFor)
        val first = api.collection(identifiers.filterNotNull()).found
        requests.forEachIndexed { i, req ->
            if (identifiers[i] != null) results[i] = first.firstOrNull { matches(req, it) }
        }

        val retry = requests.indices.filter { i ->
            results[i] == null && !requests[i].name.isNullOrBlank() &&
                (requests[i].setCode != null || requests[i].scryfallId != null)
        }
        if (retry.isNotEmpty()) {
            val second = api.collection(retry.map { ScryfallApi.nameIdentifier(requests[it].name!!) }).found
            for (i in retry) results[i] = second.firstOrNull { nameEquals(requests[i].name!!, it) }
        }

        val fuzzy = requests.indices.filter { results[it] == null && !requests[it].name.isNullOrBlank() }.take(MAX_FUZZY)
        fuzzy.forEachIndexed { n, i ->
            onProgress("Checking spelling (${n + 1}/${fuzzy.size})…")
            results[i] = runCatching { api.named(fuzzy = requests[i].name) }.getOrNull()
        }

        cacheAll(results.filterNotNull())
        return results.toList()
    }

    private fun identifierFor(r: CardRequest): JsonObject? = when {
        r.scryfallId != null -> ScryfallApi.idIdentifier(r.scryfallId)
        r.setCode != null && r.collectorNumber != null -> ScryfallApi.printIdentifier(r.setCode, r.collectorNumber)
        !r.name.isNullOrBlank() -> ScryfallApi.nameIdentifier(r.name, r.setCode)
        else -> null
    }

    private fun matches(r: CardRequest, c: Card): Boolean = when {
        r.scryfallId != null -> c.id.equals(r.scryfallId, ignoreCase = true)
        r.setCode != null && r.collectorNumber != null ->
            c.setCode.equals(r.setCode, true) && c.collectorNumber.equals(r.collectorNumber, true)
        !r.name.isNullOrBlank() -> nameEquals(r.name, c) && (r.setCode == null || c.setCode.equals(r.setCode, true))
        else -> false
    }

    private fun nameEquals(name: String, c: Card): Boolean {
        val n = CardTextExtractor.normalize(name)
        return CardTextExtractor.normalize(c.name) == n ||
            c.faces.any { CardTextExtractor.normalize(it.name) == n } ||
            CardTextExtractor.normalize(c.name.substringBefore(" // ")) == n
    }

    suspend fun pruneCache() {
        db.cards().pruneUnreferenced(System.currentTimeMillis() - 30L * 24 * 3600 * 1000)
    }

    private companion object {
        const val MAX_FUZZY = 30
    }
}
