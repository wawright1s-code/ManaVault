package com.manavault.app.core.deck

import com.manavault.app.core.mana.ManaSymbols
import com.manavault.app.core.model.Card

data class DeckCardEntry(val card: Card, val quantity: Int, val board: Board)

data class DeckStats(
    val mainCount: Int,
    val sideCount: Int,
    val commanderCount: Int,
    val maybeCount: Int,
    /** Index 0..6 = mana value 0..6, index 7 = 7+. Non-land cards in the main deck and command zone. */
    val curve: List<Int>,
    val averageManaValue: Double,
    val colorPips: Map<String, Int>,
    val typeCounts: List<Pair<String, Int>>,
    val landCount: Int,
    val colorIdentity: List<String>,
)

enum class Severity { ERROR, WARNING }

data class LegalityIssue(val severity: Severity, val message: String, val cardName: String? = null)

data class FormatRule(
    val id: String,
    val name: String,
    val minDeckSize: Int = 60,
    val exactDeckSize: Int? = null,
    val maxSideboard: Int? = 15,
    val maxCopies: Int = 4,
    val hasCommander: Boolean = false,
    val checksLegality: Boolean = true,
)

object Formats {
    val CASUAL = FormatRule("casual", "Casual", minDeckSize = 0, maxSideboard = null, maxCopies = Int.MAX_VALUE, checksLegality = false)
    val COMMANDER = FormatRule("commander", "Commander", minDeckSize = 100, exactDeckSize = 100, maxSideboard = null, maxCopies = 1, hasCommander = true)

    val all: List<FormatRule> = listOf(
        CASUAL,
        COMMANDER,
        FormatRule("standard", "Standard"),
        FormatRule("pioneer", "Pioneer"),
        FormatRule("modern", "Modern"),
        FormatRule("legacy", "Legacy"),
        FormatRule("vintage", "Vintage"),
        FormatRule("pauper", "Pauper"),
        FormatRule("historic", "Historic"),
        FormatRule("timeless", "Timeless"),
        FormatRule("premodern", "Premodern"),
    )

    fun byId(id: String?): FormatRule = all.firstOrNull { it.id == id } ?: CASUAL
}

object DeckAnalysis {

    private val TYPE_ORDER = listOf("Creature", "Planeswalker", "Battle", "Instant", "Sorcery", "Artifact", "Enchantment", "Land", "Other")
    private val ANY_NUMBER = Regex("A deck can have any number of cards named", RegexOption.IGNORE_CASE)
    private val UP_TO = Regex("A deck can have up to (\\w+) cards named", RegexOption.IGNORE_CASE)
    private val WORD_NUMBERS = mapOf("two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10)

    fun primaryType(card: Card): String {
        val t = card.faces.firstOrNull()?.typeLine?.ifBlank { null } ?: card.typeLine.substringBefore(" // ")
        return when {
            "Creature" in t -> "Creature"
            "Land" in t -> "Land"
            "Planeswalker" in t -> "Planeswalker"
            "Battle" in t -> "Battle"
            "Instant" in t -> "Instant"
            "Sorcery" in t -> "Sorcery"
            "Artifact" in t -> "Artifact"
            "Enchantment" in t -> "Enchantment"
            else -> "Other"
        }
    }

    fun typeOrder(type: String): Int = TYPE_ORDER.indexOf(type).let { if (it < 0) TYPE_ORDER.size else it }

    fun stats(entries: List<DeckCardEntry>): DeckStats {
        fun count(b: Board) = entries.filter { it.board == b }.sumOf { it.quantity }
        val playing = entries.filter { it.board == Board.MAIN || it.board == Board.COMMANDER }

        val curve = MutableList(8) { 0 }
        var mvTotal = 0.0
        var mvCards = 0
        val pips = linkedMapOf<String, Int>()
        val types = linkedMapOf<String, Int>()
        var lands = 0
        for (e in playing) {
            val type = primaryType(e.card)
            types[type] = (types[type] ?: 0) + e.quantity
            if (type == "Land") {
                lands += e.quantity
                continue
            }
            val mv = e.card.cmc.toInt().coerceIn(0, 7)
            curve[mv] += e.quantity
            mvTotal += e.card.cmc * e.quantity
            mvCards += e.quantity
            for ((color, n) in ManaSymbols.colorPips(e.card.displayManaCost)) {
                pips[color] = (pips[color] ?: 0) + n * e.quantity
            }
        }
        val identity = ManaSymbols.sortColors(playing.flatMap { it.card.colorIdentity })
        return DeckStats(
            mainCount = count(Board.MAIN),
            sideCount = count(Board.SIDE),
            commanderCount = count(Board.COMMANDER),
            maybeCount = count(Board.MAYBE),
            curve = curve,
            averageManaValue = if (mvCards == 0) 0.0 else mvTotal / mvCards,
            colorPips = ManaSymbols.COLORS.filter { (pips[it] ?: 0) > 0 }.associateWith { pips[it]!! } +
                (if ((pips["C"] ?: 0) > 0) mapOf("C" to pips["C"]!!) else emptyMap()),
            typeCounts = types.entries.sortedBy { typeOrder(it.key) }.map { it.key to it.value },
            landCount = lands,
            colorIdentity = identity,
        )
    }

    /** How many copies of this card a deck may contain, or null for "any number". */
    fun copyLimit(card: Card, format: FormatRule): Int? {
        if (card.isBasicLand) return null
        val text = card.allOracleText
        if (ANY_NUMBER.containsMatchIn(text)) return null
        UP_TO.find(text)?.let { m -> WORD_NUMBERS[m.groupValues[1].lowercase()]?.let { return it } }
        if (card.legalityIn(format.id) == "restricted") return 1
        return format.maxCopies
    }

    fun checkLegality(format: FormatRule, entries: List<DeckCardEntry>): List<LegalityIssue> {
        if (format.id == Formats.CASUAL.id) return emptyList()
        val issues = mutableListOf<LegalityIssue>()
        val counted = entries.filter { e ->
            when (e.board) {
                Board.MAIN, Board.COMMANDER -> true
                Board.SIDE -> !format.hasCommander
                Board.MAYBE -> false
            }
        }
        val deckSize = entries.filter { it.board == Board.MAIN || it.board == Board.COMMANDER }.sumOf { it.quantity }
        val sideSize = entries.filter { it.board == Board.SIDE }.sumOf { it.quantity }

        // Deck size
        if (format.exactDeckSize != null && deckSize != format.exactDeckSize) {
            issues += LegalityIssue(Severity.ERROR, "${format.name} decks must have exactly ${format.exactDeckSize} cards (this one has $deckSize).")
        } else if (format.exactDeckSize == null && deckSize < format.minDeckSize) {
            issues += LegalityIssue(Severity.ERROR, "${format.name} decks need at least ${format.minDeckSize} main-deck cards (this one has $deckSize).")
        }
        if (format.maxSideboard != null && sideSize > format.maxSideboard) {
            issues += LegalityIssue(Severity.ERROR, "Sideboard has $sideSize cards; the limit is ${format.maxSideboard}.")
        }

        // Card legality
        if (format.checksLegality) {
            for (e in counted.distinctBy { it.card.oracleId }) {
                when (e.card.legalityIn(format.id)) {
                    "legal", "restricted" -> Unit
                    "banned" -> issues += LegalityIssue(Severity.ERROR, "${e.card.name} is banned in ${format.name}.", e.card.name)
                    else -> issues += LegalityIssue(Severity.ERROR, "${e.card.name} is not legal in ${format.name}.", e.card.name)
                }
            }
        }

        // Copy limits (main + sideboard combined, by card name)
        for ((_, group) in counted.groupBy { it.card.oracleId }) {
            val card = group.first().card
            val limit = copyLimit(card, format) ?: continue
            val total = group.sumOf { it.quantity }
            if (total > limit) {
                val what = if (limit == 1) "only 1 copy" else "up to $limit copies"
                issues += LegalityIssue(Severity.ERROR, "${card.name}: $total copies, but ${format.name} allows $what.", card.name)
            }
        }

        // Commander-specific checks
        if (format.hasCommander) {
            val commanders = entries.filter { it.board == Board.COMMANDER }
            if (commanders.isEmpty()) {
                issues += LegalityIssue(Severity.WARNING, "No commander chosen. Long-press a card and pick \"Set as commander\".")
            } else {
                if (commanders.size > 2) {
                    issues += LegalityIssue(Severity.ERROR, "A deck can have at most two commanders (and only with Partner, Background or similar).")
                }
                for (c in commanders) {
                    val text = c.card.allOracleText
                    val ok = (c.card.isLegendary && c.card.isCreature) ||
                        text.contains("can be your commander", true) ||
                        c.card.typeLine.contains("Background")
                    if (!ok) issues += LegalityIssue(Severity.WARNING, "${c.card.name} normally can't be a commander.", c.card.name)
                }
                val identity = commanders.flatMap { it.card.colorIdentity }.toSet()
                for (e in entries.filter { it.board == Board.MAIN }.distinctBy { it.card.oracleId }) {
                    val outside = e.card.colorIdentity.filter { it !in identity }
                    if (outside.isNotEmpty()) {
                        issues += LegalityIssue(
                            Severity.ERROR,
                            "${e.card.name} is outside your commander's color identity (${ManaSymbols.sortColors(outside).joinToString("")}).",
                            e.card.name,
                        )
                    }
                }
            }
        }
        return issues
    }
}
