package com.manavault.app.ui.decks

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.manavault.app.AppGraph
import com.manavault.app.core.deck.Board
import com.manavault.app.core.deck.DeckAnalysis
import com.manavault.app.core.deck.DeckCardEntry
import com.manavault.app.core.deck.DeckPrompt
import com.manavault.app.core.interaction.ChatTurn
import com.manavault.app.ui.interactions.Usage
import com.manavault.app.core.deck.DeckStats
import com.manavault.app.core.deck.LegalityIssue
import com.manavault.app.core.model.Card
import com.manavault.app.core.model.Currency
import com.manavault.app.data.repo.DeckWithCards
import com.manavault.app.data.repo.ImportReport
import com.manavault.app.ui.components.userMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DeckGroup(val title: String, val board: Board, val entries: List<DeckCardEntry>) {
    val count: Int get() = entries.sumOf { it.quantity }
}

data class DeckDetailUi(
    val loaded: Boolean = false,
    val deck: DeckWithCards? = null,
    val groups: List<DeckGroup> = emptyList(),
    val stats: DeckStats? = null,
    val issues: List<LegalityIssue> = emptyList(),
    val currency: Currency = Currency.USD,
    val value: Double = 0.0,
    /** Copies owned per Oracle card (any printing). */
    val owned: Map<String, Int> = emptyMap(),
    val missingCards: Int = 0,
    val selection: Set<String> = emptySet(),
)

fun DeckCardEntry.key(): String = card.id + "|" + board.key

data class AnalysisUi(
    val thread: List<ChatTurn> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
    val usage: Usage? = null,
) {
    /** Turns shown to the player: everything after the generated deck prompt. */
    val visible: List<ChatTurn> get() = thread.drop(1)
}

sealed interface DeckTask {
    data class Running(val message: String) : DeckTask
    data class Done(val report: ImportReport) : DeckTask
}

class DeckDetailViewModel(private val graph: AppGraph, val deckId: Long) : ViewModel() {

    private val selection = MutableStateFlow<Set<String>>(emptySet())
    val task = MutableStateFlow<DeckTask?>(null)
    val messages = MutableStateFlow<String?>(null)
    val analysis = MutableStateFlow(AnalysisUi())

    private val ownedByOracle = graph.collection.owned.map { list ->
        list.groupBy { it.card.oracleId }.mapValues { (_, v) -> v.sumOf { it.quantity } }
    }

    val ui: StateFlow<DeckDetailUi> = combine(
        graph.decks.observeDeck(deckId),
        ownedByOracle,
        graph.settings.settings,
        selection,
    ) { deck, owned, settings, sel ->
        if (deck == null) return@combine DeckDetailUi(loaded = true)
        val entries = deck.entries
        val groups = buildList {
            entries.filter { it.board == Board.COMMANDER }.takeIf { it.isNotEmpty() }?.let {
                add(DeckGroup(if (it.size > 1) "Commanders" else "Commander", Board.COMMANDER, it.sortedBy { e -> e.card.name }))
            }
            entries.filter { it.board == Board.MAIN }
                .groupBy { DeckAnalysis.primaryType(it.card) }
                .toSortedMap(compareBy<String> { DeckAnalysis.typeOrder(it) })
                .forEach { (type, list) ->
                    add(DeckGroup(plural(type), Board.MAIN, list.sortedWith(compareBy<DeckCardEntry> { it.card.cmc }.thenBy { it.card.name })))
                }
            entries.filter { it.board == Board.SIDE }.takeIf { it.isNotEmpty() }?.let {
                add(DeckGroup("Sideboard", Board.SIDE, it.sortedBy { e -> e.card.name }))
            }
            entries.filter { it.board == Board.MAYBE }.takeIf { it.isNotEmpty() }?.let {
                add(DeckGroup("Maybeboard", Board.MAYBE, it.sortedBy { e -> e.card.name }))
            }
        }
        // Copies needed vs. owned, per Oracle card, across main + commander + sideboard.
        val needed = entries.filter { it.board != Board.MAYBE }.groupBy { it.card.oracleId }.mapValues { (_, v) -> v.sumOf { it.quantity } }
        val missing = needed.entries.sumOf { (oracle, n) -> (n - (owned[oracle] ?: 0)).coerceAtLeast(0) }
        DeckDetailUi(
            loaded = true,
            deck = deck,
            groups = groups,
            stats = DeckAnalysis.stats(entries),
            issues = DeckAnalysis.checkLegality(deck.format, entries),
            currency = settings.currency,
            value = deck.value(settings.currency),
            owned = owned,
            missingCards = missing,
            selection = sel.filter { k -> entries.any { it.key() == k } }.toSet(),
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DeckDetailUi())

    private fun plural(type: String) = when (type) {
        "Sorcery" -> "Sorceries"
        "Other" -> "Other"
        else -> type + "s"
    }

    private fun launchSafely(block: suspend () -> Unit) = viewModelScope.launch {
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            messages.value = e.userMessage()
        }
    }

    fun setQuantity(e: DeckCardEntry, q: Int) = launchSafely { graph.decks.setQuantity(deckId, e.card.id, e.board, q) }
    fun move(e: DeckCardEntry, to: Board) = launchSafely { graph.decks.move(deckId, e.card.id, e.board, to) }
    fun setCommander(e: DeckCardEntry) = launchSafely { graph.decks.setCommander(deckId, e.card.id, e.board) }
    fun remove(e: DeckCardEntry) = launchSafely { graph.decks.setQuantity(deckId, e.card.id, e.board, 0) }
    fun replacePrinting(e: DeckCardEntry, card: Card) = launchSafely { graph.decks.replacePrinting(deckId, e.card.id, e.board, card) }
    fun addCard(card: Card, board: Board) = launchSafely { graph.decks.addCard(deckId, card, board) }

    fun rename(name: String) = launchSafely {
        ui.value.deck?.deck?.let { graph.decks.update(it.copy(name = name.trim().ifEmpty { it.name })) }
    }

    fun setFormat(format: String) = launchSafely {
        ui.value.deck?.deck?.let { graph.decks.update(it.copy(format = format)) }
    }

    fun delete(onDeleted: () -> Unit) = launchSafely {
        graph.decks.delete(deckId)
        onDeleted()
    }

    fun duplicate(onCreated: (Long) -> Unit) = launchSafely { onCreated(graph.decks.duplicate(deckId)) }

    fun importList(text: String, replace: Boolean) {
        viewModelScope.launch {
            task.value = DeckTask.Running("Reading list…")
            try {
                val report = graph.decks.importList(deckId, text, replace) { task.value = DeckTask.Running(it) }
                task.value = DeckTask.Done(report)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                task.value = null
                messages.value = e.userMessage()
            }
        }
    }

    suspend fun exportText(includePrinting: Boolean): String = graph.decks.exportText(deckId, includePrinting)

    /** "2 Card Name" lines for every card you don't own enough copies of. */
    fun missingList(): String {
        val u = ui.value
        val entries = u.deck?.entries.orEmpty().filter { it.board != Board.MAYBE }
        return entries.groupBy { it.card.oracleId }.mapNotNull { (oracle, list) ->
            val need = list.sumOf { it.quantity } - (u.owned[oracle] ?: 0)
            if (need > 0) "$need ${list.first().card.name}" else null
        }.sorted().joinToString("\n")
    }

    fun toggleSelect(e: DeckCardEntry) = selection.update { if (e.key() in it) it - e.key() else it + e.key() }
    fun clearSelection() { selection.value = emptySet() }
    fun selectedCards(): List<Card> {
        val sel = ui.value.selection
        return ui.value.deck?.entries.orEmpty().filter { it.key() in sel }.map { it.card }.distinctBy { it.oracleId }
    }

    /** Asks Claude to review the whole deck (first call) or answers a follow-up question. */
    fun analyze(text: String) {
        val a = analysis.value
        if (a.loading) return
        val settings = graph.settings.settings.value
        val deck = ui.value.deck ?: return
        val turns = if (a.thread.isEmpty()) {
            listOf(ChatTurn.user(DeckPrompt.userMessage(deck.deck.name, deck.format, deck.entries, ui.value.issues, text)))
        } else {
            if (text.isBlank()) return
            a.thread + ChatTurn.user(text.trim())
        }
        analysis.update { it.copy(thread = turns, loading = true, error = null) }
        viewModelScope.launch {
            try {
                val reply = graph.claude.send(settings.apiKey, settings.model, DeckPrompt.SYSTEM, turns)
                val cut = if (reply.stopReason == "max_tokens") "\n\n*(Answer cut off — ask a follow-up to continue.)*" else ""
                analysis.update {
                    val prev = it.usage
                    it.copy(
                        thread = turns + ChatTurn.assistant(reply.text + cut),
                        usage = Usage(settings.model, (prev?.inputTokens ?: 0) + reply.inputTokens, (prev?.outputTokens ?: 0) + reply.outputTokens),
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                analysis.update { it.copy(thread = a.thread, error = e.userMessage()) }
            } finally {
                analysis.update { it.copy(loading = false) }
            }
        }
    }

    fun resetAnalysis() { analysis.value = AnalysisUi() }

    fun dismissTask() { task.value = null }
    fun messageShown() { messages.value = null }
}
