package com.manavault.app

import android.app.Application
import android.content.Context
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.SvgDecoder
import com.manavault.app.core.model.Card
import com.manavault.app.data.db.AppDatabase
import com.manavault.app.data.net.ClaudeApi
import com.manavault.app.data.net.Http
import com.manavault.app.data.net.ScryfallApi
import com.manavault.app.data.repo.BackupRepository
import com.manavault.app.data.repo.CardRepository
import com.manavault.app.data.repo.CollectionRepository
import com.manavault.app.data.repo.DeckRepository
import com.manavault.app.data.repo.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class ManaVaultApp : Application(), ImageLoaderFactory {

    lateinit var graph: AppGraph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = AppGraph(this)
    }

    // Coil: decode Scryfall's SVG mana symbols as well as card images.
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .components { add(SvgDecoder.Factory()) }
        .crossfade(true)
        .build()
}

/** Manual dependency graph — small enough that a DI framework isn't worth it. */
class AppGraph(context: Context) {
    val db: AppDatabase = AppDatabase.build(context)
    val scryfall = ScryfallApi(Http.client)
    val claude = ClaudeApi(Http.client)
    val settings = SettingsRepository(context)
    val cards = CardRepository(scryfall, db)
    val collection = CollectionRepository(db, cards, settings)
    val decks = DeckRepository(db, cards)
    val backup = BackupRepository(db, cards, settings)
    val tray = InteractionTray()
}

/** Cards picked for the Interaction Lab, shared across screens. */
class InteractionTray {
    private val _cards = MutableStateFlow<List<Card>>(emptyList())
    val cards: StateFlow<List<Card>> = _cards.asStateFlow()

    fun add(card: Card) = _cards.update { list -> if (list.any { it.oracleId == card.oracleId }) list else list + card }
    fun addAll(cards: List<Card>) = cards.forEach(::add)
    fun remove(cardId: String) = _cards.update { list -> list.filterNot { it.id == cardId } }
    fun clear() { _cards.value = emptyList() }
    fun contains(card: Card): Boolean = _cards.value.any { it.oracleId == card.oracleId }
}

val Context.graph: AppGraph get() = (applicationContext as ManaVaultApp).graph
