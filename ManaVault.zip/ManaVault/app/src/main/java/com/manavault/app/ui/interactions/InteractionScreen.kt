package com.manavault.app.ui.interactions

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.manavault.app.core.interaction.ClaudeProtocol
import com.manavault.app.core.interaction.InteractionNote
import com.manavault.app.core.model.Card
import com.manavault.app.core.text.MiniMarkdown
import com.manavault.app.graph
import com.manavault.app.ui.Navigator
import com.manavault.app.ui.components.AnswerCard
import com.manavault.app.ui.components.CardImage
import com.manavault.app.ui.components.FollowUpComposer
import com.manavault.app.ui.components.QuestionBubble
import com.manavault.app.ui.components.CardSearchDialog
import com.manavault.app.ui.components.EmptyState
import com.manavault.app.ui.components.ManaCost
import com.manavault.app.ui.components.ScreenScaffold
import com.manavault.app.ui.components.SectionHeader
import com.manavault.app.ui.components.SymbolText
import kotlinx.coroutines.launch

@Composable
fun InteractionScreen(nav: Navigator) {
    val graph = LocalContext.current.graph
    val vm: InteractionViewModel = viewModel { InteractionViewModel(graph) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val focus = LocalFocusManager.current
    val listState = rememberLazyListState()
    var adding by remember { mutableStateOf(false) }

    LaunchedEffect(ui.error) {
        ui.error?.let { snackbar.showSnackbar(it); vm.dismissError() }
    }
    // Scroll to the newest answer when it arrives.
    LaunchedEffect(ui.answer, ui.followUps.size) {
        // Items: 0 picked cards, 1 question box, 2 first answer, then follow-ups in order.
        if (ui.answer != null) listState.animateScrollToItem(2 + ui.followUps.size)
    }

    ScreenScaffold(
        title = "Interaction Lab",
        snackbarHost = snackbar,
        actions = {
            if (ui.cards.isNotEmpty()) IconButton(onClick = vm::clearAll) { Icon(Icons.Filled.DeleteSweep, "Clear all") }
            IconButton(onClick = nav::settings) { Icon(Icons.Filled.Settings, "Settings") }
        },
    ) { padding ->
        if (ui.cards.isEmpty()) {
            EmptyState(
                icon = Icons.Filled.AutoAwesome,
                title = "How do these cards work together?",
                message = "Pick any number of cards and get a judge-level explanation of how they interact — timing, triggers, combos and the rules that matter.\n\nTip: long-press cards in your collection or a deck to select several at once.",
                modifier = Modifier.padding(padding),
                action = { Button(onClick = { adding = true }) { Text("Pick cards") } },
            )
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).imePadding(),
                state = listState,
                contentPadding = PaddingValues(bottom = 40.dp),
            ) {
                item(key = "picked") {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(ui.cards, key = { it.id }) { card ->
                            PickedCard(card, onOpen = { nav.card(card.id) }, onRemove = { vm.remove(card) })
                        }
                        item {
                            Box(
                                Modifier.width(84.dp).aspectRatio(0.716f).clip(RoundedCornerShape(8.dp))
                                    .border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                                    .clickable { adding = true },
                                contentAlignment = Alignment.Center,
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Filled.Add, null)
                                    Text("Add", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
                item(key = "ask") {
                    Column(Modifier.padding(horizontal = 16.dp)) {
                        OutlinedTextField(
                            value = ui.context,
                            onValueChange = vm::setContext,
                            label = { Text("Situation or question (optional)") },
                            placeholder = { Text("e.g. My opponent controls Rest in Peace") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 4,
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = { focus.clearFocus(); vm.explain() },
                            enabled = !ui.loading,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            if (ui.loading && ui.answer == null) {
                                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                                Spacer(Modifier.width(10.dp))
                                Text(ui.loadingLabel.ifBlank { "Working…" })
                            } else {
                                Icon(Icons.Filled.AutoAwesome, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    when {
                                        !ui.settings.hasApiKey -> "Show rules notes"
                                        ui.answer != null && ui.stale -> "Explain again"
                                        ui.answer != null -> "Explain again"
                                        ui.cards.size == 1 -> "Explain this card"
                                        else -> "Explain ${ui.cards.size} cards"
                                    }
                                )
                            }
                        }
                        if (!ui.settings.hasApiKey) {
                            Row(
                                Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.secondaryContainer).clickable(onClick = nav::settings).padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Filled.Key, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    "Add your Anthropic API key in Settings for full AI explanations. Free mode shows official rulings and built-in rules notes.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                )
                            }
                        }
                        if (ui.stale) {
                            Text(
                                "Your card selection changed since the last explanation.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(top = 6.dp),
                            )
                        }
                    }
                }

                ui.answer?.let { answer ->
                    item(key = "answer") {
                        AnswerCard(
                            markdown = answer,
                            footer = buildString {
                                val label = ClaudeProtocol.MODELS.firstOrNull { it.id == ui.usage?.model }?.label ?: ui.usage?.model
                                append(label ?: "Claude")
                                ui.usage?.costUsd?.let { append(" · about ").append(if (it < 0.01) "<1¢" else "%.0f¢".format(it * 100)) }
                                if (ui.truncated) append(" · rulings omitted for large selections")
                            },
                            onCopy = {
                                clipboard.setText(AnnotatedString(MiniMarkdown.toPlainText(answer)))
                                scope.launch { snackbar.showSnackbar("Copied") }
                            },
                        )
                    }
                    items(ui.followUps.size, key = { "f$it" }) { i ->
                        val turn = ui.followUps[i]
                        if (turn.role == "user") QuestionBubble(turn.text) else AnswerCard(turn.text, footer = null, onCopy = {
                            clipboard.setText(AnnotatedString(MiniMarkdown.toPlainText(turn.text)))
                            scope.launch { snackbar.showSnackbar("Copied") }
                        })
                    }
                    item(key = "followup") { FollowUpComposer(loading = ui.loading, label = ui.loadingLabel, onSend = vm::askFollowUp) }
                }

                if (ui.showResults || ui.notes.isNotEmpty()) {
                    if (ui.notes.isNotEmpty()) {
                        item(key = "notes-h") { SectionHeader("Rules notes", Modifier.padding(horizontal = 16.dp)) }
                        items(ui.notes.size, key = { "n$it" }) { i -> NoteCard(ui.notes[i]) }
                    }
                    if (ui.reminders.isNotEmpty() && ui.showResults) {
                        item(key = "kw-h") { SectionHeader("Keywords", Modifier.padding(horizontal = 16.dp)) }
                        items(ui.reminders, key = { "k-" + it.keyword }) { r ->
                            Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                                Text(r.keyword + (r.rule?.let { "  ·  $it" } ?: ""), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                                SymbolText(r.text, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
                if (ui.showResults) {
                    item(key = "oracle-h") { SectionHeader("Card text & official rulings", Modifier.padding(horizontal = 16.dp)) }
                    items(ui.cards, key = { "o-" + it.id }) { card ->
                        OracleCard(card, ui.rulings[card.oracleId])
                    }
                }
            }
        }
    }

    if (adding) {
        CardSearchDialog(title = "Add cards", keepOpen = true, onDismiss = { adding = false }, onPick = vm::add)
    }
}

@Composable
private fun PickedCard(card: Card, onOpen: () -> Unit, onRemove: () -> Unit) {
    Column(Modifier.width(84.dp)) {
        Box {
            CardImage(card.frontImage, card.name, Modifier.fillMaxWidth().clickable(onClick = onOpen), cornerRadius = 6.dp)
            Box(
                Modifier.align(Alignment.TopEnd).padding(3.dp).size(22.dp).clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.65f)).clickable(onClick = onRemove),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Close, "Remove", tint = Color.White, modifier = Modifier.size(14.dp))
            }
        }
        Text(card.name, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun NoteCard(note: InteractionNote) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(note.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                note.rule?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary) }
            }
            Spacer(Modifier.height(4.dp))
            SymbolText(note.body, style = MaterialTheme.typography.bodyMedium)
            if (note.cards.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(note.cards.joinToString(" · "), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun OracleCard(card: Card, rulings: List<com.manavault.app.core.model.Ruling>?) {
    var expanded by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Column(Modifier.padding(14.dp).animateContentSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(card.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                ManaCost(card.displayManaCost, size = 14.dp)
            }
            Text(card.displayTypeLine, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            card.allOracleText.split('\n').filter { it.isNotBlank() }.forEach {
                SymbolText(it, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(bottom = 4.dp))
            }
            val count = rulings?.size ?: 0
            if (rulings != null && count > 0) {
                TextButton(onClick = { expanded = !expanded }, contentPadding = PaddingValues(0.dp)) {
                    Text("$count official ruling${if (count == 1) "" else "s"}")
                    Icon(if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, null)
                }
                if (expanded) {
                    rulings.forEach { r ->
                        Column(Modifier.padding(bottom = 8.dp)) {
                            Text(r.publishedAt, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            SymbolText(r.comment, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            } else if (rulings != null) {
                Text("No official rulings.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
