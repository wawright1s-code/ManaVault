package com.manavault.app.core.scryfall

import com.manavault.app.core.mana.ManaSymbols
import com.manavault.app.core.model.Currency
import java.util.Locale

enum class ColorMode(val label: String) {
    INCLUDES("Including"),
    EXACTLY("Exactly"),
    AT_MOST("At most"),
    IDENTITY("Fits commander"),
}

/** Point-and-tap search filters, turned into Scryfall search syntax by [SearchQueryBuilder]. */
data class SearchFilters(
    val colors: Set<String> = emptySet(),
    val colorMode: ColorMode = ColorMode.INCLUDES,
    val types: Set<String> = emptySet(),
    val legendary: Boolean = false,
    val commanders: Boolean = false,
    val format: String? = null,
    val rarities: Set<String> = emptySet(),
    val minMv: Int? = null,
    val maxMv: Int? = null,
    val maxPrice: Double? = null,
    val rulesText: String = "",
) {
    /** Number of filter groups in use, for the badge on the Filters button. */
    val activeCount: Int
        get() = listOf(
            colors.isNotEmpty(), types.isNotEmpty(), legendary, commanders, format != null, rarities.isNotEmpty(),
            minMv != null || maxMv != null, maxPrice != null, rulesText.isNotBlank(),
        ).count { it }

    val isEmpty: Boolean get() = activeCount == 0

    companion object {
        val TYPES = listOf("Creature", "Instant", "Sorcery", "Artifact", "Enchantment", "Planeswalker", "Land", "Battle")
        val RARITIES = listOf("common", "uncommon", "rare", "mythic")
        val FORMATS = listOf(
            "standard" to "Standard", "pioneer" to "Pioneer", "modern" to "Modern", "legacy" to "Legacy",
            "vintage" to "Vintage", "commander" to "Commander", "pauper" to "Pauper", "historic" to "Historic",
        )
    }
}

object SearchQueryBuilder {

    fun build(text: String, f: SearchFilters, currency: Currency = Currency.USD): String {
        val parts = mutableListOf<String>()
        text.trim().takeIf { it.isNotEmpty() }?.let { parts += it }

        val colored = ManaSymbols.sortColors(f.colors.filter { it in ManaSymbols.COLORS }).joinToString("").lowercase()
        val colorless = "C" in f.colors
        when {
            colored.isNotEmpty() -> parts += when (f.colorMode) {
                ColorMode.INCLUDES -> "c>=$colored"
                ColorMode.EXACTLY -> "c=$colored"
                ColorMode.AT_MOST -> "c<=$colored"
                ColorMode.IDENTITY -> "id<=$colored"
            }
            colorless -> parts += if (f.colorMode == ColorMode.IDENTITY) "id=c" else "c=c"
        }

        if (f.types.isNotEmpty()) parts += orGroup(f.types.sortedBy { SearchFilters.TYPES.indexOf(it) }.map { "t:" + it.lowercase() })
        if (f.legendary) parts += "t:legendary"
        if (f.commanders) parts += "is:commander"
        f.format?.let { parts += "f:$it" }
        if (f.rarities.isNotEmpty()) parts += orGroup(f.rarities.sortedBy { SearchFilters.RARITIES.indexOf(it) }.map { "r:$it" })
        f.minMv?.let { parts += "mv>=$it" }
        f.maxMv?.let { parts += "mv<=$it" }
        f.maxPrice?.let { parts += currency.key + "<=" + String.format(Locale.US, "%.2f", it).trimEnd('0').trimEnd('.') }
        val rules = f.rulesText.replace("\"", "").trim()
        if (rules.isNotEmpty()) parts += "o:\"$rules\""
        return parts.joinToString(" ")
    }

    private fun orGroup(terms: List<String>): String =
        if (terms.size == 1) terms.single() else terms.joinToString(" or ", prefix = "(", postfix = ")")
}
