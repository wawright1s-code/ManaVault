package com.manavault.app.ui.scan

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.manavault.app.core.model.Card
import com.manavault.app.core.model.Currency
import com.manavault.app.core.model.Finish
import com.manavault.app.core.scan.ScanGeometry
import com.manavault.app.core.text.Format
import com.manavault.app.graph
import com.manavault.app.ui.Navigator
import com.manavault.app.ui.components.AddToDeckDialog
import com.manavault.app.ui.components.CardImage
import com.manavault.app.ui.components.CardSearchDialog
import com.manavault.app.ui.components.EmptyState
import com.manavault.app.ui.components.ManaCost
import com.manavault.app.ui.components.PrintingPickerDialog
import com.manavault.app.ui.components.QuantityStepper
import kotlinx.coroutines.launch

@Composable
fun ScanScreen(nav: Navigator) {
    val context = LocalContext.current
    val graph = context.graph
    val vm: ScanViewModel = viewModel { ScanViewModel(graph) }
    val state by vm.state.collectAsStateWithLifecycle()
    val settings by graph.settings.settings.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current

    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPermission = it }
    var showSearch by remember { mutableStateOf(false) }
    var printingFor by remember { mutableStateOf<Card?>(null) }
    var deckFor by remember { mutableStateOf<Card?>(null) }
    var cameraError by remember { mutableStateOf<String?>(null) }

    fun toast(msg: String) { scope.launch { snackbar.showSnackbar(msg) } }

    LaunchedEffect(state.result?.id) {
        if (state.result != null) haptics.performHapticFeedback(HapticFeedbackType.LongPress)
    }
    LaunchedEffect(state.session.size) {
        if (state.mode == ScanMode.BULK && state.session.isNotEmpty()) haptics.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!hasPermission) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                EmptyState(
                    icon = Icons.Filled.CameraAlt,
                    title = "Scan your cards",
                    message = "ManaVault reads the card name — and on newer cards the set and collector number — right on your phone to find the exact printing and its price.",
                    action = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) { Text("Allow camera") }
                            TextButton(onClick = { showSearch = true }) { Text("Search by name instead") }
                        }
                    },
                )
            }
        } else {
            CameraPreview(
                onFrame = vm::onFrame,
                torchOn = state.torch,
                onCameraError = { cameraError = it },
                modifier = Modifier.fillMaxSize().onSizeChanged { vm.setViewSize(it.width, it.height) },
            )
            GuideOverlay(highlight = state.result != null || state.lookingUp, modifier = Modifier.fillMaxSize())

            // Top controls
            Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ModeChip("Single", state.mode == ScanMode.SINGLE) { vm.setMode(ScanMode.SINGLE) }
                    Spacer(Modifier.width(8.dp))
                    ModeChip("Bulk add", state.mode == ScanMode.BULK) { vm.setMode(ScanMode.BULK) }
                    Spacer(Modifier.weight(1f))
                    OverlayIconButton(onClick = { showSearch = true }) { Icon(Icons.Filled.Keyboard, "Type a card name") }
                    Spacer(Modifier.width(8.dp))
                    OverlayIconButton(onClick = vm::toggleTorch) {
                        Icon(if (state.torch) Icons.Filled.FlashOn else Icons.Filled.FlashOff, "Flashlight")
                    }
                }
                Spacer(Modifier.height(10.dp))
                StatusPill(cameraError ?: state.status, state.reading.takeIf { state.result == null && state.lookingUp.not() && state.reading != null })
            }

            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()) {
                val result = state.result
                when {
                    result != null -> ResultPanel(
                        card = result,
                        currency = settings.currency,
                        onAdd = { qty, finish -> vm.addResult(result, qty, finish, ::toast) },
                        onPrinting = { printingFor = result },
                        onDeck = { deckFor = result },
                        onDetails = { nav.card(result.id) },
                        onInteract = { graph.tray.add(result); toast("Added to the Interaction Lab") },
                        onRescan = vm::dismissResult,
                    )
                    state.mode == ScanMode.BULK -> BulkPanel(
                        state = state,
                        currency = settings.currency,
                        onFinish = vm::setBulkFinish,
                        onUndo = vm::undo,
                        onClear = vm::clearSession,
                    )
                    state.session.isNotEmpty() -> SessionSummary(state, settings.currency, onClear = vm::clearSession)
                }
            }
        }
        SnackbarHost(snackbar, Modifier.align(Alignment.Center))
    }

    if (showSearch) {
        CardSearchDialog(
            title = "Find a card",
            onDismiss = { showSearch = false },
            onPick = { vm.showResult(it) },
        )
    }
    printingFor?.let { card ->
        PrintingPickerDialog(card, onDismiss = { printingFor = null }, onPick = { vm.showResult(it) })
    }
    deckFor?.let { card ->
        AddToDeckDialog(listOf(card), onDismiss = { deckFor = null }, onDone = ::toast)
    }
}

@Composable
private fun ModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        colors = FilterChipDefaults.filterChipColors(
            containerColor = Color.Black.copy(alpha = 0.45f),
            labelColor = Color.White,
            selectedContainerColor = MaterialTheme.colorScheme.primary,
            selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
        ),
    )
}

@Composable
private fun OverlayIconButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    IconButton(
        onClick = onClick,
        colors = IconButtonDefaults.iconButtonColors(containerColor = Color.Black.copy(alpha = 0.45f), contentColor = Color.White),
        content = content,
    )
}

@Composable
private fun StatusPill(status: String, reading: String?) {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Column(
            Modifier.clip(RoundedCornerShape(16.dp)).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(status, color = Color.White, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
            if (reading != null) {
                Text("“$reading”", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** Dims everything outside a card-shaped window and outlines it. */
@Composable
private fun GuideOverlay(highlight: Boolean, modifier: Modifier = Modifier) {
    val border by animateColorAsState(
        if (highlight) MaterialTheme.colorScheme.tertiary else Color.White.copy(alpha = 0.85f),
        label = "guideBorder",
    )
    Canvas(modifier) {
        val g = ScanGeometry.guide(size.width, size.height)
        val radius = CornerRadius(g.width * 0.05f, g.width * 0.05f)
        val mask = Path().apply {
            fillType = PathFillType.EvenOdd
            addRect(Rect(0f, 0f, size.width, size.height))
            addRoundRect(RoundRect(g.left, g.top, g.right, g.bottom, radius))
        }
        drawPath(mask, Color.Black.copy(alpha = 0.5f))
        drawRoundRect(
            color = border,
            topLeft = Offset(g.left, g.top),
            size = Size(g.width, g.height),
            cornerRadius = radius,
            style = Stroke(width = 3.dp.toPx()),
        )
        // Hint bands: the name line at the top and the set/number in the bottom-left corner.
        val bandH = g.height * 0.11f
        drawRoundRect(
            color = border.copy(alpha = 0.35f),
            topLeft = Offset(g.left + g.width * 0.05f, g.top + g.height * 0.03f),
            size = Size(g.width * 0.9f, bandH * 0.6f),
            cornerRadius = CornerRadius(8f, 8f),
            style = Stroke(width = 1.5.dp.toPx()),
        )
        drawRoundRect(
            color = border.copy(alpha = 0.35f),
            topLeft = Offset(g.left + g.width * 0.04f, g.bottom - g.height * 0.065f),
            size = Size(g.width * 0.4f, g.height * 0.05f),
            cornerRadius = CornerRadius(6f, 6f),
            style = Stroke(width = 1.5.dp.toPx()),
        )
    }
}

@Composable
private fun PanelSurface(content: @Composable () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        tonalElevation = 2.dp,
    ) {
        Column(Modifier.padding(16.dp)) { content() }
    }
}

@Composable
private fun ResultPanel(
    card: Card,
    currency: Currency,
    onAdd: (Int, Finish) -> Unit,
    onPrinting: () -> Unit,
    onDeck: () -> Unit,
    onDetails: () -> Unit,
    onInteract: () -> Unit,
    onRescan: () -> Unit,
) {
    var finish by remember(card.id) { mutableStateOf(card.defaultFinish) }
    var quantity by remember(card.id) { mutableStateOf(1) }
    PanelSurface {
        Row {
            CardImage(card.frontImage, card.name, Modifier.width(96.dp).clickable(onClick = onDetails), cornerRadius = 6.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(card.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                ManaCost(card.displayManaCost, Modifier.padding(vertical = 4.dp))
                Text(
                    "${card.setName} · ${card.setCode.uppercase()} #${card.collectorNumber}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                )
                TextButton(onClick = onPrinting, contentPadding = PaddingValues(0.dp)) { Text("Wrong printing? Change it") }
                Text(
                    Format.price(card.price(finish, currency), currency),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                card.availableFinishes.forEach { f ->
                    FilterChip(selected = finish == f, onClick = { finish = f }, label = { Text(f.label) })
                }
            }
            QuantityStepper(quantity, { quantity = it }, min = 1)
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { onAdd(quantity, finish) }, modifier = Modifier.fillMaxWidth()) {
            Text("Add to collection")
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onDeck) { Text("Add to deck") }
            TextButton(onClick = onInteract) {
                Icon(Icons.Filled.AutoAwesome, null, Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Interact")
            }
            TextButton(onClick = onDetails) { Text("Details") }
            TextButton(onClick = onRescan) { Text("Rescan") }
        }
    }
}

@Composable
private fun BulkPanel(
    state: ScanUiState,
    currency: Currency,
    onFinish: (Finish) -> Unit,
    onUndo: (SessionItem) -> Unit,
    onClear: () -> Unit,
) {
    PanelSurface {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("${state.session.size} added this session", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Worth " + Format.price(state.session.sumOf { it.card.priceOrFallback(it.finish, currency) ?: 0.0 }, currency),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (state.session.isNotEmpty()) TextButton(onClick = onClear) { Text("Clear") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Add as", style = MaterialTheme.typography.labelLarge)
            FilterChip(selected = state.bulkFinish == Finish.NONFOIL, onClick = { onFinish(Finish.NONFOIL) }, label = { Text("Non-foil") })
            FilterChip(selected = state.bulkFinish == Finish.FOIL, onClick = { onFinish(Finish.FOIL) }, label = { Text("Foil") })
        }
        if (state.session.isEmpty()) {
            Text(
                "Flip through your stack — each recognized card is added to your collection automatically.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(top = 8.dp)) {
                items(state.session, key = { it.at.toString() + it.card.id }) { item ->
                    Column(Modifier.width(64.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box {
                            CardImage(item.card.frontImageSmall ?: item.card.frontImage, item.card.name, Modifier.width(64.dp), cornerRadius = 4.dp)
                            Box(
                                Modifier.align(Alignment.TopEnd).padding(2.dp).size(22.dp).clip(RoundedCornerShape(11.dp))
                                    .background(Color.Black.copy(alpha = 0.6f)).clickable { onUndo(item) },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Undo, "Undo", tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                        Text(item.card.name, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun SessionSummary(state: ScanUiState, currency: Currency, onClear: () -> Unit) {
    PanelSurface {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${state.session.size} card${if (state.session.size == 1) "" else "s"} added · " +
                    Format.price(state.session.sumOf { it.card.priceOrFallback(it.finish, currency) ?: 0.0 }, currency),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
            )
            OutlinedButton(onClick = onClear) { Text("Clear") }
        }
    }
}
