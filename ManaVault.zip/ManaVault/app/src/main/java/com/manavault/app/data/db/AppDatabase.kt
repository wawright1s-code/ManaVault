package com.manavault.app.data.db

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

// ---- Entities -------------------------------------------------------------------------------

/** A cached Scryfall printing. [json] is a trimmed Scryfall card object (see ScryfallJson.encodeCard). */
@Entity(tableName = "cards", indices = [Index("oracleId"), Index("name")])
data class CardEntity(
    @PrimaryKey val id: String,
    val oracleId: String,
    val name: String,
    val json: String,
    val updatedAt: Long,
)

@Entity(
    tableName = "collection",
    indices = [Index(value = ["cardId", "finish", "condition", "language"], unique = true)],
)
data class CollectionEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cardId: String,
    val quantity: Int,
    val finish: String,
    val condition: String,
    val language: String = "en",
    val addedAt: Long,
    val updatedAt: Long,
)

@Entity(tableName = "decks")
data class DeckEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val format: String,
    val notes: String = "",
    val createdAt: Long,
    val updatedAt: Long,
)

@Entity(
    tableName = "deck_cards",
    primaryKeys = ["deckId", "cardId", "board"],
    foreignKeys = [
        ForeignKey(entity = DeckEntity::class, parentColumns = ["id"], childColumns = ["deckId"], onDelete = ForeignKey.CASCADE),
    ],
    indices = [Index("deckId"), Index("cardId")],
)
data class DeckCardEntity(
    val deckId: Long,
    val cardId: String,
    val board: String,
    val quantity: Int,
    val addedAt: Long,
)

/** One row per day: total collection value, used for the value-over-time sparkline. */
@Entity(tableName = "value_snapshots")
data class ValueSnapshotEntity(
    @PrimaryKey val day: Long,
    val usd: Double,
    val eur: Double,
    val tix: Double,
    val cards: Int,
)

// ---- Query rows -----------------------------------------------------------------------------

data class CollectionRow(
    @Embedded val entry: CollectionEntryEntity,
    val cardJson: String,
    val cardUpdatedAt: Long,
)

data class DeckCardRow(
    @Embedded val deckCard: DeckCardEntity,
    val cardJson: String,
    val cardUpdatedAt: Long,
)

// ---- DAOs -----------------------------------------------------------------------------------

@Dao
interface CardDao {
    @Upsert
    suspend fun upsert(card: CardEntity)

    @Upsert
    suspend fun upsertAll(cards: List<CardEntity>)

    @Query("SELECT * FROM cards WHERE id = :id")
    suspend fun get(id: String): CardEntity?

    @Query("SELECT * FROM cards WHERE id IN (:ids)")
    suspend fun getMany(ids: List<String>): List<CardEntity>

    @Query("SELECT DISTINCT cardId FROM collection UNION SELECT DISTINCT cardId FROM deck_cards")
    suspend fun referencedIds(): List<String>

    @Query("SELECT * FROM cards WHERE id IN (SELECT cardId FROM collection) OR id IN (SELECT cardId FROM deck_cards)")
    suspend fun referencedCards(): List<CardEntity>

    @Query("SELECT id FROM cards")
    suspend fun allIds(): List<String>

    @Query("SELECT MIN(updatedAt) FROM cards WHERE id IN (SELECT cardId FROM collection)")
    suspend fun oldestCollectionUpdate(): Long?

    @Query(
        "DELETE FROM cards WHERE updatedAt < :before " +
            "AND id NOT IN (SELECT cardId FROM collection) AND id NOT IN (SELECT cardId FROM deck_cards)"
    )
    suspend fun pruneUnreferenced(before: Long)
}

@Dao
interface CollectionDao {
    @Query(
        "SELECT collection.*, cards.json AS cardJson, cards.updatedAt AS cardUpdatedAt " +
            "FROM collection INNER JOIN cards ON cards.id = collection.cardId"
    )
    fun observeRows(): Flow<List<CollectionRow>>

    @Query(
        "SELECT collection.*, cards.json AS cardJson, cards.updatedAt AS cardUpdatedAt " +
            "FROM collection INNER JOIN cards ON cards.id = collection.cardId"
    )
    suspend fun rows(): List<CollectionRow>

    @Query("SELECT * FROM collection WHERE id = :id")
    suspend fun get(id: Long): CollectionEntryEntity?

    @Query(
        "SELECT * FROM collection WHERE cardId = :cardId AND finish = :finish " +
            "AND condition = :condition AND language = :language LIMIT 1"
    )
    suspend fun find(cardId: String, finish: String, condition: String, language: String): CollectionEntryEntity?

    @Insert
    suspend fun insert(entry: CollectionEntryEntity): Long

    @Update
    suspend fun update(entry: CollectionEntryEntity)

    @Query("UPDATE collection SET quantity = :quantity, updatedAt = :now WHERE id = :id")
    suspend fun setQuantity(id: Long, quantity: Int, now: Long)

    @Query("DELETE FROM collection WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM collection WHERE id IN (:ids)")
    suspend fun deleteMany(ids: List<Long>)

    @Query("SELECT DISTINCT cardId FROM collection")
    suspend fun cardIds(): List<String>

    @Query("SELECT * FROM collection")
    suspend fun allEntries(): List<CollectionEntryEntity>

    @Query("DELETE FROM collection")
    suspend fun clearAll()
}

@Dao
interface DeckDao {
    @Query("SELECT * FROM decks ORDER BY updatedAt DESC")
    fun observeDecks(): Flow<List<DeckEntity>>

    @Query("SELECT * FROM decks WHERE id = :id")
    fun observeDeck(id: Long): Flow<DeckEntity?>

    @Query("SELECT * FROM decks WHERE id = :id")
    suspend fun getDeck(id: Long): DeckEntity?

    @Insert
    suspend fun insertDeck(deck: DeckEntity): Long

    @Update
    suspend fun updateDeck(deck: DeckEntity)

    @Query("DELETE FROM decks WHERE id = :id")
    suspend fun deleteDeck(id: Long)

    @Query("UPDATE decks SET updatedAt = :now WHERE id = :id")
    suspend fun touch(id: Long, now: Long)

    @Query(
        "SELECT deck_cards.*, cards.json AS cardJson, cards.updatedAt AS cardUpdatedAt " +
            "FROM deck_cards INNER JOIN cards ON cards.id = deck_cards.cardId WHERE deck_cards.deckId = :deckId"
    )
    fun observeDeckRows(deckId: Long): Flow<List<DeckCardRow>>

    @Query(
        "SELECT deck_cards.*, cards.json AS cardJson, cards.updatedAt AS cardUpdatedAt " +
            "FROM deck_cards INNER JOIN cards ON cards.id = deck_cards.cardId"
    )
    fun observeAllDeckRows(): Flow<List<DeckCardRow>>

    @Query(
        "SELECT deck_cards.*, cards.json AS cardJson, cards.updatedAt AS cardUpdatedAt " +
            "FROM deck_cards INNER JOIN cards ON cards.id = deck_cards.cardId WHERE deck_cards.deckId = :deckId"
    )
    suspend fun deckRows(deckId: Long): List<DeckCardRow>

    @Query("SELECT * FROM deck_cards WHERE deckId = :deckId AND cardId = :cardId AND board = :board")
    suspend fun getDeckCard(deckId: Long, cardId: String, board: String): DeckCardEntity?

    @Upsert
    suspend fun upsertDeckCard(card: DeckCardEntity)

    @Query("DELETE FROM deck_cards WHERE deckId = :deckId AND cardId = :cardId AND board = :board")
    suspend fun deleteDeckCard(deckId: Long, cardId: String, board: String)

    @Query("DELETE FROM deck_cards WHERE deckId = :deckId")
    suspend fun clearDeck(deckId: Long)

    @Query("SELECT * FROM decks")
    suspend fun allDecks(): List<DeckEntity>

    @Query("SELECT * FROM deck_cards")
    suspend fun allDeckCards(): List<DeckCardEntity>

    @Query("DELETE FROM deck_cards")
    suspend fun clearAllDeckCards()

    @Query("DELETE FROM decks")
    suspend fun deleteAllDecks()
}

@Dao
interface SnapshotDao {
    @Upsert
    suspend fun upsert(snapshot: ValueSnapshotEntity)

    @Query("SELECT * FROM value_snapshots ORDER BY day DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<ValueSnapshotEntity>>
}

// ---- Database -------------------------------------------------------------------------------

@Database(
    entities = [CardEntity::class, CollectionEntryEntity::class, DeckEntity::class, DeckCardEntity::class, ValueSnapshotEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun cards(): CardDao
    abstract fun collection(): CollectionDao
    abstract fun decks(): DeckDao
    abstract fun snapshots(): SnapshotDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "manavault.db").build()
    }
}
