package com.manavault.app.data.repo

import androidx.room.withTransaction
import com.manavault.app.core.backup.BackupCodec
import com.manavault.app.core.backup.BackupData
import com.manavault.app.core.backup.BackupDeck
import com.manavault.app.core.backup.BackupDeckCard
import com.manavault.app.core.backup.BackupEntry
import com.manavault.app.core.backup.BackupSettings
import com.manavault.app.core.model.Condition
import com.manavault.app.core.model.Currency
import com.manavault.app.data.db.AppDatabase
import com.manavault.app.data.db.CollectionEntryEntity
import com.manavault.app.data.db.DeckCardEntity
import com.manavault.app.data.db.DeckEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class RestoreReport(val collectionCards: Int, val decks: Int, val replaced: Boolean)

/** Whole-app backup: collection, decks, the card data they need, and preferences (never the API key). */
class BackupRepository(
    private val db: AppDatabase,
    private val cards: CardRepository,
    private val settings: SettingsRepository,
) {
    suspend fun export(): String {
        val cardList = db.cards().referencedCards().map { cards.decode(it.id, it.json, it.updatedAt) }
        val entries = db.collection().allEntries().map {
            BackupEntry(it.cardId, it.quantity, it.finish, it.condition, it.language, it.addedAt)
        }
        val deckCards = db.decks().allDeckCards().groupBy { it.deckId }
        val decks = db.decks().allDecks().map { d ->
            BackupDeck(
                name = d.name, format = d.format, notes = d.notes, createdAt = d.createdAt, updatedAt = d.updatedAt,
                cards = deckCards[d.id].orEmpty().map { BackupDeckCard(it.cardId, it.board, it.quantity) },
            )
        }
        val s = settings.settings.value
        val data = BackupData(
            exportedAt = System.currentTimeMillis(),
            cards = cardList,
            collection = entries,
            decks = decks,
            settings = BackupSettings(s.currency.key, s.defaultCondition.code, s.model),
        )
        return withContext(Dispatchers.Default) { BackupCodec.encode(data) }
    }

    /**
     * Restores a backup. With [replace] the current collection and decks are deleted first and the
     * backup's preferences are applied; otherwise quantities are added to what's there and decks are added alongside.
     */
    suspend fun restore(text: String, replace: Boolean): RestoreReport {
        val data = withContext(Dispatchers.Default) { BackupCodec.decode(text) }
        val now = System.currentTimeMillis()
        db.withTransaction {
            if (replace) {
                db.decks().clearAllDeckCards()
                db.decks().deleteAllDecks()
                db.collection().clearAll()
            }
            // Don't overwrite fresher local copies (newer prices) of cards we already have.
            val existing = db.cards().allIds().toSet()
            cards.cacheAll(data.cards.filter { it.id !in existing })

            val dao = db.collection()
            for (e in data.collection) {
                val match = dao.find(e.cardId, e.finish, e.condition, e.language)
                if (match != null) {
                    dao.setQuantity(match.id, match.quantity + e.quantity, now)
                } else {
                    dao.insert(
                        CollectionEntryEntity(
                            cardId = e.cardId, quantity = e.quantity, finish = e.finish, condition = e.condition,
                            language = e.language, addedAt = e.addedAt.takeIf { it > 0 } ?: now, updatedAt = now,
                        )
                    )
                }
            }
            for (d in data.decks) {
                val id = db.decks().insertDeck(
                    DeckEntity(
                        name = d.name, format = d.format, notes = d.notes,
                        createdAt = d.createdAt.takeIf { it > 0 } ?: now,
                        updatedAt = d.updatedAt.takeIf { it > 0 } ?: now,
                    )
                )
                d.cards.groupBy { it.cardId to it.board }.forEach { (key, list) ->
                    db.decks().upsertDeckCard(DeckCardEntity(id, key.first, key.second, list.sumOf { it.quantity }, now))
                }
            }
        }
        if (replace) {
            data.settings.currency?.let { settings.setCurrency(Currency.fromKey(it)) }
            data.settings.defaultCondition?.let { settings.setDefaultCondition(Condition.fromCode(it)) }
            data.settings.model?.let { settings.setModel(it) }
        }
        return RestoreReport(data.collectionCount, data.decks.size, replace)
    }
}
