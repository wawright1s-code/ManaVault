package com.manavault.app.core.model

/** One face of a multi-faced card (transform, modal double-faced, split, adventure, flip). */
data class CardFace(
    val name: String,
    val manaCost: String = "",
    val typeLine: String = "",
    val oracleText: String = "",
    val power: String? = null,
    val toughness: String? = null,
    val loyalty: String? = null,
    val defense: String? = null,
    val imageSmall: String? = null,
    val imageNormal: String? = null,
    val imageLarge: String? = null,
    val imageArtCrop: String? = null,
)

data class Prices(
    val usd: Double? = null,
    val usdFoil: Double? = null,
    val usdEtched: Double? = null,
    val eur: Double? = null,
    val eurFoil: Double? = null,
    val eurEtched: Double? = null,
    val tix: Double? = null,
)

data class Ruling(val source: String, val publishedAt: String, val comment: String)

enum class Finish(val key: String, val label: String) {
    NONFOIL("nonfoil", "Non-foil"),
    FOIL("foil", "Foil"),
    ETCHED("etched", "Etched");

    companion object {
        fun fromKey(key: String?): Finish = entries.firstOrNull { it.key.equals(key?.trim(), true) } ?: when {
            key == null -> NONFOIL
            key.trim().lowercase() in setOf("true", "yes", "y", "1", "f", "*f*") -> FOIL
            key.trim().lowercase().contains("etch") -> ETCHED
            key.trim().lowercase().contains("foil") && !key.trim().lowercase().contains("non") -> FOIL
            else -> NONFOIL
        }
    }
}

enum class Currency(val key: String, val label: String) {
    USD("usd", "US Dollar"),
    EUR("eur", "Euro"),
    TIX("tix", "MTGO Tix");

    companion object {
        fun fromKey(key: String?): Currency = entries.firstOrNull { it.key == key } ?: USD
    }
}

enum class Condition(val code: String, val label: String) {
    NM("NM", "Near Mint"),
    LP("LP", "Lightly Played"),
    MP("MP", "Moderately Played"),
    HP("HP", "Heavily Played"),
    DMG("DMG", "Damaged");

    companion object {
        fun fromCode(code: String?): Condition {
            val c = code?.trim()?.uppercase() ?: return NM
            return entries.firstOrNull { it.code == c || it.label.uppercase() == c } ?: when (c) {
                "M", "MINT", "NEAR MINT", "NM-M" -> NM
                "EX", "EXCELLENT", "SP", "SLIGHTLY PLAYED", "GD", "GOOD" -> LP
                "PL", "PLAYED" -> MP
                "PO", "POOR" -> DMG
                else -> NM
            }
        }
    }
}

/** A single Scryfall printing. Only the fields the app uses are kept. */
data class Card(
    val id: String,
    val oracleId: String,
    val name: String,
    val lang: String = "en",
    val layout: String = "normal",
    val manaCost: String = "",
    val cmc: Double = 0.0,
    val typeLine: String = "",
    val oracleText: String = "",
    val power: String? = null,
    val toughness: String? = null,
    val loyalty: String? = null,
    val defense: String? = null,
    val colors: List<String> = emptyList(),
    val colorIdentity: List<String> = emptyList(),
    val keywords: List<String> = emptyList(),
    val producedMana: List<String> = emptyList(),
    val legalities: Map<String, String> = emptyMap(),
    val setCode: String = "",
    val setName: String = "",
    val collectorNumber: String = "",
    val rarity: String = "",
    val releasedAt: String = "",
    val artist: String? = null,
    val imageSmall: String? = null,
    val imageNormal: String? = null,
    val imageLarge: String? = null,
    val imageArtCrop: String? = null,
    val faces: List<CardFace> = emptyList(),
    val prices: Prices = Prices(),
    val finishes: List<String> = listOf("nonfoil"),
    val scryfallUri: String? = null,
    val tcgplayerUri: String? = null,
    val cardmarketUri: String? = null,
    val edhrecRank: Int? = null,
    val gameChanger: Boolean = false,
) {
    /** True when each face has its own image (transform / MDFC / meld backs). */
    val hasBackImage: Boolean get() = faces.size >= 2 && faces[1].imageNormal != null

    val frontImage: String? get() = imageNormal ?: faces.firstOrNull()?.imageNormal
    val frontImageSmall: String? get() = imageSmall ?: faces.firstOrNull()?.imageSmall
    val artCrop: String? get() = imageArtCrop ?: faces.firstOrNull()?.imageArtCrop

    val frontName: String get() = faces.firstOrNull()?.name ?: name.substringBefore(" // ")

    /** Mana cost shown for the card as a whole (front face for DFCs). */
    val displayManaCost: String
        get() = manaCost.ifBlank { faces.firstOrNull()?.manaCost.orEmpty() }

    val displayTypeLine: String get() = typeLine.ifBlank { faces.joinToString(" // ") { it.typeLine } }

    val isLand: Boolean get() = frontTypeLine.contains("Land") && !frontTypeLine.contains("Creature")
    val isBasicLand: Boolean get() = typeLine.contains("Basic") && typeLine.contains("Land")
    val isCreature: Boolean get() = frontTypeLine.contains("Creature")
    val isLegendary: Boolean get() = frontTypeLine.contains("Legendary")

    private val frontTypeLine: String get() = faces.firstOrNull()?.typeLine?.ifBlank { null } ?: typeLine.substringBefore(" // ")

    /** Rules text for every face, joined. */
    val allOracleText: String
        get() = if (faces.isNotEmpty() && oracleText.isBlank()) {
            faces.joinToString("\n") { it.oracleText }
        } else oracleText

    val defaultFinish: Finish
        get() = when {
            "nonfoil" in finishes -> Finish.NONFOIL
            "foil" in finishes -> Finish.FOIL
            "etched" in finishes -> Finish.ETCHED
            else -> Finish.NONFOIL
        }

    val availableFinishes: List<Finish>
        get() = Finish.entries.filter { it.key in finishes }.ifEmpty { listOf(Finish.NONFOIL) }

    fun price(finish: Finish, currency: Currency): Double? = when (currency) {
        Currency.USD -> when (finish) {
            Finish.NONFOIL -> prices.usd
            Finish.FOIL -> prices.usdFoil
            Finish.ETCHED -> prices.usdEtched ?: prices.usdFoil
        }
        Currency.EUR -> when (finish) {
            Finish.NONFOIL -> prices.eur
            Finish.FOIL -> prices.eurFoil
            Finish.ETCHED -> prices.eurEtched ?: prices.eurFoil
        }
        Currency.TIX -> prices.tix
    }

    /**
     * Price for the finish. If that finish doesn't exist for this printing (e.g. an entry imported as foil
     * for a non-foil-only card), falls back to the printing's default finish.
     */
    fun priceOrFallback(finish: Finish, currency: Currency): Double? =
        price(finish, currency) ?: if (finish !in availableFinishes) price(defaultFinish, currency) else null

    fun legalityIn(format: String): String = legalities[format] ?: "not_legal"
}
