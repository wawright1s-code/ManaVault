package com.manavault.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import coil.compose.AsyncImage
import com.manavault.app.core.mana.ManaSymbols
import com.manavault.app.core.mana.TextSegment
import com.manavault.app.core.text.MdSpan

/** Scryfall "normal" images are 488 x 680. */
const val CARD_ASPECT = 488f / 680f

/** A card image with the rounded corners of a real card and a quiet placeholder while loading. */
@Composable
fun CardImage(
    url: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 10.dp,
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier
            .aspectRatio(CARD_ASPECT)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
    ) {
        if (url != null) {
            AsyncImage(
                model = url,
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

@Composable
fun SymbolIcon(symbol: String, size: Dp = 16.dp, modifier: Modifier = Modifier) {
    AsyncImage(
        model = ManaSymbols.svgUrl(symbol),
        contentDescription = "{$symbol}",
        modifier = modifier.size(size),
    )
}

/** A mana cost like "{2}{W}{U}" drawn with the official symbols. */
@Composable
fun ManaCost(cost: String, modifier: Modifier = Modifier, size: Dp = 16.dp) {
    val symbols = remember(cost) { cost.split(" // ").map { ManaSymbols.parse(it) } }
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
        symbols.forEachIndexed { i, face ->
            if (i > 0) Text(" // ", style = MaterialTheme.typography.labelSmall)
            face.forEach { SymbolIcon(it, size) }
        }
    }
}

/** Builds rich text with inline mana symbols and optional Markdown span styles. */
private fun buildSymbolString(spans: List<MdSpan>, codeBackground: Color): Pair<AnnotatedString, Set<String>> {
    val used = mutableSetOf<String>()
    val text = buildAnnotatedString {
        for (span in spans) {
            val style = SpanStyle(
                fontWeight = if (span.bold) FontWeight.SemiBold else null,
                fontStyle = if (span.italic) FontStyle.Italic else null,
                fontFamily = if (span.code) FontFamily.Monospace else null,
                background = if (span.code) codeBackground else Color.Unspecified,
            )
            withStyle(style) {
                for (seg in ManaSymbols.segments(span.text)) {
                    when (seg) {
                        is TextSegment.Plain -> append(seg.text)
                        is TextSegment.Symbol -> {
                            used += seg.symbol
                            appendInlineContent("sym:" + seg.symbol, "{" + seg.symbol + "}")
                        }
                    }
                }
            }
        }
    }
    return text to used
}

private fun inlineSymbols(symbols: Set<String>): Map<String, InlineTextContent> = symbols.associate { sym ->
    ("sym:$sym") to InlineTextContent(Placeholder(1.05.em, 1.05.em, PlaceholderVerticalAlign.TextCenter)) {
        AsyncImage(model = ManaSymbols.svgUrl(sym), contentDescription = "{$sym}", modifier = Modifier.fillMaxSize())
    }
}

/** Rules text with {T}, {W} and friends rendered as symbols. */
@Composable
fun SymbolText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = Color.Unspecified,
    maxLines: Int = Int.MAX_VALUE,
) {
    SpannedSymbolText(listOf(MdSpan(text)), modifier, style, color, maxLines)
}

@Composable
fun SpannedSymbolText(
    spans: List<MdSpan>,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = Color.Unspecified,
    maxLines: Int = Int.MAX_VALUE,
) {
    val codeBg = MaterialTheme.colorScheme.surfaceVariant
    val (annotated, used) = remember(spans, codeBg) { buildSymbolString(spans, codeBg) }
    val inline = remember(used) { inlineSymbols(used) }
    Text(
        text = annotated,
        modifier = modifier,
        style = style,
        color = color,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        inlineContent = inline,
    )
}

/** Small colored dots / symbols for a color identity. */
@Composable
fun ColorIdentity(colors: List<String>, modifier: Modifier = Modifier, size: Dp = 14.dp) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        if (colors.isEmpty()) SymbolIcon("C", size) else colors.forEach { SymbolIcon(it, size) }
    }
}

/** A compact rounded label, e.g. "Foil", "NM", "Banned". */
@Composable
fun Tag(text: String, container: Color, content: Color, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelSmall,
        color = content,
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(container)
            .padding(horizontal = 6.dp, vertical = 2.dp),
    )
}

@Composable
fun FinishTag(finishKey: String, modifier: Modifier = Modifier) {
    when (finishKey) {
        "foil" -> Tag("Foil", MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer, modifier)
        "etched" -> Tag("Etched", MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer, modifier)
        else -> Unit
    }
}

@Composable
fun Dot(color: Color, size: Dp = 8.dp, modifier: Modifier = Modifier) {
    Box(modifier.size(size).clip(CircleShape).background(color))
}
