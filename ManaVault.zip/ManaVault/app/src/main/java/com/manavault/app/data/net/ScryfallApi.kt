package com.manavault.app.data.net

import com.manavault.app.BuildConfig
import com.manavault.app.core.model.Card
import com.manavault.app.core.model.Ruling
import com.manavault.app.core.scryfall.CardPage
import com.manavault.app.core.scryfall.CollectionResult
import com.manavault.app.core.scryfall.ScryfallJson
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class ScryfallException(val status: Int, val code: String, message: String) : IOException(message)

/**
 * Thin client for https://api.scryfall.com. Scryfall asks clients to send a descriptive User-Agent and
 * an Accept header and to keep to ~10 requests per second, so every call goes through [throttle].
 */
class ScryfallApi(private val http: OkHttpClient) {

    private val base: HttpUrl = "https://api.scryfall.com".toHttpUrl()
    private val userAgent = "ManaVault/${BuildConfig.VERSION_NAME} (Android; personal MTG collection app)"
    private val throttleLock = Mutex()
    private var lastRequestAt = 0L

    private suspend fun throttle() = throttleLock.withLock {
        val wait = lastRequestAt + MIN_INTERVAL_MS - System.currentTimeMillis()
        if (wait > 0) delay(wait)
        lastRequestAt = System.currentTimeMillis()
    }

    private fun url(vararg segments: String, query: Map<String, String?> = emptyMap()): HttpUrl {
        val b = base.newBuilder()
        segments.forEach { b.addPathSegment(it) }
        query.forEach { (k, v) -> if (v != null) b.addQueryParameter(k, v) }
        return b.build()
    }

    private suspend fun send(request: Request): JsonObject {
        throttle()
        val result = http.fetch(
            request.newBuilder()
                .header("User-Agent", userAgent)
                .header("Accept", "application/json;q=0.9,*/*;q=0.8")
                .build()
        )
        if (!result.isSuccess) {
            val err = ScryfallJson.parseError(result.body, result.code)
            throw ScryfallException(err.status, err.code, err.details)
        }
        return ScryfallJson.parseObject(result.body)
    }

    private suspend fun get(url: HttpUrl): JsonObject = send(Request.Builder().url(url).get().build())

    private suspend fun post(url: HttpUrl, json: String): JsonObject =
        send(Request.Builder().url(url).post(json.toRequestBody(JSON)).build())

    /** Returns null instead of throwing when Scryfall says "not found". */
    private suspend fun <T> orNullIfMissing(block: suspend () -> T): T? = try {
        block()
    } catch (e: ScryfallException) {
        if (e.status == 404) null else throw e
    }

    suspend fun cardById(id: String): Card = ScryfallJson.parseCard(get(url("cards", id)))

    suspend fun named(fuzzy: String? = null, exact: String? = null, set: String? = null): Card? = orNullIfMissing {
        ScryfallJson.parseCard(get(url("cards", "named", query = mapOf("fuzzy" to fuzzy, "exact" to exact, "set" to set))))
    }

    suspend fun byCollectorNumber(set: String, number: String): Card? = orNullIfMissing {
        ScryfallJson.parseCard(get(url("cards", set.lowercase(), number)))
    }

    suspend fun search(query: String, unique: String = "cards", order: String = "name", dir: String = "auto"): CardPage =
        orNullIfMissing {
            ScryfallJson.parseList(get(url("cards", "search", query = mapOf("q" to query, "unique" to unique, "order" to order, "dir" to dir))))
        } ?: CardPage(emptyList(), 0, false, null)

    suspend fun page(nextPageUrl: String): CardPage = ScryfallJson.parseList(get(nextPageUrl.toHttpUrl()))

    suspend fun autocomplete(text: String): List<String> =
        if (text.length < 2) emptyList()
        else ScryfallJson.parseCatalog(get(url("cards", "autocomplete", query = mapOf("q" to text))))

    suspend fun rulings(cardId: String): List<Ruling> = ScryfallJson.parseRulings(get(url("cards", cardId, "rulings")))

    /** All English printings of a card, newest first (first few pages at most). */
    suspend fun printings(oracleId: String): List<Card> {
        val first = search("oracleid:$oracleId", unique = "prints", order = "released", dir = "desc")
        val all = first.cards.toMutableList()
        var next = first.nextPage
        var pages = 1
        while (next != null && pages < 4) {
            val p = page(next)
            all += p.cards
            next = if (p.hasMore) p.nextPage else null
            pages++
        }
        return all
    }

    suspend fun random(query: String? = null): Card =
        ScryfallJson.parseCard(get(url("cards", "random", query = mapOf("q" to query?.ifBlank { null }))))

    /** POST /cards/collection, automatically split into batches of 75 identifiers. */
    suspend fun collection(identifiers: List<JsonObject>): CollectionResult {
        val found = mutableListOf<Card>()
        val missing = mutableListOf<JsonObject>()
        for (batch in identifiers.chunked(75)) {
            val body = buildJsonObject { put("identifiers", buildJsonArray { batch.forEach { add(it) } }) }.toString()
            val r = ScryfallJson.parseCollection(post(url("cards", "collection"), body))
            found += r.found
            missing += r.notFound
        }
        return CollectionResult(found, missing)
    }

    companion object {
        private const val MIN_INTERVAL_MS = 100L
        private val JSON = "application/json".toMediaType()

        fun idIdentifier(id: String) = buildJsonObject { put("id", id) }
        fun nameIdentifier(name: String, set: String? = null) = buildJsonObject {
            put("name", name)
            if (set != null) put("set", set)
        }
        fun printIdentifier(set: String, number: String) = buildJsonObject {
            put("set", set)
            put("collector_number", number)
        }
    }
}
