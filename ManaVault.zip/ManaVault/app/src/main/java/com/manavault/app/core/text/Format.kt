package com.manavault.app.core.text

import com.manavault.app.core.model.Currency
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

object Format {
    private val money = ThreadLocal.withInitial { DecimalFormat("#,##0.00", DecimalFormatSymbols(Locale.US)) }
    private val compact = ThreadLocal.withInitial { DecimalFormat("#,##0", DecimalFormatSymbols(Locale.US)) }

    fun price(value: Double?, currency: Currency): String {
        if (value == null) return "—"
        val n = money.get()!!.format(value)
        return when (currency) {
            Currency.USD -> "$$n"
            Currency.EUR -> "€$n"
            Currency.TIX -> "$n tix"
        }
    }

    /** Large totals without cents once they're big enough that cents are noise. */
    fun total(value: Double, currency: Currency): String =
        if (value >= 10_000) {
            val n = compact.get()!!.format(value)
            when (currency) {
                Currency.USD -> "$$n"
                Currency.EUR -> "€$n"
                Currency.TIX -> "$n tix"
            }
        } else price(value, currency)

    fun count(n: Int): String = compact.get()!!.format(n)

    fun relativeAge(epochMillis: Long, now: Long = System.currentTimeMillis()): String {
        if (epochMillis <= 0) return "never"
        val minutes = (now - epochMillis) / 60_000
        return when {
            minutes < 1 -> "just now"
            minutes < 60 -> "${minutes}m ago"
            minutes < 60 * 24 -> "${minutes / 60}h ago"
            else -> "${minutes / (60 * 24)}d ago"
        }
    }

    fun rarity(r: String): String = r.replaceFirstChar { it.uppercase() }

    fun legality(status: String): String = when (status) {
        "legal" -> "Legal"
        "not_legal" -> "Not legal"
        "banned" -> "Banned"
        "restricted" -> "Restricted"
        else -> status.replace('_', ' ').replaceFirstChar { it.uppercase() }
    }
}

/** Small thread-safe LRU cache. */
class LruMap<K, V>(private val capacity: Int) {
    private val map = object : LinkedHashMap<K, V>(capacity, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<K, V>?): Boolean = size > capacity
    }

    @Synchronized operator fun get(key: K): V? = map[key]
    @Synchronized operator fun set(key: K, value: V) { map[key] = value }
    @Synchronized fun remove(key: K) { map.remove(key) }
    @Synchronized fun clear() = map.clear()
    @Synchronized fun getOrPut(key: K, compute: () -> V): V = map[key] ?: compute().also { map[key] = it }
}
