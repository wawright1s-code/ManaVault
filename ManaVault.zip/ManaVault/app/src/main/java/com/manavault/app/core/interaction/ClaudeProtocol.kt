package com.manavault.app.core.interaction

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put

data class ChatTurn(val role: String, val text: String) {
    companion object {
        fun user(text: String) = ChatTurn("user", text)
        fun assistant(text: String) = ChatTurn("assistant", text)
    }
}

data class ClaudeReply(
    val text: String,
    val stopReason: String?,
    val inputTokens: Int,
    val outputTokens: Int,
)

data class ModelOption(
    val id: String,
    val label: String,
    val description: String,
    val inputPerMillion: Double,
    val outputPerMillion: Double,
)

/** Request/response handling for Anthropic's Messages API (https://api.anthropic.com/v1/messages). */
object ClaudeProtocol {
    const val ENDPOINT = "https://api.anthropic.com/v1/messages"
    const val API_VERSION = "2023-06-01"
    const val DEFAULT_MODEL = "claude-sonnet-5-5"

    val MODELS = listOf(
        ModelOption("claude-sonnet-5-5", "Claude Sonnet 5.5", "Balanced speed and depth — recommended", 2.0, 10.0),
        ModelOption("claude-opus-5-5", "Claude Opus 5.5", "Most thorough on tricky rules questions", 4.0, 20.0),
        ModelOption("claude-haiku-4-5-20251001", "Claude Haiku 4.5", "Fastest and cheapest", 1.0, 5.0),
    )

    private val json = Json { ignoreUnknownKeys = true }

    fun requestBody(model: String, system: String, turns: List<ChatTurn>, maxTokens: Int = 4096): String = buildJsonObject {
        put("model", model)
        put("max_tokens", maxTokens)
        put("system", system)
        put("messages", buildJsonArray {
            for (t in turns) {
                add(buildJsonObject {
                    put("role", t.role)
                    put("content", t.text)
                })
            }
        })
    }.toString()

    /** Concatenates the text blocks of a Messages API response (ignoring thinking or other block types). */
    fun parseReply(body: String): ClaudeReply {
        val o = json.parseToJsonElement(body).jsonObject
        val text = (o["content"] as? JsonArray).orEmpty()
            .mapNotNull { it as? JsonObject }
            .filter { (it["type"] as? JsonPrimitive)?.contentOrNull == "text" }
            .mapNotNull { (it["text"] as? JsonPrimitive)?.contentOrNull }
            .joinToString("")
        val usage = o["usage"] as? JsonObject
        return ClaudeReply(
            text = text.trim(),
            stopReason = (o["stop_reason"] as? JsonPrimitive)?.contentOrNull,
            inputTokens = (usage?.get("input_tokens") as? JsonPrimitive)?.intOrNull ?: 0,
            outputTokens = (usage?.get("output_tokens") as? JsonPrimitive)?.intOrNull ?: 0,
        )
    }

    /** A message suitable for showing to the player when the API returns an error. */
    fun friendlyError(httpCode: Int, body: String?): String {
        val (type, message) = try {
            val err = json.parseToJsonElement(body.orEmpty()).jsonObject["error"] as? JsonObject
            ((err?.get("type") as? JsonPrimitive)?.contentOrNull to (err?.get("message") as? JsonPrimitive)?.contentOrNull)
        } catch (e: Exception) {
            null to null
        }
        return when {
            httpCode == 401 || type == "authentication_error" ->
                "Your Anthropic API key was rejected. Check it in Settings."
            httpCode == 403 || type == "permission_error" ->
                "This API key doesn't have permission to use that model."
            httpCode == 404 || type == "not_found_error" ->
                "That model wasn't found. Pick a different model in Settings."
            httpCode == 429 || type == "rate_limit_error" ->
                "Rate limit reached. Wait a moment and try again."
            httpCode == 529 || type == "overloaded_error" ->
                "Claude is busy right now. Try again in a minute."
            !message.isNullOrBlank() -> message
            else -> "The Claude API returned an error (HTTP $httpCode)."
        }
    }

    fun estimateCostUsd(modelId: String, inputTokens: Int, outputTokens: Int): Double? {
        val m = MODELS.firstOrNull { it.id == modelId } ?: return null
        return inputTokens / 1_000_000.0 * m.inputPerMillion + outputTokens / 1_000_000.0 * m.outputPerMillion
    }
}
