package com.manavault.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.manavault.app.core.deck.Board
import com.manavault.app.core.deck.Formats
import com.manavault.app.core.model.Card
import com.manavault.app.core.model.Condition
import com.manavault.app.core.model.Finish
import com.manavault.app.core.text.Format
import com.manavault.app.data.net.ClaudeException
import com.manavault.app.data.net.ScryfallException
import com.manavault.app.graph
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import java.io.IOException
import java.net.UnknownHostException

/** Turns exceptions into short messages for the player. */
fun Throwable.userMessage(): String = when (this) {
    is ScryfallException -> message ?: "Scryfall returned an error."
    is ClaudeException -> message ?: "The Claude API returned an error."
    is UnknownHostException -> "No internet connection."
    is java.net.SocketTimeoutException -> "The request timed out. Try again."
    is IOException -> "Network problem: ${message ?: "couldn't connect"}"
    else -> message ?: "Something went wrong."
}

/**
 * Full-screen card search used by the Interaction Lab, deck editor and scanner.
 * With [keepOpen] the dialog stays up so several cards can be added in a row.
 */
@Composable
fun CardSearchDialog(
    title: String,
    onDismiss: () -> Unit,
    onPick: (Card) -> Unit,
    keepOpen: Boolean = false,
    initialQuery: String = "",
) {
    val graph = LocalContext.current.graph
    val currency = graph.settings.settings.collectAsStateWithLifecycle().value.currency
    var query by rememberSaveable { mutableStateOf(initialQuery) }
    var results by remember { mutableStateOf<List<Card>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var picked by remember { mutableStateOf(setOf<String>()) }
    val focus = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        runCatching { focus.requestFocus() }
        snapshotFlow { query.trim() }
            .debounce(350)
            .distinctUntilChanged()
            .collectLatest { q ->
                if (q.length < 2) {
                    results = emptyList()
                    message = null
                    return@collectLatest
                }
                loading = true
                try {
                    results = graph.cards.search(q).cards.take(75)
                    message = if (results.isEmpty()) "No cards match “$q”." else null
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    message = e.userMessage()
                } finally {
                    loading = false
                }
            }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxSize().imePadding()) {
                Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 16.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Close") }
                    Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    if (keepOpen && picked.isNotEmpty()) TextButton(onClick = onDismiss) { Text("Done (${picked.size})") }
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Card name or Scryfall search, e.g. t:dragon c:r") },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Clear") } },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { }),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).focusRequester(focus),
                )
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp))
                message?.let {
                    Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp))
                }
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
                    items(results, key = { it.id }) { card ->
                        val isPicked = card.id in picked
                        CardRow(
                            card = card,
                            subtitle = "${card.displayTypeLine} · ${Format.price(card.price(card.defaultFinish, currency), currency)}",
                            selected = isPicked,
                            onClick = {
                                onPick(card)
                                if (keepOpen) picked = picked + card.id else onDismiss()
                            },
                            trailing = { if (isPicked) Icon(Icons.Filled.Check, "Added", tint = MaterialTheme.colorScheme.tertiary) },
                        )
                    }
                }
            }
        }
    }
}

/** Add-to-collection options: finish, condition, quantity. */
@Composable
fun AddToCollectionDialog(card: Card, onDismiss: () -> Unit, onDone: (String) -> Unit) {
    val graph = LocalContext.current.graph
    val scope = rememberCoroutineScope()
    val settings = graph.settings.settings.collectAsStateWithLifecycle().value
    var finish by remember { mutableStateOf(card.defaultFinish) }
    var condition by remember { mutableStateOf(settings.defaultCondition) }
    var quantity by remember { mutableStateOf(1) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to collection") },
        text = {
            Column {
                Text("${card.name} · ${card.setCode.uppercase()} #${card.collectorNumber}", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                Text("Finish", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    card.availableFinishes.forEach { f ->
                        FilterChip(
                            selected = finish == f,
                            onClick = { finish = f },
                            label = { Text("${f.label} ${Format.price(card.price(f, settings.currency), settings.currency)}") },
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Condition", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Condition.entries.forEach { c ->
                        FilterChip(selected = condition == c, onClick = { condition = c }, label = { Text(c.code) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Quantity", style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                    QuantityStepper(quantity, { quantity = it }, min = 1)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    graph.collection.add(card, quantity, finish, condition)
                    onDone("Added $quantity× ${card.name} to your collection")
                }
                onDismiss()
            }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** Pick a deck (or create one) and a board, then add the card(s). */
@Composable
fun AddToDeckDialog(cards: List<Card>, onDismiss: () -> Unit, onDone: (String) -> Unit, quantity: Int = 1) {
    if (cards.isEmpty()) return
    val what = if (cards.size == 1) cards.first().name else "${cards.size} cards"
    val graph = LocalContext.current.graph
    val scope = rememberCoroutineScope()
    val decksFlow = remember { graph.decks.observeDecks() }
    val decks by decksFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    var selectedDeck by remember { mutableStateOf<Long?>(null) }
    var newName by remember { mutableStateOf("") }
    var board by remember { mutableStateOf(Board.MAIN) }
    var qty by remember { mutableStateOf(quantity) }
    val creating = selectedDeck == null

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add $what to a deck") },
        text = {
            Column {
                LazyColumn(Modifier.heightIn(max = 260.dp)) {
                    items(decks, key = { it.deck.id }) { d ->
                        Row(
                            Modifier.fillMaxWidth().clickable { selectedDeck = d.deck.id }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = selectedDeck == d.deck.id, onClick = { selectedDeck = d.deck.id })
                            Column(Modifier.weight(1f)) {
                                Text(d.deck.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${d.format.name} · ${d.playingCount} cards", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    item {
                        Row(
                            Modifier.fillMaxWidth().clickable { selectedDeck = null }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = creating, onClick = { selectedDeck = null })
                            Text("New deck")
                        }
                    }
                }
                if (creating) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Deck name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(Board.MAIN, Board.SIDE, Board.MAYBE, Board.COMMANDER).forEach { b ->
                        FilterChip(selected = board == b, onClick = { board = b }, label = { Text(b.label) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Copies", style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                    QuantityStepper(qty, { qty = it }, min = 1)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !creating || newName.isNotBlank(),
                onClick = {
                    scope.launch {
                        val deckId = selectedDeck ?: graph.decks.create(
                            newName,
                            if (board == Board.COMMANDER) Formats.COMMANDER.id else Formats.CASUAL.id,
                        )
                        cards.forEach { graph.decks.addCard(deckId, it, board, qty) }
                        val name = decks.firstOrNull { it.deck.id == deckId }?.deck?.name ?: newName
                        onDone("Added $what to $name")
                    }
                    onDismiss()
                },
            ) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** Lets the player pick the exact printing (set, collector number) they own. */
@Composable
fun PrintingPickerDialog(card: Card, onDismiss: () -> Unit, onPick: (Card) -> Unit) {
    val graph = LocalContext.current.graph
    val currency = graph.settings.settings.collectAsStateWithLifecycle().value.currency
    var printings by remember { mutableStateOf<List<Card>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(card.oracleId) {
        try {
            printings = graph.cards.printings(card)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = e.userMessage()
        }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 16.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Close") }
                    Column(Modifier.weight(1f)) {
                        Text("Choose printing", style = MaterialTheme.typography.titleLarge)
                        Text(card.name, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                val list = printings
                when {
                    error != null -> Text(error!!, modifier = Modifier.padding(16.dp))
                    list == null -> LoadingBox(label = "Loading printings…")
                    else -> LazyVerticalGrid(
                        columns = GridCells.Adaptive(110.dp),
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        items(list, key = { it.id }) { p ->
                            Column(
                                Modifier.clickable { onPick(p); onDismiss() },
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                CardImage(p.frontImageSmall ?: p.frontImage, p.name, Modifier.fillMaxWidth(), cornerRadius = 6.dp)
                                Spacer(Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (p.id == card.id) {
                                        Icon(Icons.Filled.Check, "Current", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                                        Spacer(Modifier.width(2.dp))
                                    }
                                    Text("${p.setCode.uppercase()} #${p.collectorNumber}", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                                }
                                Text(p.setName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    Format.price(p.price(p.defaultFinish, currency), currency) +
                                        (p.price(Finish.FOIL, currency)?.let { " · F " + Format.price(it, currency) } ?: ""),
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
