package com.manavault.app.data.repo

import android.content.Context
import com.manavault.app.core.interaction.ClaudeProtocol
import com.manavault.app.core.model.Condition
import com.manavault.app.core.model.Currency
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class Settings(
    val apiKey: String = "",
    val model: String = ClaudeProtocol.DEFAULT_MODEL,
    val currency: Currency = Currency.USD,
    val defaultCondition: Condition = Condition.NM,
) {
    val hasApiKey: Boolean get() = apiKey.isNotBlank()
}

/** App preferences, stored privately on the device. */
class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("manavault_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<Settings> = _settings.asStateFlow()

    private fun load() = Settings(
        apiKey = prefs.getString(KEY_API, "").orEmpty(),
        model = prefs.getString(KEY_MODEL, null) ?: ClaudeProtocol.DEFAULT_MODEL,
        currency = Currency.fromKey(prefs.getString(KEY_CURRENCY, null)),
        defaultCondition = Condition.fromCode(prefs.getString(KEY_CONDITION, null)),
    )

    private fun save(edit: (android.content.SharedPreferences.Editor) -> Unit) {
        val e = prefs.edit()
        edit(e)
        e.apply()
        _settings.value = load()
    }

    fun setApiKey(key: String) = save { it.putString(KEY_API, key.trim()) }
    fun setModel(model: String) = save { it.putString(KEY_MODEL, model.trim().ifEmpty { ClaudeProtocol.DEFAULT_MODEL }) }
    fun setCurrency(currency: Currency) = save { it.putString(KEY_CURRENCY, currency.key) }
    fun setDefaultCondition(condition: Condition) = save { it.putString(KEY_CONDITION, condition.code) }

    var lastPriceRefresh: Long
        get() = prefs.getLong(KEY_LAST_REFRESH, 0L)
        set(value) { prefs.edit().putLong(KEY_LAST_REFRESH, value).apply() }

    private companion object {
        const val KEY_API = "anthropic_api_key"
        const val KEY_MODEL = "claude_model"
        const val KEY_CURRENCY = "currency"
        const val KEY_CONDITION = "default_condition"
        const val KEY_LAST_REFRESH = "last_price_refresh"
    }
}
