package com.manavault.app.core.scan

/** One line of recognized text with its bounding box in upright image coordinates. */
data class OcrLine(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val height: Int get() = bottom - top
}

/** What the scanner could read off a card in one frame. */
data class ScanReading(
    val nameCandidates: List<String>,
    val setCode: String?,
    val collectorNumber: String?,
) {
    val bestName: String? get() = nameCandidates.firstOrNull()
    val hasPrintingInfo: Boolean get() = setCode != null && collectorNumber != null
}

/**
 * Turns raw OCR lines from a camera frame into a card name guess plus (on cards printed since 2014)
 * the set code and collector number printed in the bottom-left corner, which pin down the exact printing.
 */
object CardTextExtractor {

    private val TYPE_WORDS = setOf(
        "legendary", "basic", "snow", "world", "tribal", "kindred", "ongoing", "host", "elite",
        "creature", "artifact", "enchantment", "land", "planeswalker", "instant", "sorcery", "battle",
        "token", "conspiracy", "phenomenon", "plane", "scheme", "vanguard", "dungeon",
    )
    private val MANA_JUNK = Regex("^[0-9XYZWUBRGCSP@©®°*{}()\\[\\]|/\\\\.,:;~^'\"`=+\\-]{1,6}$")
    private val NON_NAME_CHARS = Regex("[^\\p{L}0-9 ',\\-:!?&.]")
    private val LANGS = "EN|ES|FR|DE|IT|PT|JA|JP|KO|RU|ZHS|ZHT|CS|CT|PH"
    private val SET_LINE = Regex("(?<![A-Z0-9])([A-Z0-9]{3,5})\\s*[•·*.,\\-]?\\s*(?:$LANGS)(?![A-Za-z])")
    private val NUMBER_SLASH = Regex("(?<!\\d)(\\d{1,4})\\s*/\\s*\\d{1,4}(?!\\d)")
    private val NUMBER_RARITY_AFTER = Regex("(?:^|\\s)(\\d{1,4}[a-z]?)\\s+[CURMSLTPB](?:\\s|$)")
    private val NUMBER_RARITY_BEFORE = Regex("(?:^|\\s)[CURMSLTPB]\\s+(\\d{1,4}[a-z]?)(?:\\s|$)")

    fun extract(lines: List<OcrLine>): ScanReading {
        val clean = lines.filter { it.text.isNotBlank() }
        if (clean.isEmpty()) return ScanReading(emptyList(), null, null)

        val minTop = clean.minOf { it.top }
        val maxBottom = clean.maxOf { it.bottom }
        val span = (maxBottom - minTop).coerceAtLeast(1)
        val sorted = clean.sortedBy { it.top }

        // --- name: tall text near the top of the card ---
        val topRegion = sorted.filter { it.top - minTop <= span * 0.4 }.take(6)
        val named = topRegion.mapNotNull { line -> cleanName(line.text)?.let { line to it } }
        val tallest = named.maxOfOrNull { it.first.height } ?: 0
        val candidates = named
            .filter { (line, _) -> line.height >= tallest * 0.6 }
            .map { it.second }
            .distinct()

        // --- set code + collector number: small print at the bottom ---
        val bottomRegion = sorted.filter { maxBottom - it.bottom <= span * 0.25 }.takeLast(6)
        var setCode: String? = null
        var number: String? = null
        for (line in bottomRegion) {
            val t = line.text.trim()
            if (setCode == null) {
                SET_LINE.find(t.uppercase())?.let { m ->
                    val code = m.groupValues[1]
                    if (code.any { it.isLetter() }) setCode = code
                }
            }
            if (number == null) {
                number = (NUMBER_SLASH.find(t) ?: NUMBER_RARITY_AFTER.find(t) ?: NUMBER_RARITY_BEFORE.find(t))
                    ?.groupValues?.get(1)?.let(::normalizeNumber)
            }
        }
        return ScanReading(candidates, setCode?.lowercase(), number)
    }

    /** "0146" -> "146", "0007a" -> "7a", "000" -> "0" */
    fun normalizeNumber(raw: String): String {
        val trimmed = raw.trimStart('0')
        return when {
            trimmed.isEmpty() -> "0"
            !trimmed.first().isDigit() -> "0$trimmed"
            else -> trimmed
        }
    }

    /** Returns a plausible card name from a raw OCR line, or null if the line can't be a name. */
    fun cleanName(raw: String): String? {
        if (raw.contains('©') || raw.contains('™') || raw.contains("Wizards", ignoreCase = true)) return null
        if (looksLikeTypeLine(raw)) return null
        var tokens = raw.replace('’', '\'').replace('‘', '\'')
            .replace(NON_NAME_CHARS, " ")
            .split(' ')
            .filter { it.isNotBlank() }
            .toMutableList()
        // OCR often reads the mana cost next to the name as a few stray characters.
        while (tokens.isNotEmpty() && isJunk(tokens.last())) tokens.removeAt(tokens.lastIndex)
        while (tokens.isNotEmpty() && isJunk(tokens.first())) tokens.removeAt(0)
        if (tokens.isEmpty() || tokens.size > 7) return null

        val name = tokens.joinToString(" ").trim(' ', ',', '-', ':', '.')
        val letters = name.count { it.isLetter() }
        val nonSpace = name.count { !it.isWhitespace() }
        if (letters < 3 || nonSpace == 0 || letters.toDouble() / nonSpace < 0.7) return null
        if (name.length > 45) return null
        if (looksLikeTypeLine(name)) return null
        // Rules text tends to be long sentences of lowercase words.
        val lowerWords = tokens.count { it.first().isLowerCase() && it.length > 3 }
        if (lowerWords >= 3) return null
        return name
    }

    private fun isJunk(token: String): Boolean {
        if (token.length > 6) return false
        if (token.any { it.isLowerCase() }) return false
        if (!MANA_JUNK.matches(token)) return false
        // Keep real short words like "of"/"the" (lowercase, handled above) and initials like "Mr." — but drop
        // lone uppercase mana letters and digit clusters such as "2", "1G", "WW", "@".
        return token.any { it.isDigit() } || token.length <= 3
    }

    fun looksLikeTypeLine(text: String): Boolean {
        val beforeDash = text.split('—', '-', '–').first()
        val words = beforeDash.split(' ', ',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        return words.isNotEmpty() && words.all { it in TYPE_WORDS }
    }

    // ---- name comparison --------------------------------------------------------------------

    fun normalize(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    /** Similarity in [0,1] based on edit distance of the normalized strings. */
    fun similarity(a: String, b: String): Double {
        val x = normalize(a)
        val y = normalize(b)
        if (x.isEmpty() || y.isEmpty()) return 0.0
        val d = levenshtein(x, y)
        return 1.0 - d.toDouble() / maxOf(x.length, y.length)
    }

    /** Does the OCR'd name plausibly match the card (any face)? */
    fun nameMatches(ocrName: String, cardName: String): Boolean {
        val faces = cardName.split(" // ") + cardName
        return faces.any { face ->
            val a = normalize(ocrName)
            val b = normalize(face)
            similarity(ocrName, face) >= 0.7 || (a.length >= 5 && b.startsWith(a)) || (b.length >= 5 && a.startsWith(b))
        }
    }

    fun levenshtein(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }
}

/**
 * Debounces OCR results across frames: a name is only accepted once it has been read in
 * [required] of the last [window] frames, which filters out half-focused misreads.
 */
class ScanStabilizer(private val window: Int = 4, private val required: Int = 2) {
    private val recent = ArrayDeque<Pair<String, String>>()

    fun offer(name: String?): String? {
        val key = name?.let(CardTextExtractor::normalize).orEmpty()
        recent.addLast(key to (name ?: ""))
        while (recent.size > window) recent.removeFirst()
        if (key.isEmpty()) return null
        val hits = recent.count { it.first == key }
        return if (hits >= required) name else null
    }

    fun reset() = recent.clear()
}
