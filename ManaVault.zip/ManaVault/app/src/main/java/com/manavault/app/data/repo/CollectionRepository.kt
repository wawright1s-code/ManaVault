package com.manavault.app.data.repo

import androidx.room.withTransaction
import com.manavault.app.core.collection.CollectionCsv
import com.manavault.app.core.collection.CsvCollectionRow
import com.manavault.app.core.deck.DeckListFormat
import com.manavault.app.core.model.Card
import com.manavault.app.core.model.Condition
import com.manavault.app.core.model.Currency
import com.manavault.app.core.model.Finish
import com.manavault.app.data.db.AppDatabase
import com.manavault.app.data.db.CollectionEntryEntity
import com.manavault.app.data.db.ValueSnapshotEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import java.time.LocalDate

/** One collection entry: a quantity of one printing in one finish and condition. */
data class OwnedCard(
    val entryId: Long,
    val card: Card,
    val quantity: Int,
    val finish: Finish,
    val condition: Condition,
    val language: String,
    val addedAt: Long,
) {
    fun unitPrice(currency: Currency): Double? = card.priceOrFallback(finish, currency)
    fun totalPrice(currency: Currency): Double = (unitPrice(currency) ?: 0.0) * quantity
}

data class ImportReport(val added: Int, val distinct: Int, val notFound: List<String>)

class CollectionRepository(
    private val db: AppDatabase,
    private val cards: CardRepository,
    private val settings: SettingsRepository,
) {
    val owned: Flow<List<OwnedCard>> = db.collection().observeRows()
        .map { rows ->
            rows.map { r ->
                OwnedCard(
                    entryId = r.entry.id,
                    card = cards.decode(r.entry.cardId, r.cardJson, r.cardUpdatedAt),
                    quantity = r.entry.quantity,
                    finish = Finish.fromKey(r.entry.finish),
                    condition = Condition.fromCode(r.entry.condition),
                    language = r.entry.language,
                    addedAt = r.entry.addedAt,
                )
            }
        }
        .flowOn(Dispatchers.Default)

    val snapshots: Flow<List<ValueSnapshotEntity>> = db.snapshots().observeRecent(90)

    suspend fun add(
        card: Card,
        quantity: Int = 1,
        finish: Finish = card.defaultFinish,
        condition: Condition = settings.settings.value.defaultCondition,
        language: String = card.lang,
    ): Long {
        cards.cache(card)
        return addCached(card.id, quantity, finish, condition, language)
    }

    private suspend fun addCached(cardId: String, quantity: Int, finish: Finish, condition: Condition, language: String): Long {
        val dao = db.collection()
        val now = System.currentTimeMillis()
        return db.withTransaction {
            val existing = dao.find(cardId, finish.key, condition.code, language)
            if (existing != null) {
                dao.setQuantity(existing.id, existing.quantity + quantity, now)
                existing.id
            } else {
                dao.insert(
                    CollectionEntryEntity(
                        cardId = cardId, quantity = quantity, finish = finish.key, condition = condition.code,
                        language = language, addedAt = now, updatedAt = now,
                    )
                )
            }
        }
    }

    suspend fun setQuantity(entryId: Long, quantity: Int) {
        if (quantity <= 0) db.collection().delete(entryId)
        else db.collection().setQuantity(entryId, quantity, System.currentTimeMillis())
    }

    /** Changes printing, finish, condition or quantity; merges into an existing identical entry if needed. */
    suspend fun edit(entryId: Long, card: Card, finish: Finish, condition: Condition, quantity: Int) {
        cards.cache(card)
        val dao = db.collection()
        db.withTransaction {
            val current = dao.get(entryId) ?: return@withTransaction
            if (quantity <= 0) {
                dao.delete(entryId)
                return@withTransaction
            }
            val clash = dao.find(card.id, finish.key, condition.code, current.language)
            val now = System.currentTimeMillis()
            if (clash != null && clash.id != entryId) {
                dao.setQuantity(clash.id, clash.quantity + quantity, now)
                dao.delete(entryId)
            } else {
                dao.update(current.copy(cardId = card.id, finish = finish.key, condition = condition.code, quantity = quantity, updatedAt = now))
            }
        }
    }

    suspend fun entry(entryId: Long): CollectionEntryEntity? = db.collection().get(entryId)

    suspend fun remove(entryId: Long) = db.collection().delete(entryId)

    // Chunked: older SQLite versions allow at most 999 bound parameters per statement.
    suspend fun removeMany(entryIds: Collection<Long>) = db.withTransaction {
        entryIds.toList().chunked(500).forEach { db.collection().deleteMany(it) }
    }

    /** Refreshes prices for every card in the collection and records today's total value. */
    suspend fun refreshPrices(onProgress: (Int, Int) -> Unit = { _, _ -> }): Int {
        val ids = db.collection().cardIds()
        val n = cards.refresh(ids, onProgress)
        settings.lastPriceRefresh = System.currentTimeMillis()
        recordSnapshot()
        return n
    }

    suspend fun recordSnapshot() {
        val rows = db.collection().rows()
        if (rows.isEmpty()) return
        var usd = 0.0
        var eur = 0.0
        var tix = 0.0
        var count = 0
        for (r in rows) {
            val card = cards.decode(r.entry.cardId, r.cardJson, r.cardUpdatedAt)
            val finish = Finish.fromKey(r.entry.finish)
            usd += (card.priceOrFallback(finish, Currency.USD) ?: 0.0) * r.entry.quantity
            eur += (card.priceOrFallback(finish, Currency.EUR) ?: 0.0) * r.entry.quantity
            tix += (card.priceOrFallback(finish, Currency.TIX) ?: 0.0) * r.entry.quantity
            count += r.entry.quantity
        }
        db.snapshots().upsert(ValueSnapshotEntity(LocalDate.now().toEpochDay(), usd, eur, tix, count))
    }

    suspend fun exportCsv(): String {
        val rows = db.collection().rows().map { r ->
            val card = cards.decode(r.entry.cardId, r.cardJson, r.cardUpdatedAt)
            val finish = Finish.fromKey(r.entry.finish)
            CsvCollectionRow(
                quantity = r.entry.quantity,
                name = card.name,
                setCode = card.setCode,
                setName = card.setName,
                collectorNumber = card.collectorNumber,
                finish = finish,
                condition = Condition.fromCode(r.entry.condition),
                language = r.entry.language,
                scryfallId = card.id,
                price = card.priceOrFallback(finish, Currency.USD),
            )
        }.sortedBy { it.name }
        return CollectionCsv.write(rows)
    }

    /** Imports a CSV export (from this app or ManaBox, Moxfield, Deckbox…) or a plain "4 Card Name" list. */
    suspend fun importText(text: String, onProgress: (String) -> Unit = {}): ImportReport {
        val csvRows = CollectionCsv.read(text)
        val rows: List<CsvCollectionRow> = csvRows
            ?: DeckListFormat.parse(text).map {
                CsvCollectionRow(
                    quantity = it.quantity, name = it.name, setCode = it.setCode, collectorNumber = it.collectorNumber,
                    finish = if (it.foil) Finish.FOIL else Finish.NONFOIL,
                )
            }
        if (rows.isEmpty()) return ImportReport(0, 0, emptyList())
        val requests = rows.map { CardRequest(it.name.ifBlank { null }, it.setCode, it.collectorNumber, it.scryfallId) }
        val resolved = cards.resolve(requests, onProgress)
        onProgress("Adding to your collection…")
        var added = 0
        val notFound = mutableListOf<String>()
        val defaultCondition = settings.settings.value.defaultCondition
        rows.forEachIndexed { i, row ->
            val card = resolved[i]
            if (card == null) {
                notFound += requests[i].label
                return@forEachIndexed
            }
            val finish = if (row.finish.key in card.finishes) row.finish else card.defaultFinish
            val condition = if (csvRows != null) row.condition else defaultCondition
            addCached(card.id, row.quantity, finish, condition, row.language)
            added += row.quantity
        }
        recordSnapshot()
        return ImportReport(added, resolved.filterNotNull().distinctBy { it.id }.size, notFound)
    }
}
