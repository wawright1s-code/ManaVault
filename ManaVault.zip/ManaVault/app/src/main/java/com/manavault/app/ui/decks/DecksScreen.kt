package com.manavault.app.ui.decks

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Style
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.manavault.app.core.deck.DeckAnalysis
import com.manavault.app.core.deck.Formats
import com.manavault.app.core.deck.Severity
import com.manavault.app.core.model.Currency
import com.manavault.app.core.text.Format
import com.manavault.app.data.repo.DeckWithCards
import com.manavault.app.graph
import com.manavault.app.ui.Navigator
import com.manavault.app.ui.components.ColorIdentity
import com.manavault.app.ui.components.EmptyState
import com.manavault.app.ui.components.ScreenScaffold
import com.manavault.app.ui.components.Tag
import kotlinx.coroutines.launch

@Composable
fun DecksScreen(nav: Navigator) {
    val graph = LocalContext.current.graph
    val decksFlow = remember { graph.decks.observeDecks() }
    val decks by decksFlow.collectAsStateWithLifecycle(initialValue = null)
    val currency = graph.settings.settings.collectAsStateWithLifecycle().value.currency
    var creating by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    ScreenScaffold(
        title = "Decks",
        floatingActionButton = {
            ExtendedFloatingActionButton(
                text = { Text("New deck") },
                icon = { Icon(Icons.Filled.Add, null) },
                onClick = { creating = true },
            )
        },
    ) { padding ->
        val list = decks
        when {
            list == null -> Unit
            list.isEmpty() -> EmptyState(
                icon = Icons.Filled.Style,
                title = "No decks yet",
                message = "Build a deck from scratch, or paste a list exported from Arena, MTGO, Moxfield or Archidekt.",
                modifier = Modifier.padding(padding),
            )
            else -> LazyColumn(
                Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(list, key = { it.deck.id }) { d -> DeckCard(d, currency) { nav.deck(d.deck.id) } }
            }
        }
    }

    if (creating) {
        NewDeckDialog(
            onDismiss = { creating = false },
            onCreate = { name, format, list ->
                scope.launch {
                    val id = graph.decks.create(name, format)
                    if (list.isNotBlank()) graph.decks.importList(id, list, replace = true)
                    nav.deck(id)
                }
            },
        )
    }
}

@Composable
private fun DeckCard(d: DeckWithCards, currency: Currency, onClick: () -> Unit) {
    val issues = remember(d) { DeckAnalysis.checkLegality(d.format, d.entries).count { it.severity == Severity.ERROR } }
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(104.dp).height(84.dp).background(MaterialTheme.colorScheme.surfaceVariant)) {
                d.coverArt?.let {
                    AsyncImage(model = it, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
            }
            Column(Modifier.weight(1f).padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(d.deck.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ColorIdentity(d.colorIdentity, size = 14.dp)
                    Text(
                        "${d.format.name} · ${d.playingCount} cards",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(Format.price(d.value(currency), currency), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    if (d.format.id != Formats.CASUAL.id && d.entries.isNotEmpty()) {
                        if (issues == 0) Tag("Legal", MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer)
                        else Tag("$issues issue${if (issues == 1) "" else "s"}", MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
        }
    }
}

@Composable
fun FormatPicker(selected: String, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Formats.all.forEach { f ->
            FilterChip(selected = f.id == selected, onClick = { onSelect(f.id) }, label = { Text(f.name) })
        }
    }
}

@Composable
private fun NewDeckDialog(onDismiss: () -> Unit, onCreate: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var format by remember { mutableStateOf(Formats.COMMANDER.id) }
    var list by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New deck") },
        text = {
            Column(Modifier.heightIn(max = 520.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                Text("Format", style = MaterialTheme.typography.labelLarge)
                FormatPicker(format) { format = it }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = list,
                    onValueChange = { list = it },
                    label = { Text("Paste a deck list (optional)") },
                    placeholder = { Text("1 Sol Ring\n1 Command Tower\n…") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp, max = 180.dp),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onCreate(name, format, list); onDismiss() }) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
