package com.manavault.app.ui.decks

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.manavault.app.core.interaction.ClaudeProtocol
import com.manavault.app.core.text.MiniMarkdown
import com.manavault.app.ui.components.AnswerCard
import com.manavault.app.ui.components.FollowUpComposer
import com.manavault.app.ui.components.QuestionBubble

/** Full-screen conversation with Claude about the whole deck. */
@Composable
fun DeckAnalysisDialog(
    deckName: String,
    analysis: AnalysisUi,
    hasApiKey: Boolean,
    onAnalyze: (String) -> Unit,
    onReset: () -> Unit,
    onOpenSettings: () -> Unit,
    onDismiss: () -> Unit,
) {
    val clipboard = LocalClipboardManager.current
    val listState = rememberLazyListState()
    var focus by remember { mutableStateOf("") }
    val visible = analysis.visible

    LaunchedEffect(visible.size) {
        if (visible.isNotEmpty()) listState.animateScrollToItem(visible.size)
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxSize().imePadding()) {
                Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Close") }
                    Column(Modifier.weight(1f)) {
                        Text("Deck analysis", style = MaterialTheme.typography.titleLarge)
                        Text(deckName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (analysis.thread.isNotEmpty() && !analysis.loading) TextButton(onClick = onReset) { Text("Start over") }
                }

                if (!hasApiKey) {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "Deck analysis uses Claude. Add your Anthropic API key in Settings to turn it on.",
                            style = MaterialTheme.typography.bodyLarge,
                        )
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = onOpenSettings) { Text("Open Settings") }
                    }
                } else {
                    AnalysisConversation(analysis, listState, focus, { focus = it }, onAnalyze, onCopy = { clipboard.setText(AnnotatedString(it)) })
                }
            }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.ColumnScope.AnalysisConversation(
    analysis: AnalysisUi,
    listState: androidx.compose.foundation.lazy.LazyListState,
    focus: String,
    onFocusChange: (String) -> Unit,
    onAnalyze: (String) -> Unit,
    onCopy: (String) -> Unit,
) {
    val visible = analysis.visible
    LazyColumn(Modifier.weight(1f), state = listState, contentPadding = PaddingValues(bottom = 24.dp)) {
        item(key = "intro") {
            if (analysis.thread.isEmpty()) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "Claude reviews the whole list: game plan, synergies and combos, mana and curve, weak spots, and suggested swaps that are legal in your format.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = focus,
                        onValueChange = onFocusChange,
                        label = { Text("Anything to focus on? (optional)") },
                        placeholder = { Text("e.g. budget upgrades under \$5, more removal") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3,
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { onAnalyze(focus) }, enabled = !analysis.loading, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.AutoAwesome, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Analyze deck")
                    }
                }
            }
        }
        items(visible.size, key = { "t$it" }) { i ->
            val turn = visible[i]
            if (turn.role == "user") {
                QuestionBubble(turn.text)
            } else {
                AnswerCard(
                    markdown = turn.text,
                    footer = if (i == visible.lastIndex) footer(analysis) else null,
                    onCopy = { onCopy(MiniMarkdown.toPlainText(turn.text)) },
                )
            }
        }
        if (analysis.loading && visible.lastOrNull()?.role != "assistant") {
            item(key = "loading") {
                Row(Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(12.dp))
                    Text("Claude is reviewing the deck…")
                }
            }
        }
        analysis.error?.let { err ->
            item(key = "error") {
                Text(err, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp))
            }
        }
    }
    if (visible.any { it.role == "assistant" }) {
        FollowUpComposer(loading = analysis.loading, label = "Thinking…", onSend = onAnalyze)
    }
}

private fun footer(a: AnalysisUi): String {
    val u = a.usage ?: return ""
    val label = ClaudeProtocol.MODELS.firstOrNull { it.id == u.model }?.label ?: u.model
    val cost = u.costUsd?.let { if (it < 0.01) " · under 1¢" else " · about %.0f¢".format(it * 100) }.orEmpty()
    return label + cost
}
