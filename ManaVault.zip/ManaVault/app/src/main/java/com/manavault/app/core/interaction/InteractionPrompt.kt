package com.manavault.app.core.interaction

import com.manavault.app.core.model.Card
import com.manavault.app.core.model.Ruling

/** Builds the prompt sent to Claude for the interaction explainer. */
object InteractionPrompt {

    const val MAX_RULINGS_PER_CARD = 15
    private const val MAX_RULING_CHARS = 500

    val SYSTEM = """
You are an expert Magic: The Gathering rules advisor with the knowledge of a Level 3 judge. The player has selected cards and wants to understand how they work together.

Ground rules:
- The Oracle text and official rulings in the message are authoritative and current. Base your answer on them and on the Comprehensive Rules.
- Be concrete: say what happens, in what order, who makes each choice, and when. Bring in the stack, priority, triggered abilities, replacement effects, state-based actions, layers and timing restrictions only where they actually matter.
- If the cards form a combo or a loop, say so plainly, walk through one full iteration, and say whether it is infinite, whether it is optional or mandatory, and what else it needs (mana, a sacrifice outlet, a specific board state).
- If the cards don't meaningfully interact, say so honestly and briefly describe what each does instead of inventing synergy.
- Cite Comprehensive Rules numbers only when you are confident of them.
- Call out common misconceptions and edge cases players get wrong.
- If the answer depends on board state you don't know, state the assumption you're making.

Format your answer in Markdown using these sections, skipping any that don't apply:
## Summary
## How they interact
## Step by step
## Rules that matter
## Gotchas

Keep it tight — no filler or preamble. For follow-up questions, answer directly and briefly in plain Markdown without the section template.
""".trimIndent()

    fun cardBlock(index: Int, card: Card, rulings: List<Ruling>): String = buildString {
        append("### Card ").append(index).append(": ").append(card.name).append('\n')
        if (card.faces.size >= 2 && card.oracleText.isBlank()) {
            card.faces.forEachIndexed { i, f ->
                append("Face ").append(i + 1).append(": ").append(f.name).append('\n')
                if (f.manaCost.isNotBlank()) append("Mana cost: ").append(f.manaCost).append('\n')
                append("Type: ").append(f.typeLine).append('\n')
                stats(f.power, f.toughness, f.loyalty, f.defense)?.let { append(it).append('\n') }
                append("Oracle text:\n").append(f.oracleText.ifBlank { "(no rules text)" }).append('\n')
            }
        } else {
            if (card.displayManaCost.isNotBlank()) append("Mana cost: ").append(card.displayManaCost).append('\n')
            append("Type: ").append(card.displayTypeLine).append('\n')
            stats(card.power, card.toughness, card.loyalty, card.defense)?.let { append(it).append('\n') }
            append("Oracle text:\n").append(card.allOracleText.ifBlank { "(no rules text)" }).append('\n')
        }
        val relevant = rulings.sortedByDescending { it.publishedAt }.take(MAX_RULINGS_PER_CARD)
        if (relevant.isNotEmpty()) {
            append("Official rulings:\n")
            for (r in relevant) {
                append("- (").append(r.publishedAt).append(") ").append(r.comment.take(MAX_RULING_CHARS)).append('\n')
            }
        }
    }

    private fun stats(power: String?, toughness: String?, loyalty: String?, defense: String?): String? = when {
        power != null && toughness != null -> "Power/Toughness: $power/$toughness"
        loyalty != null -> "Starting loyalty: $loyalty"
        defense != null -> "Defense: $defense"
        else -> null
    }

    fun userMessage(cards: List<Card>, rulings: Map<String, List<Ruling>>, context: String?): String = buildString {
        if (cards.size == 1) {
            append("Explain how this card works, including the rules questions players most often get wrong.\n\n")
        } else {
            append("Explain how these ").append(cards.size).append(" cards interact when used together.\n\n")
        }
        cards.forEachIndexed { i, c ->
            append(cardBlock(i + 1, c, rulings[c.oracleId] ?: rulings[c.id].orEmpty()))
            append('\n')
        }
        if (!context.isNullOrBlank()) {
            append("Additional context from the player:\n").append(context.trim()).append('\n')
        }
    }
}
