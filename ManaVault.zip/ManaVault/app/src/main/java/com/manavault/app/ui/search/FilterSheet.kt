package com.manavault.app.ui.search

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.manavault.app.core.model.Currency
import com.manavault.app.core.scryfall.ColorMode
import com.manavault.app.core.scryfall.SearchFilters
import com.manavault.app.core.text.Format
import com.manavault.app.ui.components.SymbolIcon
import kotlin.math.roundToInt

private const val MV_MAX = 10

/** Bottom sheet for building a search without Scryfall syntax. */
@Composable
fun FilterSheet(
    initial: SearchFilters,
    currency: Currency,
    onDismiss: () -> Unit,
    onApply: (SearchFilters) -> Unit,
) {
    var f by remember { mutableStateOf(initial) }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Filters", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                TextButton(onClick = { f = SearchFilters() }) { Text("Reset") }
            }

            Label("Colors")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("W", "U", "B", "R", "G", "C").forEach { c ->
                    FilterChip(
                        selected = c in f.colors,
                        onClick = { f = f.copy(colors = f.colors.toggle(c)) },
                        label = { SymbolIcon(c, 20.dp) },
                    )
                }
            }
            if (f.colors.isNotEmpty()) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ColorMode.entries.forEach { m ->
                        FilterChip(selected = f.colorMode == m, onClick = { f = f.copy(colorMode = m) }, label = { Text(m.label) })
                    }
                }
                Text(
                    when (f.colorMode) {
                        ColorMode.INCLUDES -> "Cards that are at least these colors (may have more)."
                        ColorMode.EXACTLY -> "Cards that are exactly these colors."
                        ColorMode.AT_MOST -> "Cards using only these colors (or fewer)."
                        ColorMode.IDENTITY -> "Cards you can play in a Commander deck of these colors."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Label("Card type")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SearchFilters.TYPES.forEach { t ->
                    FilterChip(selected = t in f.types, onClick = { f = f.copy(types = f.types.toggle(t)) }, label = { Text(t) })
                }
                FilterChip(selected = f.legendary, onClick = { f = f.copy(legendary = !f.legendary) }, label = { Text("Legendary") })
                FilterChip(selected = f.commanders, onClick = { f = f.copy(commanders = !f.commanders) }, label = { Text("Can be a commander") })
            }

            Label("Legal in")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = f.format == null, onClick = { f = f.copy(format = null) }, label = { Text("Any") })
                SearchFilters.FORMATS.forEach { (id, name) ->
                    FilterChip(selected = f.format == id, onClick = { f = f.copy(format = id) }, label = { Text(name) })
                }
            }

            Label("Rarity")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SearchFilters.RARITIES.forEach { r ->
                    FilterChip(selected = r in f.rarities, onClick = { f = f.copy(rarities = f.rarities.toggle(r)) }, label = { Text(Format.rarity(r)) })
                }
            }

            val lo = f.minMv ?: 0
            val hi = f.maxMv ?: MV_MAX
            Label("Mana value: " + when {
                f.minMv == null && f.maxMv == null -> "any"
                lo == hi -> "$lo"
                f.maxMv == null -> "$lo or more"
                else -> "$lo to $hi"
            })
            RangeSlider(
                value = lo.toFloat()..hi.toFloat(),
                onValueChange = { r ->
                    val a = r.start.roundToInt()
                    val b = r.endInclusive.roundToInt()
                    f = f.copy(minMv = a.takeIf { it > 0 }, maxMv = b.takeIf { it < MV_MAX })
                },
                valueRange = 0f..MV_MAX.toFloat(),
                steps = MV_MAX - 1,
            )

            Label("Maximum price")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = f.maxPrice == null, onClick = { f = f.copy(maxPrice = null) }, label = { Text("Any") })
                listOf(0.5, 1.0, 5.0, 10.0, 25.0, 50.0).forEach { p ->
                    FilterChip(selected = f.maxPrice == p, onClick = { f = f.copy(maxPrice = p) }, label = { Text(Format.price(p, currency).removeSuffix(".00")) })
                }
            }

            Label("Rules text contains")
            OutlinedTextField(
                value = f.rulesText,
                onValueChange = { f = f.copy(rulesText = it) },
                placeholder = { Text("e.g. draw a card") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(Modifier.height(20.dp))
            Button(onClick = { onApply(f) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (f.isEmpty) "Clear filters" else "Show results")
            }
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))
}

private fun <T> Set<T>.toggle(item: T): Set<T> = if (item in this) this - item else this + item
