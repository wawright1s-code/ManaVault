package com.manavault.app.core.deck

import com.manavault.app.core.model.Card
import kotlin.random.Random

/** A goldfish session: shuffle the main deck, draw an opening hand, mulligan, and draw turn by turn. */
class Playtest(entries: List<DeckCardEntry>, private val random: Random = Random.Default) {

    /** One physical card in the session (copies of the same card get distinct ids). */
    data class PlayCard(val id: Int, val card: Card)

    private val deck: List<Card> = entries.filter { it.board == Board.MAIN }.flatMap { e -> List(e.quantity) { e.card } }

    var library: List<PlayCard> = emptyList()
        private set
    var hand: List<PlayCard> = emptyList()
        private set
    var mulligans: Int = 0
        private set
    /** Turn number; 0 means "opening hand". */
    var turn: Int = 0
        private set
    /** London mulligan: after a mulligan you keep 7 and put this many on the bottom. */
    val toBottom: Int get() = (mulligans - bottomed).coerceAtLeast(0)
    private var bottomed = 0

    val deckSize: Int get() = deck.size

    init {
        newGame()
    }

    fun newGame() {
        mulligans = 0
        bottomed = 0
        dealOpeningHand()
    }

    fun mulligan() {
        if (mulligans >= 6) return
        mulligans++
        bottomed = 0
        dealOpeningHand()
    }

    private fun dealOpeningHand() {
        val shuffled = deck.mapIndexed { i, c -> PlayCard(i, c) }.shuffled(random)
        hand = shuffled.take(OPENING_HAND)
        library = shuffled.drop(OPENING_HAND)
        turn = 0
    }

    /** Puts a card from hand on the bottom of the library (for the London mulligan). */
    fun putOnBottom(card: PlayCard) {
        if (card !in hand || toBottom == 0) return
        hand = hand - card
        library = library + card
        bottomed++
    }

    /** Draws the next card and advances the turn counter. */
    fun draw(): PlayCard? {
        val top = library.firstOrNull() ?: return null
        library = library.drop(1)
        hand = hand + top
        turn++
        return top
    }

    companion object {
        const val OPENING_HAND = 7
    }
}

/** Probability helpers for deck building. */
object DeckOdds {

    /** ln(n!) table-free: sum of logs; fine for deck-sized numbers. */
    private fun lnFactorial(n: Int): Double {
        var s = 0.0
        for (i in 2..n) s += kotlin.math.ln(i.toDouble())
        return s
    }

    private fun lnChoose(n: Int, k: Int): Double =
        if (k < 0 || k > n) Double.NEGATIVE_INFINITY else lnFactorial(n) - lnFactorial(k) - lnFactorial(n - k)

    /** P(exactly k successes) drawing [draws] cards from [population] containing [successes]. */
    fun exactly(population: Int, successes: Int, draws: Int, k: Int): Double {
        if (population <= 0 || draws < 0 || draws > population) return 0.0
        val ln = lnChoose(successes, k) + lnChoose(population - successes, draws - k) - lnChoose(population, draws)
        return if (ln == Double.NEGATIVE_INFINITY) 0.0 else kotlin.math.exp(ln)
    }

    fun atLeast(population: Int, successes: Int, draws: Int, k: Int): Double =
        (k..minOf(draws, successes)).sumOf { exactly(population, successes, draws, it) }.coerceIn(0.0, 1.0)

    /** Chance of each land count (0..7) in a 7-card opening hand. */
    fun openingHandLands(deckSize: Int, lands: Int): List<Double> =
        (0..Playtest.OPENING_HAND).map { exactly(deckSize, lands, minOf(Playtest.OPENING_HAND, deckSize), it) }

    /**
     * Chance of having made every land drop through [turn] (i.e. at least [turn] lands among the
     * cards seen by then). On the play you see 6 + turn cards; on the draw 7 + turn.
     */
    fun hitLandDrops(deckSize: Int, lands: Int, turn: Int, onThePlay: Boolean = true): Double {
        val seen = (if (onThePlay) 6 else 7) + turn
        return atLeast(deckSize, lands, minOf(seen, deckSize), turn)
    }
}
