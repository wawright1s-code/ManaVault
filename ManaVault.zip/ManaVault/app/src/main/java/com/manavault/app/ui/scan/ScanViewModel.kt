package com.manavault.app.ui.scan

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.manavault.app.AppGraph
import com.manavault.app.core.model.Card
import com.manavault.app.core.model.Finish
import com.manavault.app.core.scan.CardTextExtractor
import com.manavault.app.core.scan.ScanGeometry
import com.manavault.app.core.scan.ScanReading
import com.manavault.app.core.scan.ScanStabilizer
import com.manavault.app.core.text.LruMap
import com.manavault.app.ui.components.userMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ScanMode { SINGLE, BULK }

data class SessionItem(val entryId: Long, val card: Card, val finish: Finish, val at: Long)

data class ScanUiState(
    val mode: ScanMode = ScanMode.SINGLE,
    val bulkFinish: Finish = Finish.NONFOIL,
    val status: String = "Fit the card inside the frame",
    val reading: String? = null,
    val result: Card? = null,
    val lookingUp: Boolean = false,
    val torch: Boolean = false,
    val session: List<SessionItem> = emptyList(),
    val lastAdded: Card? = null,
)

class ScanViewModel(private val graph: AppGraph) : ViewModel() {

    private val _state = MutableStateFlow(ScanUiState())
    val state: StateFlow<ScanUiState> = _state.asStateFlow()

    private val stabilizer = ScanStabilizer(window = 4, required = 2)
    private val found = LruMap<String, Card>(300)
    private val misses = LruMap<String, Long>(300)

    // Bulk mode: don't add the same card again until it has left the frame for a few reads.
    private var lastAddedKey: String? = null
    private var framesWithoutLast = 0

    private var viewWidth = 0
    private var viewHeight = 0

    fun setViewSize(width: Int, height: Int) {
        viewWidth = width
        viewHeight = height
    }

    fun onFrame(frame: OcrFrame) {
        val s = _state.value
        if (s.result != null || s.lookingUp) return
        val lines = ScanGeometry.linesInGuide(frame.lines, frame.imageWidth, frame.imageHeight, viewWidth, viewHeight)
        val reading = CardTextExtractor.extract(lines)
        val best = reading.bestName
        val key = best?.let(CardTextExtractor::normalize)

        if (lastAddedKey != null) {
            if (key == null || !similarKeys(key, lastAddedKey!!)) {
                framesWithoutLast++
                if (framesWithoutLast >= 3) lastAddedKey = null
            } else {
                framesWithoutLast = 0
                _state.update { it.copy(reading = best, status = "Next card…") }
                return
            }
        }

        _state.update {
            it.copy(
                reading = best,
                status = if (best == null) "Fit the card inside the frame" else "Reading…",
            )
        }
        val stable = stabilizer.offer(best) ?: return
        lookup(reading, stable)
    }

    private fun similarKeys(a: String, b: String) = a == b || CardTextExtractor.similarity(a, b) >= 0.8

    private fun cacheKey(r: ScanReading, name: String) =
        CardTextExtractor.normalize(name) + "|" + (r.setCode ?: "") + "|" + (r.collectorNumber ?: "")

    private fun lookup(reading: ScanReading, name: String) {
        val key = cacheKey(reading, name)
        val missAt = misses[key]
        if (missAt != null && System.currentTimeMillis() - missAt < 15_000) return

        _state.update { it.copy(lookingUp = true, status = "Looking up $name…") }
        viewModelScope.launch {
            try {
                val card = found[key] ?: identify(reading, name)?.also { found[key] = it }
                if (card == null) {
                    misses[key] = System.currentTimeMillis()
                    _state.update { it.copy(status = "No match for “$name”. Try better light or hold steady.") }
                } else {
                    onIdentified(card)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                misses[key] = System.currentTimeMillis()
                _state.update { it.copy(status = e.userMessage()) }
            } finally {
                stabilizer.reset()
                _state.update { it.copy(lookingUp = false) }
            }
        }
    }

    /** Exact printing from set + collector number when legible and consistent with the name; otherwise a fuzzy name match. */
    private suspend fun identify(reading: ScanReading, name: String): Card? {
        val cards = graph.cards
        if (reading.setCode != null && reading.collectorNumber != null) {
            val byNumber = runCatching { cards.byCollectorNumber(reading.setCode, reading.collectorNumber) }.getOrNull()
            if (byNumber != null && CardTextExtractor.nameMatches(name, byNumber.name)) return byNumber
        }
        if (reading.setCode != null) {
            cards.named(name, reading.setCode)?.let { return it }
        }
        for (candidate in reading.nameCandidates.ifEmpty { listOf(name) }.take(2)) {
            cards.named(candidate)?.let { return it }
        }
        return null
    }

    private suspend fun onIdentified(card: Card) {
        val s = _state.value
        if (s.mode == ScanMode.SINGLE) {
            _state.update { it.copy(result = card, status = "Found ${card.name}") }
            return
        }
        val finish = if (s.bulkFinish.key in card.finishes) s.bulkFinish else card.defaultFinish
        val entryId = graph.collection.add(card, 1, finish)
        lastAddedKey = CardTextExtractor.normalize(card.frontName)
        framesWithoutLast = 0
        _state.update {
            it.copy(
                session = listOf(SessionItem(entryId, card, finish, System.currentTimeMillis())) + it.session,
                lastAdded = card,
                status = "Added ${card.name}",
            )
        }
    }

    fun setMode(mode: ScanMode) {
        stabilizer.reset()
        lastAddedKey = null
        _state.update { it.copy(mode = mode, result = null, status = if (mode == ScanMode.BULK) "Bulk mode: each card is added automatically" else "Fit the card inside the frame") }
    }

    fun setBulkFinish(finish: Finish) = _state.update { it.copy(bulkFinish = finish) }

    fun toggleTorch() = _state.update { it.copy(torch = !it.torch) }

    fun showResult(card: Card) = _state.update { it.copy(result = card, status = "Found ${card.name}") }

    fun dismissResult() {
        stabilizer.reset()
        _state.update { it.copy(result = null, reading = null, status = "Fit the card inside the frame") }
    }

    fun addResult(card: Card, quantity: Int, finish: Finish, onAdded: (String) -> Unit) {
        viewModelScope.launch {
            val entryId = graph.collection.add(card, quantity, finish)
            _state.update {
                it.copy(session = listOf(SessionItem(entryId, card, finish, System.currentTimeMillis())) + it.session)
            }
            onAdded("Added $quantity× ${card.name}")
            dismissResult()
        }
    }

    /** Removes one copy that this scanning session added. */
    fun undo(item: SessionItem) {
        viewModelScope.launch {
            val entry = graph.collection.entry(item.entryId)
            if (entry != null) graph.collection.setQuantity(item.entryId, entry.quantity - 1)
            _state.update { s -> s.copy(session = s.session.filterNot { it === item }) }
        }
    }

    fun clearSession() = _state.update { it.copy(session = emptyList(), lastAdded = null) }
}
