package com.manavault.app.data.net

import com.manavault.app.core.interaction.ChatTurn
import com.manavault.app.core.interaction.ClaudeProtocol
import com.manavault.app.core.interaction.ClaudeReply
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

class ClaudeException(message: String) : IOException(message)

/** Calls Anthropic's Messages API directly with the player's own API key. */
class ClaudeApi(baseClient: OkHttpClient) {

    // Long answers can take a while to generate.
    private val http = baseClient.newBuilder()
        .readTimeout(180, TimeUnit.SECONDS)
        .callTimeout(240, TimeUnit.SECONDS)
        .build()

    /** Checks that the key and model are accepted. Throws [ClaudeException] with a readable reason if not. */
    suspend fun verifyKey(apiKey: String, model: String) {
        if (apiKey.isBlank()) throw ClaudeException("Enter an API key first.")
        val request = Request.Builder()
            .url(ClaudeProtocol.ENDPOINT)
            .header("x-api-key", apiKey.trim())
            .header("anthropic-version", ClaudeProtocol.API_VERSION)
            .header("content-type", "application/json")
            .post(
                ClaudeProtocol.requestBody(model, "Reply with the single word OK.", listOf(ChatTurn.user("Test")), 256)
                    .toRequestBody("application/json".toMediaType())
            )
            .build()
        val result = http.fetch(request)
        if (!result.isSuccess) throw ClaudeException(ClaudeProtocol.friendlyError(result.code, result.body))
    }

    suspend fun send(
        apiKey: String,
        model: String,
        system: String,
        turns: List<ChatTurn>,
        maxTokens: Int = 8000,
    ): ClaudeReply {
        if (apiKey.isBlank()) throw ClaudeException("Add your Anthropic API key in Settings to use AI explanations.")
        val request = Request.Builder()
            .url(ClaudeProtocol.ENDPOINT)
            .header("x-api-key", apiKey.trim())
            .header("anthropic-version", ClaudeProtocol.API_VERSION)
            .header("content-type", "application/json")
            .post(ClaudeProtocol.requestBody(model, system, turns, maxTokens).toRequestBody("application/json".toMediaType()))
            .build()
        val result = http.fetch(request)
        if (!result.isSuccess) throw ClaudeException(ClaudeProtocol.friendlyError(result.code, result.body))
        val reply = ClaudeProtocol.parseReply(result.body)
        if (reply.text.isBlank()) {
            throw ClaudeException(
                if (reply.stopReason == "refusal") "Claude declined to answer this one."
                else "Claude returned an empty answer. Try again."
            )
        }
        return reply
    }
}
