package com.manavault.app.core.interaction

import com.manavault.app.core.model.Card

/** A rules note about how the selected cards behave together. */
data class InteractionNote(
    val title: String,
    val body: String,
    val rule: String? = null,
    val cards: List<String> = emptyList(),
)

data class KeywordReminder(val keyword: String, val text: String, val rule: String?, val cards: List<String>)

/**
 * Offline, rules-based interaction notes. These cover the classic keyword and rules interactions that
 * come up most at the table; they're shown in free mode and alongside the AI explanation.
 */
object QuickNotes {

    private class C(val card: Card) {
        val text = card.allOracleText.lowercase()
        val keywords = card.keywords.map { it.lowercase() }.toSet()
        fun has(word: String): Boolean = word in keywords || Regex("\\b${Regex.escape(word)}\\b").containsMatchIn(text)
        fun says(regex: Regex): Boolean = regex.containsMatchIn(text)
        val name get() = card.name
    }

    private val DAMAGE = Regex("deals? (\\w+ |that much |damage equal)|damage to (any target|target creature|each creature)|\\bfights?\\b")
    private val REMOVAL_NOT_DESTROY = Regex("\\bexile|\\bsacrifices?\\b|-\\d+/-\\d+|-x/-x|toughness")
    private val TARGETS = Regex("\\btarget\\b")
    private val PLUS_COUNTER = Regex("\\+1/\\+1 counter")
    private val MINUS_COUNTER = Regex("-1/-1 counter")
    private val REPLACEMENT = Regex("\\binstead\\b|\\bif [^.]* would\\b")
    private val CANT = Regex("\\bcan't\\b")
    private val DIES = Regex("\\bdies\\b")
    private val ENTERS = Regex("\\benters\\b|enters the battlefield")
    private val FLICKER = Regex("exile[^.]*\\. (?:return|at the beginning)[^.]*(?:to|onto) the battlefield|exile[^.]*, then return [^.]*to the battlefield")
    private val COPY = Regex("\\bcopy of\\b|\\bbecomes? a copy\\b|enter as a copy")
    private val FREE_CAST = Regex("without paying (its|their) mana cost|\\bcascade\\b|\\bdiscover\\b")
    private val DOUBLER = Regex("twice that many|double the (number|amount)|that many plus|additional [^.]*counter")
    private val TOKENS_OR_COUNTERS = Regex("\\btokens?\\b|\\bcounters?\\b")
    private val BOUNCE = Regex("return [^.]* to (its|their) owner'?s'? hand")

    fun analyze(cards: List<Card>): List<InteractionNote> {
        val cs = cards.distinctBy { it.id }.map(::C)
        if (cs.isEmpty()) return emptyList()
        val notes = mutableListOf<InteractionNote>()
        fun names(vararg groups: List<C>) = groups.flatMap { g -> g.map { it.name } }.distinct()
        fun with(word: String) = cs.filter { it.has(word) }
        fun saying(r: Regex) = cs.filter { it.says(r) }

        val deathtouch = with("deathtouch")
        val trample = with("trample")
        val firstStrike = with("first strike")
        val doubleStrike = with("double strike")
        val lifelink = with("lifelink")
        val indestructible = with("indestructible")
        val hexproof = with("hexproof") + with("shroud")
        val ward = with("ward")
        val protection = cs.filter { it.text.contains("protection from") }
        val infect = with("infect") + with("wither")
        val persist = with("persist")
        val undying = with("undying")

        if (deathtouch.isNotEmpty() && trample.isNotEmpty()) {
            notes += InteractionNote(
                "Deathtouch + trample",
                "With both abilities, 1 damage assigned to each blocker counts as lethal, so all remaining combat damage can trample over to the player, planeswalker or battle being attacked.",
                "CR 702.2, 702.19", names(deathtouch, trample),
            )
        }
        if (deathtouch.isNotEmpty() && (firstStrike + doubleStrike).isNotEmpty()) {
            notes += InteractionNote(
                "Deathtouch + first strike",
                "A creature with both deals its damage in the first-strike damage step, so any creature it damages is destroyed before it can deal regular combat damage back.",
                "CR 702.2, 702.7", names(deathtouch, firstStrike, doubleStrike),
            )
        }
        val pingers = saying(DAMAGE)
        if (deathtouch.isNotEmpty() && pingers.isNotEmpty()) {
            notes += InteractionNote(
                "Deathtouch isn't just for combat",
                "Deathtouch applies to any damage dealt by that source. If the deathtouch source fights, \"bites\" or deals noncombat damage, even 1 damage destroys the creature. It only works when the deathtouch source itself is dealing the damage.",
                "CR 702.2", names(deathtouch, pingers),
            )
        }
        if (lifelink.isNotEmpty() && doubleStrike.isNotEmpty()) {
            notes += InteractionNote(
                "Lifelink + double strike",
                "Lifelink applies each time the creature deals damage, so with double strike you gain life in both the first-strike and regular damage steps.",
                "CR 702.15, 702.4", names(lifelink, doubleStrike),
            )
        } else if (lifelink.isNotEmpty() && (pingers.isNotEmpty() || trample.isNotEmpty())) {
            notes += InteractionNote(
                "How lifelink counts",
                "Lifelink isn't a trigger: you gain life at the same moment the damage is dealt, equal to all damage that source dealt — to creatures, players, planeswalkers and battles alike.",
                "CR 702.15", names(lifelink, pingers, trample),
            )
        }
        val nonDestroyRemoval = saying(REMOVAL_NOT_DESTROY)
        if (indestructible.isNotEmpty() && nonDestroyRemoval.isNotEmpty()) {
            notes += InteractionNote(
                "What indestructible doesn't stop",
                "Indestructible only stops \"destroy\" effects and destruction from lethal damage. It doesn't stop exile, sacrifice, -X/-X or a toughness of 0 or less, or the legend rule.",
                "CR 702.12", names(indestructible, nonDestroyRemoval),
            )
        }
        val targeters = saying(TARGETS)
        if (hexproof.isNotEmpty() && targeters.any { t -> hexproof.any { it !== t } || hexproof.size > 1 }) {
            notes += InteractionNote(
                "Hexproof / shroud and targeting",
                "Hexproof stops only spells and abilities your opponents control from targeting it; shroud stops everyone, including you. Neither stops effects that don't target, such as \"each creature\" or \"all creatures\".",
                "CR 702.11, 702.18", names(hexproof, targeters),
            )
        }
        if (ward.isNotEmpty() && targeters.isNotEmpty()) {
            notes += InteractionNote(
                "Ward",
                "When a permanent with ward becomes the target of a spell or ability an opponent controls, ward triggers and counters that spell or ability unless its controller pays the ward cost. Your own spells don't trigger it.",
                "CR 702.21", names(ward, targeters),
            )
        }
        if (protection.isNotEmpty() && cs.size > 1) {
            notes += InteractionNote(
                "Protection (DEBT)",
                "Protection from a quality means it can't be Damaged, Enchanted or Equipped, Blocked, or Targeted by anything with that quality. Effects that don't target or deal damage, like \"destroy all creatures\", still affect it.",
                "CR 702.16", names(protection),
            )
        }
        val plus = saying(PLUS_COUNTER)
        val minus = saying(MINUS_COUNTER) + infect
        if (plus.isNotEmpty() && minus.isNotEmpty()) {
            notes += InteractionNote(
                "+1/+1 and -1/-1 counters cancel",
                "If a permanent has both +1/+1 and -1/-1 counters, they're removed in pairs as a state-based action.",
                "CR 704.5q", names(plus, minus),
            )
        }
        if (persist.isNotEmpty() && plus.any { p -> persist.any { it !== p } }) {
            notes += InteractionNote(
                "Persist loop",
                "Persist only returns a creature that had no -1/-1 counters. A +1/+1 counter cancels the -1/-1 counter persist adds, so the creature can persist again — combined with a free sacrifice outlet this can loop.",
                "CR 702.79, 704.5q", names(persist, plus),
            )
        }
        if (undying.isNotEmpty() && minus.any { m -> undying.any { it !== m } }) {
            notes += InteractionNote(
                "Undying loop",
                "Undying only returns a creature that had no +1/+1 counters. A -1/-1 counter cancels the +1/+1 counter undying adds, so it can return again — the basis of undying + sacrifice-outlet loops.",
                "CR 702.93, 704.5q", names(undying, minus),
            )
        }
        if (infect.isNotEmpty()) {
            notes += InteractionNote(
                "Infect and wither damage",
                "Damage from a source with infect or wither is dealt to creatures as -1/-1 counters, which don't go away at end of turn. Infect damage to a player gives poison counters instead of life loss; 10 poison counters and that player loses.",
                "CR 702.80, 702.90", names(infect),
            )
        }
        val legends = cs.filter { it.card.isLegendary }.groupBy { it.card.name }.filter { it.value.size > 1 }
        for ((name, _) in legends) {
            notes += InteractionNote(
                "Legend rule",
                "If you control two or more legendary permanents with the same name, you choose one and put the rest into your graveyard. That isn't destruction, so indestructible doesn't help.",
                "CR 704.5j", listOf(name),
            )
        }
        val dies = saying(DIES)
        val exilers = cs.filter { it.text.contains("exile") }
        if (dies.isNotEmpty() && exilers.any { e -> dies.any { it !== e } }) {
            notes += InteractionNote(
                "Exile isn't dying",
                "\"Dies\" means put into a graveyard from the battlefield. A creature that's exiled (or bounced) doesn't die, so its \"when this dies\" abilities don't trigger. Sacrificing or destroying it does count.",
                "CR 700.4", names(dies, exilers),
            )
        }
        val flicker = saying(FLICKER)
        val enters = saying(ENTERS)
        if (flicker.isNotEmpty() && enters.any { e -> flicker.any { it !== e } }) {
            notes += InteractionNote(
                "Blinking resets a permanent",
                "A permanent that's exiled and returned is a new object: its \"enters\" abilities trigger again, but it loses counters, damage, Auras/Equipment attachments and any effects that applied to it.",
                "CR 400.7", names(flicker, enters),
            )
        }
        val copiers = saying(COPY)
        if (copiers.isNotEmpty() && enters.any { e -> copiers.any { it !== e } }) {
            notes += InteractionNote(
                "Copies and enter abilities",
                "A permanent that enters as a copy has the copied card's abilities as it enters, so its \"when this enters\" triggers fire. Copies don't copy counters, damage or effects that modified the original.",
                "CR 707.2", names(copiers, enters),
            )
        }
        val replacers = saying(REPLACEMENT)
        if (replacers.size >= 2) {
            notes += InteractionNote(
                "Multiple replacement effects",
                "When several replacement or prevention effects would apply to the same event, the affected player (or the controller of the affected object) chooses the order. Each effect can apply only once to that event.",
                "CR 616.1", names(replacers),
            )
        }
        val doublers = saying(DOUBLER)
        if (doublers.isNotEmpty() && saying(TOKENS_OR_COUNTERS).any { t -> doublers.any { it !== t } || doublers.size > 1 }) {
            notes += InteractionNote(
                "Stacking doublers",
                "Each doubling or \"additional\" effect modifies the event once, and they stack: two \"twice that many\" effects make four times as many. You choose the order they apply, which matters when mixing \"+1\" and \"double\" effects.",
                "CR 616.1, 614.1", names(doublers, saying(TOKENS_OR_COUNTERS)),
            )
        }
        val cants = saying(CANT)
        if (cants.isNotEmpty() && cs.size > 1) {
            notes += InteractionNote(
                "\"Can't\" beats \"can\"",
                "If one effect says something can happen and another says it can't, the \"can't\" effect wins.",
                "CR 101.2", names(cants),
            )
        }
        val freeCasters = saying(FREE_CAST)
        val xSpells = cs.filter { it.card.displayManaCost.contains("{X}") }
        if (freeCasters.isNotEmpty() && xSpells.any { x -> freeCasters.any { it !== x } }) {
            notes += InteractionNote(
                "X is 0 when cast for free",
                "If you cast a spell with {X} in its cost without paying its mana cost (cascade, discover and similar), X must be 0.",
                "CR 107.3b", names(freeCasters, xSpells),
            )
        }
        val tokenMakers = cs.filter { it.text.contains("token") }
        val bouncers = saying(BOUNCE) + flicker
        if (tokenMakers.isNotEmpty() && bouncers.any { b -> tokenMakers.any { it !== b } }) {
            notes += InteractionNote(
                "Tokens don't come back",
                "A token that leaves the battlefield ceases to exist, so bouncing or blinking a token removes it permanently.",
                "CR 704.5d", names(tokenMakers, bouncers),
            )
        }
        val flash = with("flash")
        if (flash.isNotEmpty() && cs.size > 1) {
            notes += InteractionNote(
                "Flash timing",
                "Cards with flash can be cast any time you could cast an instant: in response to a spell, during combat after blockers, or at the end of an opponent's turn.",
                "CR 702.8", names(flash),
            )
        }
        return notes
    }

    private data class Glossary(val text: String, val rule: String?)

    private val GLOSSARY: Map<String, Glossary> = mapOf(
        "deathtouch" to Glossary("Any amount of damage it deals to a creature is enough to destroy that creature.", "CR 702.2"),
        "defender" to Glossary("Can't attack.", "CR 702.3"),
        "double strike" to Glossary("Deals both first-strike and regular combat damage.", "CR 702.4"),
        "equip" to Glossary("Pay the equip cost to attach it to target creature you control. Activate only as a sorcery.", "CR 702.6"),
        "first strike" to Glossary("Deals combat damage before creatures without first strike or double strike.", "CR 702.7"),
        "flash" to Glossary("You may cast it any time you could cast an instant.", "CR 702.8"),
        "flying" to Glossary("Can't be blocked except by creatures with flying or reach.", "CR 702.9"),
        "haste" to Glossary("Can attack and use {T} abilities as soon as you control it.", "CR 702.10"),
        "hexproof" to Glossary("Can't be the target of spells or abilities your opponents control.", "CR 702.11"),
        "indestructible" to Glossary("Isn't destroyed by lethal damage or \"destroy\" effects.", "CR 702.12"),
        "intimidate" to Glossary("Can be blocked only by artifact creatures and creatures that share a color with it.", "CR 702.13"),
        "lifelink" to Glossary("Damage it deals also causes its controller to gain that much life.", "CR 702.15"),
        "protection" to Glossary("Can't be damaged, enchanted/equipped, blocked or targeted by anything with the stated quality.", "CR 702.16"),
        "reach" to Glossary("Can block creatures with flying.", "CR 702.17"),
        "shroud" to Glossary("Can't be the target of any spells or abilities.", "CR 702.18"),
        "trample" to Glossary("Combat damage beyond what's lethal to its blockers can be assigned to the player, planeswalker or battle it's attacking.", "CR 702.19"),
        "vigilance" to Glossary("Attacking doesn't cause it to tap.", "CR 702.20"),
        "ward" to Glossary("When it becomes the target of a spell or ability an opponent controls, counter that spell or ability unless its controller pays the ward cost.", "CR 702.21"),
        "cycling" to Glossary("Pay the cycling cost and discard this card to draw a card.", "CR 702.29"),
        "kicker" to Glossary("You may pay an additional cost as you cast it for an extra effect.", "CR 702.33"),
        "flashback" to Glossary("You may cast it from your graveyard for its flashback cost; then it's exiled.", "CR 702.34"),
        "storm" to Glossary("When you cast it, copy it for each spell cast before it this turn.", "CR 702.40"),
        "affinity" to Glossary("Costs {1} less to cast for each permanent of the stated type you control.", "CR 702.41"),
        "ninjutsu" to Glossary("Return an unblocked attacker you control to hand to put this onto the battlefield tapped and attacking.", "CR 702.49"),
        "convoke" to Glossary("Each creature you tap while casting it pays for {1} or one mana of that creature's color.", "CR 702.51"),
        "delve" to Glossary("Each card you exile from your graveyard while casting it pays for {1}.", "CR 702.66"),
        "evoke" to Glossary("You may cast it for its evoke cost; if you do, it's sacrificed when it enters.", "CR 702.74"),
        "persist" to Glossary("When it dies, if it had no -1/-1 counters, return it to the battlefield with a -1/-1 counter.", "CR 702.79"),
        "wither" to Glossary("Deals damage to creatures in the form of -1/-1 counters.", "CR 702.80"),
        "cascade" to Glossary("When you cast it, exile cards from the top of your library until you exile a nonland card with lesser mana value. You may cast it without paying its mana cost.", "CR 702.85"),
        "annihilator" to Glossary("Whenever it attacks, the defending player sacrifices that many permanents.", "CR 702.86"),
        "infect" to Glossary("Deals damage to creatures as -1/-1 counters and to players as poison counters.", "CR 702.90"),
        "undying" to Glossary("When it dies, if it had no +1/+1 counters, return it to the battlefield with a +1/+1 counter.", "CR 702.93"),
        "prowess" to Glossary("Whenever you cast a noncreature spell, it gets +1/+1 until end of turn.", "CR 702.108"),
        "menace" to Glossary("Can't be blocked except by two or more creatures.", "CR 702.111"),
        "crew" to Glossary("Tap any number of untapped creatures you control with total power N or more: this Vehicle becomes an artifact creature until end of turn.", "CR 702.122"),
        "toxic" to Glossary("Players dealt combat damage by it also get that many poison counters.", null),
    )

    /** One-line reminders for the keywords on the selected cards. */
    fun keywordReminders(cards: List<Card>): List<KeywordReminder> {
        val byKeyword = linkedMapOf<String, MutableList<String>>()
        for (card in cards.distinctBy { it.id }) {
            for (kw in card.keywords) {
                val key = kw.lowercase()
                val glossaryKey = if (key.startsWith("protection")) "protection" else key
                if (glossaryKey in GLOSSARY) byKeyword.getOrPut(glossaryKey) { mutableListOf() }.add(card.name)
            }
        }
        return byKeyword.map { (k, names) ->
            val g = GLOSSARY.getValue(k)
            KeywordReminder(k.replaceFirstChar { it.uppercase() }, g.text, g.rule, names.distinct())
        }
    }
}
