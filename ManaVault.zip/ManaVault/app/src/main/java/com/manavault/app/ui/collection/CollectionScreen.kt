package com.manavault.app.ui.collection

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.manavault.app.core.model.Condition
import com.manavault.app.core.model.Currency
import com.manavault.app.core.text.Format
import com.manavault.app.data.repo.OwnedCard
import com.manavault.app.graph
import com.manavault.app.ui.Navigator
import com.manavault.app.ui.Routes
import com.manavault.app.ui.components.AddToDeckDialog
import com.manavault.app.ui.components.CardImage
import com.manavault.app.ui.components.CardRow
import com.manavault.app.ui.components.CardSearchDialog
import com.manavault.app.ui.components.ConfirmDialog
import com.manavault.app.ui.components.EmptyState
import com.manavault.app.ui.components.FinishTag
import com.manavault.app.ui.components.LoadingBox
import com.manavault.app.ui.components.PrintingPickerDialog
import com.manavault.app.ui.components.QuantityStepper
import com.manavault.app.ui.components.ScreenScaffold
import com.manavault.app.ui.components.Sparkline
import com.manavault.app.ui.components.SymbolIcon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

@Composable
fun CollectionScreen(nav: Navigator) {
    val context = LocalContext.current
    val graph = context.graph
    val vm: CollectionViewModel = viewModel { CollectionViewModel(graph) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val job by vm.job.collectAsStateWithLifecycle()
    val message by vm.messages.collectAsStateWithLifecycle()
    val lastRefresh by vm.lastRefresh.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var menuOpen by remember { mutableStateOf(false) }
    var sortOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<OwnedCard?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var showPaste by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var deckCards by remember { mutableStateOf<List<com.manavault.app.core.model.Card>>(emptyList()) }

    LaunchedEffect(message) {
        message?.let { snackbar.showSnackbar(it); vm.messageShown() }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) scope.launch {
            val csv = vm.exportCsv()
            val ok = withContext(Dispatchers.IO) {
                runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(csv.toByteArray()) } }.isSuccess
            }
            snackbar.showSnackbar(if (ok) "Collection exported" else "Couldn't write the file")
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val text = withContext(Dispatchers.IO) {
                runCatching { context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } }.getOrNull()
            }
            if (text.isNullOrBlank()) snackbar.showSnackbar("Couldn't read that file") else vm.import(text)
        }
    }

    val selecting = ui.selection.isNotEmpty()
    ScreenScaffold(
        title = if (selecting) "${ui.selection.size} selected" else "Collection",
        snackbarHost = snackbar,
        onBack = if (selecting) vm::clearSelection else null,
        actions = {
            if (selecting) {
                IconButton(onClick = {
                    graph.tray.addAll(vm.selectedCards())
                    vm.clearSelection()
                    nav.interactionLab()
                }) { Icon(Icons.Filled.AutoAwesome, "Explain interactions") }
                IconButton(onClick = { deckCards = vm.selectedCards() }) { Icon(Icons.Filled.Style, "Add to deck") }
                IconButton(onClick = vm::selectAllVisible) { Icon(Icons.Filled.SelectAll, "Select all") }
                IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Delete") }
            } else {
                if (job is CollectionTask.Running) {
                    CircularProgressIndicator(Modifier.size(20.dp).padding(end = 4.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(12.dp))
                } else {
                    IconButton(onClick = { vm.refreshPrices() }) { Icon(Icons.Filled.Refresh, "Update prices") }
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, "More") }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Import CSV file") },
                            leadingIcon = { Icon(Icons.Filled.FileUpload, null) },
                            onClick = { menuOpen = false; importLauncher.launch(arrayOf("text/*", "application/csv", "application/vnd.ms-excel", "*/*")) },
                        )
                        DropdownMenuItem(
                            text = { Text("Paste a card list") },
                            leadingIcon = { Icon(Icons.Filled.ContentPaste, null) },
                            onClick = { menuOpen = false; showPaste = true },
                        )
                        DropdownMenuItem(
                            text = { Text("Export CSV") },
                            leadingIcon = { Icon(Icons.Filled.FileDownload, null) },
                            enabled = !ui.isEmpty,
                            onClick = { menuOpen = false; exportLauncher.launch("manavault-collection-${LocalDate.now()}.csv") },
                        )
                        DropdownMenuItem(
                            text = { Text("Settings") },
                            leadingIcon = { Icon(Icons.Filled.Settings, null) },
                            onClick = { menuOpen = false; nav.settings() },
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (!selecting && !ui.isEmpty) {
                FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Filled.Add, "Add cards") }
            }
        },
    ) { padding ->
        when {
            !ui.loaded -> LoadingBox(Modifier.padding(padding))
            ui.isEmpty -> EmptyState(
                icon = Icons.Filled.Inventory2,
                title = "Your vault is empty",
                message = "Scan cards with the camera, search for them, or import a list from another app.",
                modifier = Modifier.padding(padding),
                action = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { nav.tab(Routes.SCAN) }) { Text("Scan cards") }
                        OutlinedButton(onClick = { showAdd = true }) { Text("Search and add") }
                        TextButton(onClick = { showPaste = true }) { Text("Paste or import a list") }
                    }
                },
            )
            else -> LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(bottom = 96.dp)) {
                item(key = "summary") { ValueSummary(ui, lastRefresh) }
                item(key = "controls") {
                    Column(Modifier.padding(horizontal = 16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = ui.query,
                                onValueChange = vm::setQuery,
                                placeholder = { Text("Filter by name, type or set") },
                                leadingIcon = { Icon(Icons.Filled.Search, null) },
                                trailingIcon = { if (ui.query.isNotEmpty()) IconButton(onClick = { vm.setQuery("") }) { Icon(Icons.Filled.Close, "Clear") } },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                            )
                            Spacer(Modifier.width(4.dp))
                            Box {
                                IconButton(onClick = { sortOpen = true }) { Icon(Icons.AutoMirrored.Filled.Sort, "Sort") }
                                DropdownMenu(expanded = sortOpen, onDismissRequest = { sortOpen = false }) {
                                    SortMode.entries.forEach { s ->
                                        DropdownMenuItem(
                                            text = { Text(s.label, fontWeight = if (s == ui.sort) FontWeight.Bold else null) },
                                            onClick = { vm.setSort(s); sortOpen = false },
                                        )
                                    }
                                }
                            }
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                            items(COLOR_FILTERS) { c ->
                                FilterChip(
                                    selected = c in ui.colors,
                                    onClick = { vm.toggleColor(c) },
                                    label = {
                                        if (c == "M") Text("Multi") else SymbolIcon(c, 18.dp)
                                    },
                                )
                            }
                        }
                        Text(
                            "${ui.items.size} entries · sorted by ${ui.sort.label.lowercase()}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                items(ui.items, key = { it.entryId }) { o ->
                    OwnedRow(
                        o = o,
                        currency = ui.currency,
                        selected = o.entryId in ui.selection,
                        onClick = { if (selecting) vm.toggleSelect(o.entryId) else editing = o },
                        onLongClick = { vm.toggleSelect(o.entryId) },
                    )
                }
            }
        }
    }

    editing?.let { o ->
        // Keep the sheet in sync with database changes (quantity edits etc.).
        val live = ui.items.firstOrNull { it.entryId == o.entryId } ?: o
        EntrySheet(
            o = live,
            currency = ui.currency,
            onDismiss = { editing = null },
            onQuantity = { vm.setQuantity(live.entryId, it); if (it <= 0) editing = null },
            onEdit = { card, finish, cond -> vm.edit(live.entryId, card, finish, cond, live.quantity) },
            onOpen = { editing = null; nav.card(live.card.id) },
            onInteract = { graph.tray.add(live.card); scope.launch { snackbar.showSnackbar("Added to the Interaction Lab") } },
        )
    }
    if (showAdd) {
        CardSearchDialog(title = "Add to collection", keepOpen = true, onDismiss = { showAdd = false }, onPick = { vm.addCard(it) })
    }
    if (showPaste) {
        PasteListDialog(onDismiss = { showPaste = false }, onImport = { vm.import(it) })
    }
    if (confirmDelete) {
        ConfirmDialog(
            title = "Remove ${ui.selection.size} entries?",
            message = "They'll be removed from your collection. Decks aren't affected.",
            confirmLabel = "Remove",
            onConfirm = vm::deleteSelected,
            onDismiss = { confirmDelete = false },
        )
    }
    if (deckCards.isNotEmpty()) {
        AddToDeckDialog(deckCards, onDismiss = { deckCards = emptyList(); vm.clearSelection() }, onDone = { scope.launch { snackbar.showSnackbar(it) } })
    }
    when (val j = job) {
        is CollectionTask.Running -> if (!j.message.startsWith("Updating prices")) {
            AlertDialog(onDismissRequest = {}, confirmButton = {}, title = { Text("Importing") }, text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(24.dp))
                    Spacer(Modifier.width(16.dp))
                    Text(j.message)
                }
            })
        }
        is CollectionTask.ImportDone -> AlertDialog(
            onDismissRequest = vm::dismissJob,
            confirmButton = { TextButton(onClick = vm::dismissJob) { Text("OK") } },
            title = { Text("Import finished") },
            text = {
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    Text("Added ${j.report.added} cards (${j.report.distinct} different printings).")
                    if (j.report.notFound.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Couldn't find ${j.report.notFound.size}:", fontWeight = FontWeight.SemiBold)
                        j.report.notFound.take(50).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            },
        )
        null -> Unit
    }
}

@Composable
private fun ValueSummary(ui: CollectionUi, lastRefresh: Long) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("Collection value", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    Format.total(ui.totalValue, ui.currency),
                    style = MaterialTheme.typography.displaySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.weight(1f),
                )
                if (ui.history.size >= 2) {
                    Sparkline(ui.history, Modifier.width(110.dp).height(40.dp).padding(bottom = 6.dp), color = MaterialTheme.colorScheme.primary)
                }
            }
            Text(
                "${Format.count(ui.totalCards)} cards · ${Format.count(ui.uniqueCards)} unique · prices ${Format.relativeAge(lastRefresh)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
            )
        }
    }
}

@Composable
private fun OwnedRow(o: OwnedCard, currency: Currency, selected: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    CardRow(
        card = o.card,
        subtitle = "${o.card.setCode.uppercase()} #${o.card.collectorNumber} · ${o.condition.code}",
        selected = selected,
        onClick = onClick,
        onLongClick = onLongClick,
        badges = { FinishTag(o.finish.key) },
        trailing = {
            Column(horizontalAlignment = Alignment.End) {
                Text(Format.price(o.totalPrice(currency), currency), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    if (o.quantity > 1) "${o.quantity} × ${Format.price(o.unitPrice(currency), currency)}" else "×1",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
    )
}

@Composable
private fun EntrySheet(
    o: OwnedCard,
    currency: Currency,
    onDismiss: () -> Unit,
    onQuantity: (Int) -> Unit,
    onEdit: (com.manavault.app.core.model.Card, com.manavault.app.core.model.Finish, Condition) -> Unit,
    onOpen: () -> Unit,
    onInteract: () -> Unit,
) {
    var pickPrinting by remember { mutableStateOf(false) }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
            Row {
                CardImage(o.card.frontImage, o.card.name, Modifier.width(110.dp), cornerRadius = 7.dp)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(o.card.name, style = MaterialTheme.typography.titleLarge)
                    Text("${o.card.setName} · #${o.card.collectorNumber}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Text(Format.price(o.unitPrice(currency), currency) + " each", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Text("Total " + Format.price(o.totalPrice(currency), currency), style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { pickPrinting = true }, contentPadding = PaddingValues(0.dp)) { Text("Change printing") }
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Quantity", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                QuantityStepper(o.quantity, onQuantity, min = 0)
            }
            Spacer(Modifier.height(12.dp))
            Text("Finish", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                o.card.availableFinishes.forEach { f ->
                    FilterChip(selected = o.finish == f, onClick = { onEdit(o.card, f, o.condition) }, label = { Text(f.label) })
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Condition", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Condition.entries.forEach { c ->
                    FilterChip(selected = o.condition == c, onClick = { onEdit(o.card, o.finish, c) }, label = { Text(c.code) })
                }
            }
            Spacer(Modifier.height(16.dp))
            HorizontalDivider()
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = onOpen) { Text("Card details") }
                TextButton(onClick = onInteract) { Text("Interaction Lab") }
                TextButton(onClick = { onQuantity(0) }) { Text("Remove", color = MaterialTheme.colorScheme.error) }
            }
        }
    }
    if (pickPrinting) {
        PrintingPickerDialog(o.card, onDismiss = { pickPrinting = false }, onPick = { p ->
            val finish = if (o.finish.key in p.finishes) o.finish else p.defaultFinish
            onEdit(p, finish, o.condition)
        })
    }
}

@Composable
fun PasteListDialog(onDismiss: () -> Unit, onImport: (String) -> Unit, title: String = "Paste a card list") {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(
                    "One card per line, e.g. “4 Lightning Bolt” or “1 Sol Ring (CMM) 400”. Exports from Arena, MTGO, Moxfield, Archidekt and ManaBox CSVs all work.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 320.dp),
                    placeholder = { Text("4 Lightning Bolt\n2 Counterspell\n1 Sol Ring (CMM) 400") },
                )
            }
        },
        confirmButton = {
            TextButton(enabled = text.isNotBlank(), onClick = { onImport(text); onDismiss() }) { Text("Import") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
