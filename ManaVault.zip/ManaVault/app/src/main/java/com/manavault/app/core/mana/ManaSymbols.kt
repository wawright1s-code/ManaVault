package com.manavault.app.core.mana

/** A run of rules text: either plain text or a single `{X}` symbol. */
sealed interface TextSegment {
    data class Plain(val text: String) : TextSegment
    data class Symbol(val symbol: String) : TextSegment
}

object ManaSymbols {
    private val symbolRegex = Regex("\\{([^}]+)\\}")

    val COLORS = listOf("W", "U", "B", "R", "G")
    val COLOR_NAMES = mapOf("W" to "White", "U" to "Blue", "B" to "Black", "R" to "Red", "G" to "Green", "C" to "Colorless")

    /** "{2}{W/U}{G}" -> ["2", "W/U", "G"] */
    fun parse(cost: String): List<String> = symbolRegex.findAll(cost).map { it.groupValues[1] }.toList()

    /** URL of Scryfall's official SVG for a symbol, e.g. "W/U" -> .../WU.svg */
    fun svgUrl(symbol: String): String {
        val code = when (symbol) {
            "½" -> "HALF"
            "∞" -> "INFINITY"
            else -> symbol.replace("/", "").uppercase()
        }
        return "https://svgs.scryfall.io/card-symbols/$code.svg"
    }

    /** Splits text into plain runs and symbols so they can be drawn inline. */
    fun segments(text: String): List<TextSegment> {
        val out = mutableListOf<TextSegment>()
        var last = 0
        for (m in symbolRegex.findAll(text)) {
            if (m.range.first > last) out += TextSegment.Plain(text.substring(last, m.range.first))
            out += TextSegment.Symbol(m.groupValues[1])
            last = m.range.last + 1
        }
        if (last < text.length) out += TextSegment.Plain(text.substring(last))
        return out
    }

    /**
     * Counts colored pips in a mana cost. Hybrid symbols count toward each of their colors
     * ("{W/U}" adds one to W and one to U); Phyrexian symbols count toward their color.
     */
    fun colorPips(cost: String): Map<String, Int> {
        val counts = linkedMapOf<String, Int>()
        for (sym in parse(cost)) {
            for (part in sym.split('/')) {
                if (part in COLORS) counts[part] = (counts[part] ?: 0) + 1
            }
            if (sym == "C") counts["C"] = (counts["C"] ?: 0) + 1
        }
        return counts
    }

    /** Orders color identity letters in WUBRG order. */
    fun sortColors(colors: Collection<String>): List<String> =
        colors.distinct().sortedBy { COLORS.indexOf(it).let { i -> if (i < 0) 99 else i } }

    /** "{W}{U}{B}" style string for a color identity, "{C}" when colorless. */
    fun identityCost(colors: Collection<String>): String =
        sortColors(colors).joinToString("") { "{$it}" }.ifEmpty { "{C}" }

    /** Common guild / shard / wedge names for a color identity. */
    fun identityName(colors: Collection<String>): String {
        val key = sortColors(colors).joinToString("")
        return NAMES[key] ?: when (key.length) {
            0 -> "Colorless"
            1 -> COLOR_NAMES[key] ?: key
            5 -> "Five-color"
            else -> key
        }
    }

    private val NAMES = mapOf(
        "WU" to "Azorius", "UB" to "Dimir", "BR" to "Rakdos", "RG" to "Gruul", "WG" to "Selesnya",
        "WB" to "Orzhov", "UR" to "Izzet", "BG" to "Golgari", "WR" to "Boros", "UG" to "Simic",
        "WUG" to "Bant", "WUB" to "Esper", "UBR" to "Grixis", "BRG" to "Jund", "WRG" to "Naya",
        "WBG" to "Abzan", "WUR" to "Jeskai", "UBG" to "Sultai", "WBR" to "Mardu", "URG" to "Temur",
        "UBRG" to "Glint-Eye", "WBRG" to "Dune-Brood", "WURG" to "Ink-Treader", "WUBG" to "Witch-Maw",
        "WUBR" to "Yore-Tiller",
    )
}
