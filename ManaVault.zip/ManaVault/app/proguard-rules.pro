# OkHttp optional TLS providers
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# Room entities are accessed reflectively by generated code
-keep class com.manavault.app.data.db.** { *; }
